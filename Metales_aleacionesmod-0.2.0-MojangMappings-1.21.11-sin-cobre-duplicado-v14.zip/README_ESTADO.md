# Mod Realista — estado v14

Base: v13, Minecraft 1.21.11, Fabric, Mojang Mappings.

Cambios de esta versión:

1. Se corrigieron las recetas `crafting_shaped` para el formato de Minecraft 1.21.11: las entradas de `key` usan directamente el ID del objeto. Esto corrige las recetas de las herramientas de aluminio y normaliza las demás recetas shaped del mod.
2. Receta del Alto Horno de Cobre:
   - Fila superior: 3 lingotes de cobre.
   - Fila central: bloque de cobre, horno, bloque de cobre.
   - Fila inferior: 3 bloques de piedra lisa (`smooth_stone`).
3. El Acero ahora se puede fabricar en el Horno de Fusión Básico: 1 hierro + 1 carbón -> 1 acero.
4. El Horno de Fusión Avanzado queda para Netherite-Titanio y Netherite-Tungsteno.
5. Se mantienen las correcciones anteriores: cobre vanilla sin duplicados de mena/equipo, fragmentos de estaño/aluminio fundibles en horno y alto horno, y progresión de minería de picos.

No se ha ejecutado una compilación local; el ZIP está preparado para GitHub Actions.
