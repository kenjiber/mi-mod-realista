package com.kenjiber.modrealista.screen;

import com.kenjiber.modrealista.ModRealista;
import com.kenjiber.modrealista.menu.AltoHornoScreenHandler;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/**
 * Pantalla del Alto Horno de Cobre. El fondo es nuestra textura propia;
 * la llama y la flecha de progreso reutilizan los sprites del horno
 * vainilla (se ven y animan exactamente igual).
 */
public class AltoHornoScreen extends AbstractContainerScreen<AltoHornoScreenHandler> {

	private static final Identifier TEXTURA = Identifier.fromNamespaceAndPath(ModRealista.MOD_ID, "textures/gui/container/alto_horno_de_cobre.png");

	// Sprites vainilla del horno normal (mismo tamaño en el horno de fusión/alto horno).
	private static final Identifier LLAMA = Identifier.withDefaultNamespace("container/furnace/lit_progress");
	private static final Identifier FLECHA = Identifier.withDefaultNamespace("container/furnace/burn_progress");

	// Posiciones dentro de nuestra GUI (coinciden con donde están los slots de combustible/salida).
	private static final int LLAMA_X = 56, LLAMA_Y = 36, LLAMA_W = 14, LLAMA_H = 14;
	private static final int FLECHA_X = 79, FLECHA_Y = 34, FLECHA_W = 22, FLECHA_H = 16;

	public AltoHornoScreen(AltoHornoScreenHandler handler, Inventory inventory, Component title) {
		super(handler, inventory, title);
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	@Override
	protected void renderBg(GuiGraphics context, float delta, int mouseX, int mouseY) {
		int x = (width - imageWidth) / 2;
		int y = (height - imageHeight) / 2;
		context.drawTexture(RenderPipelines.GUI_TEXTURED, TEXTURA, x, y, 0, 0, imageWidth, imageHeight, 176, 166);

		// Llama: se "vacía" de abajo hacia arriba a medida que se consume el combustible.
		float combustible = handler.getCombustibleFraccion();
		int alturaLlama = Math.round(LLAMA_H * combustible);
		if (alturaLlama > 0) {
			context.drawTexture(RenderPipelines.GUI_TEXTURED, LLAMA, x + LLAMA_X, y + LLAMA_Y + (LLAMA_H - alturaLlama),
					0, LLAMA_H - alturaLlama, LLAMA_W, alturaLlama, LLAMA_W, LLAMA_H);
		}

		// Flecha de progreso: se rellena de izquierda a derecha.
		float progreso = handler.getProgresoFraccion();
		int anchoFlecha = Math.round(FLECHA_W * progreso);
		if (anchoFlecha > 0) {
			context.drawTexture(RenderPipelines.GUI_TEXTURED, FLECHA, x + FLECHA_X, y + FLECHA_Y, 0, 0, anchoFlecha, FLECHA_H, FLECHA_W, FLECHA_H);
		}
	}

	@Override
	public void render(GuiGraphics context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		this.renderTooltip(context, mouseX, mouseY);
	}
}
