# Estado de migración — 1.21.11 Mojang Mappings

Esta versión fue revisada de forma global para eliminar restos de Yarn en el código Java.

Cambios importantes aplicados:
- `ExperienceDroppingBlock` (Yarn) -> `DropExperienceBlock` (Mojang).
- `ItemStack.decrement()` -> `shrink()`.
- `ItemStack.increment()` -> `grow()`.
- `Entity.squaredDistanceTo()` -> `distanceToSqr()`.
- `BlockEntity.pos` -> `worldPosition`.
- `AbstractContainerScreen.backgroundWidth/backgroundHeight` -> `imageWidth/imageHeight`.
- `AbstractContainerScreen.drawBackground()` -> `renderBg()`.
- Se conservaron los nombres Mojang ya correctos de 1.21.11, como `BlockPos.STREAM_CODEC`, `ItemStack.is(...)`, `Slot.mayPlace(...)`, `AbstractContainerMenu.quickMoveStack(...)`, `BlockBehaviour.Properties.lightLevel(...)`, etc.
- Se mantiene la eliminación de equipo/mena/lingote de cobre personalizado; solo permanece el Alto Horno de Cobre del mod.

No se declara compilación verificada en este entorno. La verificación final debe hacerse con el `build` de GitHub Actions.
