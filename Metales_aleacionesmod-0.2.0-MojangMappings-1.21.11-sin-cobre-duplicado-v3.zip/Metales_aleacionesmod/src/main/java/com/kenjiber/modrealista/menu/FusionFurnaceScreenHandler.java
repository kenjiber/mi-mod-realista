package com.kenjiber.modrealista.menu;

import com.kenjiber.modrealista.block.entity.FusionFurnaceBlockEntity;
import com.kenjiber.modrealista.init.ModItems;
import com.kenjiber.modrealista.init.ModScreenHandlers;
import com.kenjiber.modrealista.util.ModFuel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.FuelValues;

/**
 * Horno de Fusión (Básico o Avanzado, mismo Screen para los dos):
 * 2 ranuras de entrada (metales distintos), 1 de molde, 1 de combustible,
 * 1 de salida (la aleación resultante).
 */
public class FusionFurnaceScreenHandler extends AbstractContainerMenu {

	public static final int SLOT_ENTRADA_1 = 0;
	public static final int SLOT_ENTRADA_2 = 1;
	public static final int SLOT_MOLDE = 2;
	public static final int SLOT_COMBUSTIBLE = 3;
	public static final int SLOT_SALIDA = 4;

	private final Container inventarioHorno;
	private final ContainerData propiedades;

	public static final int PROP_PROGRESO = 0;
	public static final int PROP_PROGRESO_TOTAL = 1;
	public static final int PROP_COMBUSTIBLE = 2;
	public static final int PROP_COMBUSTIBLE_MAX = 3;

	public FusionFurnaceScreenHandler(int syncId, Inventory playerInventory, BlockPos pos) {
		super(ModScreenHandlers.HORNO_DE_FUSION, syncId);
		final FuelValues fuelValues = playerInventory.player.level().fuelValues();

		// 🔧 FIX: getLevel() → level()
		BlockEntity be = playerInventory.player.level().getBlockEntity(pos);
		if (be instanceof FusionFurnaceBlockEntity fusionFurnace) {
			this.inventarioHorno = fusionFurnace;
			this.propiedades = new ContainerData() {
				@Override
				public int get(int index) {
					return switch (index) {
						case PROP_PROGRESO -> fusionFurnace.getProgresoRaw();
						case PROP_PROGRESO_TOTAL -> fusionFurnace.getTiempoTotalNecesarioRaw();
						case PROP_COMBUSTIBLE -> fusionFurnace.getCombustibleRestanteRaw();
						case PROP_COMBUSTIBLE_MAX -> fusionFurnace.getCombustibleMaximoRaw();
						default -> 0;
					};
				}

				@Override
				public void set(int index, int value) {
					switch (index) {
						case PROP_PROGRESO -> fusionFurnace.setProgresoRaw(value);
						case PROP_PROGRESO_TOTAL -> fusionFurnace.setTiempoTotalNecesarioRaw(value);
						case PROP_COMBUSTIBLE -> fusionFurnace.setCombustibleRestanteRaw(value);
						case PROP_COMBUSTIBLE_MAX -> fusionFurnace.setCombustibleMaximoRaw(value);
					}
				}

				// 🔧 FIX: getContainerSize() → getCount()
				@Override
				public int getCount() {
					return 4;
				}
			};
		} else {
			this.inventarioHorno = new SimpleContainer(5);
			this.propiedades = new SimpleContainerData(4);
		}

		// 🔧 FIX: checkSize() → checkContainerSize()
		checkContainerSize(inventarioHorno, 5);
		this.addDataSlots(propiedades);

		this.addSlot(new Slot(inventarioHorno, SLOT_ENTRADA_1, 35, 17));
		this.addSlot(new Slot(inventarioHorno, SLOT_ENTRADA_2, 80, 17));

		this.addSlot(new Slot(inventarioHorno, SLOT_MOLDE, 35, 53) {
			// 🔧 FIX: canInsert() → mayPlace(), isOf() → is()
			@Override
			public boolean mayPlace(ItemStack stack) {
				return stack.is(ModItems.molde_de_fundicion);
			}
		});

		this.addSlot(new Slot(inventarioHorno, SLOT_COMBUSTIBLE, 80, 53) {
			@Override
			public boolean mayPlace(ItemStack stack) {
				return ModFuel.esCombustible(stack, fuelValues);
			}
		});

		this.addSlot(new Slot(inventarioHorno, SLOT_SALIDA, 134, 35) {
			@Override
			public boolean mayPlace(ItemStack stack) {
				return false;
			}
		});

		// Inventario del jugador (27 slots principales + 9 de hotbar).
		for (int fila = 0; fila < 3; fila++) {
			for (int col = 0; col < 9; col++) {
				this.addSlot(new Slot(playerInventory, col + fila * 9 + 9, 8 + col * 18, 84 + fila * 18));
			}
		}
		for (int col = 0; col < 9; col++) {
			this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 142));
		}
	}

	// 🔧 FIX: canUse() → stillValid(), Player → Player
	@Override
	public boolean stillValid(Player player) {
		return inventarioHorno.stillValid(player);
	}

	// 🔧 FIX: quickMove() → quickMoveStack(), insertItem() → moveItemStackTo()
	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		Slot slot = this.slots.get(index);
		if (slot == null || !slot.hasItem()) return ItemStack.EMPTY;
		ItemStack original = slot.getItem();
		ItemStack copia = original.copy();
		if (index < 5) {
			if (!this.moveItemStackTo(original, 5, this.slots.size(), true)) return ItemStack.EMPTY;
		} else {
			if (!this.moveItemStackTo(original, 0, 5, false)) return ItemStack.EMPTY;
		}
		if (original.isEmpty()) slot.set(ItemStack.EMPTY); else slot.setChanged();
		return copia;
	}

	// --- Helpers para que la pantalla (cliente) dibuje la animación ---
	public float getProgresoFraccion() {
		int total = propiedades.get(PROP_PROGRESO_TOTAL);
		return total <= 0 ? 0f : (float) propiedades.get(PROP_PROGRESO) / total;
	}

	public float getCombustibleFraccion() {
		int max = propiedades.get(PROP_COMBUSTIBLE_MAX);
		return max <= 0 ? 0f : (float) propiedades.get(PROP_COMBUSTIBLE) / max;
	}
}
