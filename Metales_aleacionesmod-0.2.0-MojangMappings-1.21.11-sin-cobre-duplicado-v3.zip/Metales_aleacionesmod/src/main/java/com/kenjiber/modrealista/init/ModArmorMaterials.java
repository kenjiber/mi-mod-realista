package com.kenjiber.modrealista.init;

import net.minecraft.core.Holder;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

import java.util.EnumMap;
import java.util.Map;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

/**
 * ============================== ATENCION (1.21.11) ==============================
 * A partir de 1.21.2-1.21.4, Mojang reescribió por completo el sistema de
 * armaduras. Cambios clave frente a la version 1.21.1 que teniamos antes:
 *   1. ArmorMaterial se movio de paquete: ahora vive en
 *      net.minecraft.world.item.equipment.ArmorMaterial.
 *   2. Ya NO se registra en un Registry (no mas Registries.ARMOR_MATERIAL);
 *      ahora es un simple record que se guarda como constante, sin
 *      Holder envolviendolo.
 *   3. El "repairIngredient" ya no es un Ingredient/Supplier<Ingredient>,
 *      sino un TagKey<Item> (usamos los tags ya creados en
 *      data/modrealista/tags/item/repair/<metal>.json).
 *   4. La lista de texturas (List<Layer>) fue reemplazada por una sola
 *      ResourceKey<EquipmentAsset>, que apunta a un archivo JSON nuevo en
 *      assets/modrealista/equipment/<metal>.json.
 *   5. Las texturas de armadura en si se movieron de
 *      textures/models/armor/<id>_layer_1.png (viejo) a
 *      textures/entity/equipment/humanoid/<id>.png (nuevo, capa 1: cuerpo+botas)
 *      textures/entity/equipment/humanoid_leggings/<id>.png (nuevo, capa 2: piernas)
 * ==================================================================================
 */
public final class ModArmorMaterials {

	private ModArmorMaterials() {}

	private static final Map<ModMetal, ArmorMaterial> CACHE = new EnumMap<>(ModMetal.class);

	public static ArmorMaterial get(ModMetal metal) {
		return CACHE.computeIfAbsent(metal, ModArmorMaterials::crear);
	}

	/** Clave del "equipment asset": determina el nombre del JSON en assets/modrealista/equipment/. */
	public static ResourceKey<EquipmentAsset> equipmentAssetKey(ModMetal metal) {
		// 🔧 FIX: ResourceKey.create(EquipmentAssetKeys.REGISTRY_KEY, ...) 
		//      → ResourceKey.create(EquipmentAssets.ROOT_ID, ...)
		return ResourceKey.create(
				EquipmentAssets.ROOT_ID,
				Identifier.fromNamespaceAndPath(MOD_ID, metal.id)
		);
	}

	private static int encantabilidad(ModMetal metal) {
		return switch (metal) {
			case ORO -> 25;
			case TITANIO, NETHERITE_TITANIO, NETHERITE_TUNGSTENO -> 15;
			default -> 9;
		};
	}

	private static Holder<SoundEvent> sonidoEquipar(ModMetal metal) {
		// 🔧 FIX: RegistryEntry<SoundEvent> → Holder<SoundEvent>
		// 🔧 FIX: SoundEvents.ITEM_ARMOR_EQUIP_X → SoundEvents.ARMOR_EQUIP_X
		return switch (metal) {
			case ORO -> SoundEvents.ARMOR_EQUIP_GOLD;
			case NETHERITE_TITANIO, NETHERITE_TUNGSTENO -> SoundEvents.ARMOR_EQUIP_NETHERITE;
			default -> SoundEvents.ARMOR_EQUIP_IRON;
		};
	}

	private static ArmorMaterial crear(ModMetal metal) {
		ModMetal.ArmorStats s = metal.armadura;

		// 🔧 FIX: EquipmentType → ArmorType
		Map<ArmorType, Integer> defensaPorPieza = Map.of(
				ArmorType.HELMET, s.casco,
				ArmorType.CHESTPLATE, s.pechera,
				ArmorType.LEGGINGS, s.pantalones,
				ArmorType.BOOTS, s.botas
		);

		TagKey<Item> repararCon = ModToolMaterials.tagDeReparacion(metal);

		return new ArmorMaterial(
				s.durabilidadBase,       // 1. int durability (base; cada pieza lo multiplica distinto)
				defensaPorPieza,         // 2. Map<ArmorType, Integer> defense
				encantabilidad(metal),   // 3. int enchantmentValue
				sonidoEquipar(metal),    // 4. Holder<SoundEvent> equipSound
				s.tenacidad,             // 5. float toughness
				0f,                      // 6. float knockbackResistance
				repararCon,              // 7. TagKey<Item> repairIngredient
				equipmentAssetKey(metal) // 8. ResourceKey<EquipmentAsset> assetId
		);
	}
}
