package com.kenjiber.modrealista.util;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.FuelValues;

/** Acceso a los combustibles de Minecraft 1.21.11. */
public final class ModFuel {

    private ModFuel() {}

    /** Indica si el stack es un combustible según los valores del mundo. */
    public static boolean esCombustible(ItemStack stack, FuelValues fuelValues) {
        return !stack.isEmpty() && fuelValues.isFuel(stack);
    }

    /** Devuelve los ticks de quemado de una unidad de combustible. */
    public static int tiempoDeQuemado(ItemStack stack, FuelValues fuelValues) {
        if (stack.isEmpty()) return 0;
        return fuelValues.burnDuration(stack);
    }
}
