package com.kenjiber.modrealista.block.entity;

import com.kenjiber.modrealista.init.ModBlockEntities;
import com.kenjiber.modrealista.init.ModItems;
import com.kenjiber.modrealista.recipe.ModFusionRecipes;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Alto Horno de Cobre: purifica 4 Fragmentos Crudos de UN metal (slot 0) +
 * Molde reutilizable (slot 1, no se consume) + combustible (slot 2) en
 * 1 Lingote Puro (slot 3). Ver {@link ModFusionRecipes#PURIFICACIONES}.
 */
public class AltoHornoBlockEntity extends BlockEntity implements Inventory, net.minecraft.screen.NamedScreenHandlerFactory {

	public static final int SLOT_FRAGMENTOS = 0;
	public static final int SLOT_MOLDE = 1;
	public static final int SLOT_COMBUSTIBLE = 2;
	public static final int SLOT_SALIDA = 3;
	private static final int TAMANO_INVENTARIO = 4;

	private final DefaultedList<ItemStack> inventario = DefaultedList.ofSize(TAMANO_INVENTARIO, ItemStack.EMPTY);

	private int progreso = 0;
	private int tiempoTotalNecesario = 200;
	private int combustibleRestante = 0;
	private int combustibleMaximoActual = 0;

	public AltoHornoBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.ALTO_HORNO_ENTITY, pos, state);
	}

	public float getProgreso() {
		return tiempoTotalNecesario == 0 ? 0 : (float) progreso / tiempoTotalNecesario;
	}

	public static <T extends BlockEntity> void tick(World world, BlockPos pos, BlockState state, T be) {
		if (!(be instanceof AltoHornoBlockEntity horno)) return;
		if (world.isClient) return;
		horno.tickServidor((ServerWorld) world);
	}

	private void tickServidor(ServerWorld world) {
		ItemStack fragmentos = inventario.get(SLOT_FRAGMENTOS);
		ModFusionRecipes.Purificacion receta = ModFusionRecipes.buscarPurificacion(fragmentos.getItem(), fragmentos.getCount());

		boolean tieneMolde = inventario.get(SLOT_MOLDE).isOf(ModItems.molde_de_fundicion);
		boolean puedeProcesar = receta != null && tieneMolde
				&& (inventario.get(SLOT_SALIDA).isEmpty()
					|| (inventario.get(SLOT_SALIDA).isOf(receta.resultado())
						&& inventario.get(SLOT_SALIDA).getCount() < inventario.get(SLOT_SALIDA).getMaxCount()));

		if (!puedeProcesar) {
			if (combustibleRestante <= 0) progreso = 0;
			markDirty();
			return;
		}

		if (combustibleRestante <= 0) {
			ItemStack combustible = inventario.get(SLOT_COMBUSTIBLE);
			int valor = com.kenjiber.modrealista.util.ModFuel.tiempoDeQuemado(combustible);
			if (valor > 0) {
				combustibleRestante = valor;
				combustibleMaximoActual = valor;
				combustible.decrement(1);
			}
		}

		if (combustibleRestante > 0) {
			combustibleRestante--;
			tiempoTotalNecesario = receta.tiempoTicks();
			progreso++;
			if (progreso >= tiempoTotalNecesario) {
				progreso = 0;
				fragmentos.decrement(receta.cantidadFragmentos());
				if (inventario.get(SLOT_SALIDA).isEmpty()) {
					inventario.set(SLOT_SALIDA, new ItemStack(receta.resultado()));
				} else {
					inventario.get(SLOT_SALIDA).increment(1);
				}
			}
		}
		markDirty();
	}

	@Override public int size() { return TAMANO_INVENTARIO; }
	@Override public boolean isEmpty() { return inventario.stream().allMatch(ItemStack::isEmpty); }
	@Override public ItemStack getStack(int slot) { return inventario.get(slot); }
	@Override public ItemStack removeStack(int slot, int amount) { return net.minecraft.inventory.Inventories.splitStack(inventario, slot, amount); }
	@Override public ItemStack removeStack(int slot) { return net.minecraft.inventory.Inventories.removeStack(inventario, slot); }
	@Override public void setStack(int slot, ItemStack stack) { inventario.set(slot, stack); }
	@Override public void markDirty() { if (world != null) world.updateListeners(pos, getCachedState(), getCachedState(), 3); }
	@Override public boolean canPlayerUse(PlayerEntity player) {
		return world != null && world.getBlockEntity(pos) == this
				&& player.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 64.0;
	}
	@Override public void clear() { inventario.clear(); }

	@Override
	public net.minecraft.text.Text getDisplayName() {
		return net.minecraft.text.Text.translatable("block.modrealista.alto_horno_de_cobre");
	}

	@Override
	public net.minecraft.screen.ScreenHandler createMenu(int syncId, net.minecraft.entity.player.PlayerInventory playerInventory, PlayerEntity player) {
		return new com.kenjiber.modrealista.menu.AltoHornoScreenHandler(syncId, playerInventory, this);
	}
}
