package com.kenjiber.modrealista.init;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.util.Identifier;

// NOTA: Reemplaza "MiScreenHandler" por el nombre real de la clase de tu contenedor/GUI (ej. HornoScreenHandler)
public class ModScreenHandlers {

    // Registro de manejadores de pantalla usando la API Extendida de Fabric (ideal para hornos y contenedores)
    public static final ScreenHandlerType<MiScreenHandler> MI_PANTALLA =
            register("mi_pantalla", new ExtendedScreenHandlerType<>(MiScreenHandler::new));

    // Método auxiliar con tipos genéricos explícitos (<T extends ScreenHandler>) para evitar fallos de inferencia en Java
    private static <T extends ScreenHandler> ScreenHandlerType<T> register(String name, ScreenHandlerType<T> type) {
        return Registry.register(Registries.SCREEN_HANDLER, new Identifier("modrealista", name), type);
    }

    public static void registerAllScreenHandlers() {
        // Se llama en la inicialización principal de tu mod (ModRealista.java)
    }
}