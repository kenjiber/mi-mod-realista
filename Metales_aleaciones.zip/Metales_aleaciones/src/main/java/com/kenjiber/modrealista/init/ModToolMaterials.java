package com.kenjiber.modrealista.init;

import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;
import java.util.function.Supplier;

public enum ModToolMaterials implements ToolMaterial {
    // Define aquí tus materiales con sus estadísticas:
    // (nivelDeMinado, durabilidad, velocidadMinado, dañoAtaque, encantabilidad, ingredienteReparacion)
    ACERO(2, 600, 7.0F, 2.5F, 14, () -> Ingredient.ofItems(ModItems.INGOTE_ACERO)),
    TITANIO(3, 1200, 8.0F, 3.0F, 15, () -> Ingredient.ofItems(ModItems.INGOTE_TITANIO)),
    TUNGSTENO(4, 2000, 9.0F, 4.0F, 10, () -> Ingredient.ofItems(ModItems.INGOTE_TUNGSTENO));

    private final int miningLevel;
    private final int itemDurability;
    private final float miningSpeed;
    private final float attackDamage;
    private final int enchantability;
    private final Supplier<Ingredient> repairIngredient;

    ModToolMaterials(int miningLevel, int itemDurability, float miningSpeed, float attackDamage, int enchantability, Supplier<Ingredient> repairIngredient) {
        this.miningLevel = miningLevel;
        this.itemDurability = itemDurability;
        this.miningSpeed = miningSpeed;
        this.attackDamage = attackDamage;
        this.enchantability = enchantability;
        this.repairIngredient = repairIngredient;
    }

    @Override
    public int getDurability() {
        return this.itemDurability;
    }

    @Override
    public float getMiningSpeedMultiplier() {
        return this.miningSpeed;
    }

    @Override
    public float getAttackDamage() {
        return this.attackDamage;
    }

    @Override
    public int getMiningLevel() {
        return this.miningLevel;
    }

    @Override
    public int getEnchantability() {
        return this.enchantability;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return this.repairIngredient.get();
    }
}