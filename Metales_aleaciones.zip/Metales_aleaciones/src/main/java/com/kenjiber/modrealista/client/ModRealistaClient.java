package com.kenjiber.modrealista.client;

import com.kenjiber.modrealista.init.ModScreenHandlers;
import com.kenjiber.modrealista.screen.AltoHornoScreen;
import com.kenjiber.modrealista.screen.FusionFurnaceScreen;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.gui.screen.ingame.HandledScreens;

/**
 * Todo lo que solo existe en el cliente (pantallas, renderizado) va aquí,
 * nunca en ModRealista.java — si se registra una Screen en el servidor
 * dedicado, este crashea al arrancar.
 */
public class ModRealistaClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		HandledScreens.register(ModScreenHandlers.ALTO_HORNO, AltoHornoScreen::new);
		HandledScreens.register(ModScreenHandlers.HORNO_DE_FUSION, FusionFurnaceScreen::new);
	}
}
