package com.kenjiber.modrealista.block.entity;

import com.kenjiber.modrealista.init.ModItems;
import com.kenjiber.modrealista.recipe.ModFusionRecipes;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Horno de Fusión: combina 2 lingotes/ingredientes (slots 0 y 1) + un Molde
 * en el slot 2 (se pide pero NO se consume) + combustible en el slot 3,
 * y produce 1 lingote de aleación en el slot 4.
 * <p>
 * La tabla de "qué combina con qué" vive en {@link ModFusionRecipes}, no
 * aquí — este archivo solo mueve items de un slot a otro según lo que esa
 * tabla diga.
 */
public class FusionFurnaceBlockEntity extends BlockEntity implements Inventory, net.minecraft.screen.NamedScreenHandlerFactory {

	public static final int SLOT_ENTRADA_1 = 0;
	public static final int SLOT_ENTRADA_2 = 1;
	public static final int SLOT_MOLDE = 2;
	public static final int SLOT_COMBUSTIBLE = 3;
	public static final int SLOT_SALIDA = 4;
	private static final int TAMANO_INVENTARIO = 5;

	private final DefaultedList<ItemStack> inventario = DefaultedList.ofSize(TAMANO_INVENTARIO, ItemStack.EMPTY);
	private final int tier; // 1 = Básico, 2 = Avanzado

	private int progresoFundido = 0;
	private int tiempoTotalNecesario = 200;
	private int combustibleRestante = 0;
	private int combustibleMaximoActual = 0;

	public FusionFurnaceBlockEntity(BlockPos pos, BlockState state, int tier) {
		super(tier == 1
				? com.kenjiber.modrealista.init.ModBlockEntities.HORNO_FUSION_BASICO_ENTITY
				: com.kenjiber.modrealista.init.ModBlockEntities.HORNO_FUSION_AVANZADO_ENTITY,
				pos, state);
		this.tier = tier;
	}

	public int getTier() {
		return tier;
	}

	public boolean estaQuemando() {
		return combustibleRestante > 0;
	}

	/** Progreso 0-1 para la barra de la GUI (cuando se implemente el Screen). */
	public float getProgreso() {
		return tiempoTotalNecesario == 0 ? 0 : (float) progresoFundido / tiempoTotalNecesario;
	}

	public float getCombustibleProgreso() {
		return combustibleMaximoActual == 0 ? 0 : (float) combustibleRestante / combustibleMaximoActual;
	}

	// --- Ticker estático, se registra en ModBlockEntities ---
	public static <T extends BlockEntity> void tick(World world, BlockPos pos, BlockState state, T be) {
		if (!(be instanceof FusionFurnaceBlockEntity horno)) return;
		if (world.isClient) return;
		horno.tickServidor((ServerWorld) world);
	}

	private void tickServidor(ServerWorld world) {
		ModFusionRecipes.Aleacion receta = ModFusionRecipes.buscarAleacion(
				stackOf(SLOT_ENTRADA_1), inventario.get(SLOT_ENTRADA_1).getCount(),
				stackOf(SLOT_ENTRADA_2), inventario.get(SLOT_ENTRADA_2).getCount(),
				tier);

		boolean tieneMolde = !inventario.get(SLOT_MOLDE).isEmpty()
				&& inventario.get(SLOT_MOLDE).isOf(ModItems.molde_de_fundicion);

		boolean puedeProcesar = receta != null && tieneMolde
				&& (inventario.get(SLOT_SALIDA).isEmpty()
					|| (inventario.get(SLOT_SALIDA).isOf(receta.resultado())
						&& inventario.get(SLOT_SALIDA).getCount() < inventario.get(SLOT_SALIDA).getMaxCount()));

		if (!puedeProcesar) {
			// Se resetea el progreso si ya no hay nada válido que procesar.
			if (combustibleRestante <= 0) progresoFundido = 0;
			markDirty();
			return;
		}

		// Consumir combustible si no está ardiendo.
		if (combustibleRestante <= 0) {
			ItemStack combustible = inventario.get(SLOT_COMBUSTIBLE);
			int valor = getValorCombustible(combustible);
			if (valor > 0) {
				combustibleRestante = valor;
				combustibleMaximoActual = valor;
				combustible.decrement(1);
			}
		}

		if (combustibleRestante > 0) {
			combustibleRestante--;
			tiempoTotalNecesario = receta.tiempoTicks();
			progresoFundido++;
			if (progresoFundido >= tiempoTotalNecesario) {
				progresoFundido = 0;
				boolean directo = receta.ingrediente1() == inventario.get(SLOT_ENTRADA_1).getItem();
				int consumo1 = directo ? receta.cantidad1() : receta.cantidad2();
				int consumo2 = directo ? receta.cantidad2() : receta.cantidad1();
				inventario.get(SLOT_ENTRADA_1).decrement(consumo1);
				inventario.get(SLOT_ENTRADA_2).decrement(consumo2);
				if (inventario.get(SLOT_SALIDA).isEmpty()) {
					inventario.set(SLOT_SALIDA, new ItemStack(receta.resultado()));
				} else {
					inventario.get(SLOT_SALIDA).increment(1);
				}
			}
		}
		markDirty();
	}

	/** Ticks de combustión por unidad de combustible; usa el mapa vanilla como base. */
	private int getValorCombustible(ItemStack stack) {
		int valor = com.kenjiber.modrealista.util.ModFuel.tiempoDeQuemado(stack);
		if (valor == 0) return 0;
		// El Horno Avanzado se calienta más rápido con lava/blaze: se le da el doble de ticks útiles.
		return tier == 2 ? valor : valor / 2 + 1;
	}

	private Item stackOf(int slot) {
		return inventario.get(slot).getItem();
	}

	// --- Implementación mínima de Inventory ---

	@Override
	public int size() {
		return TAMANO_INVENTARIO;
	}

	@Override
	public boolean isEmpty() {
		return inventario.stream().allMatch(ItemStack::isEmpty);
	}

	@Override
	public ItemStack getStack(int slot) {
		return inventario.get(slot);
	}

	@Override
	public ItemStack removeStack(int slot, int amount) {
		return net.minecraft.inventory.Inventories.splitStack(inventario, slot, amount);
	}

	@Override
	public ItemStack removeStack(int slot) {
		return net.minecraft.inventory.Inventories.removeStack(inventario, slot);
	}

	@Override
	public void setStack(int slot, ItemStack stack) {
		inventario.set(slot, stack);
	}

	@Override
	public void markDirty() {
		if (world != null) world.updateListeners(pos, getCachedState(), getCachedState(), 3);
	}

	@Override
	public boolean canPlayerUse(PlayerEntity player) {
		return world != null && world.getBlockEntity(pos) == this
				&& player.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 64.0;
	}

	@Override
	public void clear() {
		inventario.clear();
	}

	@Override
	public net.minecraft.text.Text getDisplayName() {
		return net.minecraft.text.Text.translatable(tier == 1
				? "block.modrealista.horno_de_fusion_basico"
				: "block.modrealista.horno_de_fusion_avanzado");
	}

	@Override
	public net.minecraft.screen.ScreenHandler createMenu(int syncId, net.minecraft.entity.player.PlayerInventory playerInventory, PlayerEntity player) {
		return new com.kenjiber.modrealista.menu.FusionFurnaceScreenHandler(syncId, playerInventory, this);
	}
}
