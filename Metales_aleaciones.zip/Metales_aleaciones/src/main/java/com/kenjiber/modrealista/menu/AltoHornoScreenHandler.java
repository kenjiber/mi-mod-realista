package com.kenjiber.modrealista.menu;

import com.kenjiber.modrealista.init.ModItems;
import com.kenjiber.modrealista.init.ModScreenHandlers;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import com.kenjiber.modrealista.util.ModFuel;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;

/**
 * Igual que el ScreenHandler del Alto Horno vainilla, pero con una 4ta
 * ranura extra para el Molde Reutilizable (que no se consume).
 * <p>
 * Slots 0-3 = horno (fragmentos, molde, combustible, salida); 4+ =
 * inventario del jugador (27 + 9 de hotbar), igual que cualquier container
 * vainilla.
 */
public class AltoHornoScreenHandler extends ScreenHandler {

	public static final int SLOT_FRAGMENTOS = 0;
	public static final int SLOT_MOLDE = 1;
	public static final int SLOT_COMBUSTIBLE = 2;
	public static final int SLOT_SALIDA = 3;

	private final Inventory inventarioHorno;

	// Constructor "cliente": se llama al abrir la pantalla vía openHandledScreen.
	public AltoHornoScreenHandler(int syncId, PlayerInventory playerInventory) {
		this(syncId, playerInventory, new net.minecraft.inventory.SimpleInventory(4));
	}

	public AltoHornoScreenHandler(int syncId, PlayerInventory playerInventory, Inventory inventarioHorno) {
		super(ModScreenHandlers.ALTO_HORNO, syncId);
		this.inventarioHorno = inventarioHorno;
		checkSize(inventarioHorno, 4);

		// Ranura de fragmentos (input tipo "mineral").
		this.addSlot(new Slot(inventarioHorno, SLOT_FRAGMENTOS, 56, 17));
		// Ranura del molde: solo acepta molde_de_fundicion.
		this.addSlot(new Slot(inventarioHorno, SLOT_MOLDE, 26, 35) {
			@Override
			public boolean canInsert(ItemStack stack) {
				return stack.isOf(ModItems.molde_de_fundicion);
			}
		});
		// Ranura de combustible: usa el mismo filtro que el horno vainilla.
		this.addSlot(new Slot(inventarioHorno, SLOT_COMBUSTIBLE, 56, 53) {
			@Override
			public boolean canInsert(ItemStack stack) {
				return ModFuel.esCombustible(stack);
			}
		});
		// Ranura de salida: solo se puede extraer, no colocar directamente.
		this.addSlot(new Slot(inventarioHorno, SLOT_SALIDA, 116, 35) {
			@Override
			public boolean canInsert(ItemStack stack) {
				return false;
			}
		});

		// Inventario del jugador (27 slots principales + 9 de hotbar).
		for (int fila = 0; fila < 3; fila++) {
			for (int col = 0; col < 9; col++) {
				this.addSlot(new Slot(playerInventory, col + fila * 9 + 9, 8 + col * 18, 84 + fila * 18));
			}
		}
		for (int col = 0; col < 9; col++) {
			this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 142));
		}
	}

	@Override
	public boolean canUse(PlayerEntity player) {
		return inventarioHorno.canPlayerUse(player);
	}

	@Override
	public ItemStack quickMove(PlayerEntity player, int index) {
		// Implementación mínima de shift-click; suficiente para jugar,
		// se puede refinar luego (mover automáticamente al slot "correcto").
		Slot slot = this.slots.get(index);
		if (slot == null || !slot.hasStack()) return ItemStack.EMPTY;
		ItemStack original = slot.getStack();
		ItemStack copia = original.copy();
		if (index < 4) {
			if (!this.insertItem(original, 4, this.slots.size(), true)) return ItemStack.EMPTY;
		} else {
			if (!this.insertItem(original, 0, 4, false)) return ItemStack.EMPTY;
		}
		if (original.isEmpty()) slot.setStack(ItemStack.EMPTY); else slot.markDirty();
		return copia;
	}
}
