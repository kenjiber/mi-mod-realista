package com.kenjiber.modrealista.init;

import com.kenjiber.modrealista.block.AltoHornoBlock;
import com.kenjiber.modrealista.block.FusionFurnaceBlock;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.ExperienceDroppingBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.intprovider.UniformIntProvider;

public class ModBlocks {

    // Bloques especiales (Hornos)
    public static final Block ALTO_HORNO_DE_COBRE = registerBlock("alto_horno_de_cobre",
            new AltoHornoBlock(AbstractBlock.Settings.copy(Blocks.IRON_BLOCK).requiresTool()));

    public static final Block HORNO_DE_FUSION_BASICO = registerBlock("horno_de_fusion_basico",
            new FusionFurnaceBlock(AbstractBlock.Settings.copy(Blocks.IRON_BLOCK).requiresTool()));

    public static final Block HORNO_DE_FUSION_AVANZADO = registerBlock("horno_de_fusion_avanzado",
            new FusionFurnaceBlock(AbstractBlock.Settings.copy(Blocks.NETHERITE_BLOCK).requiresTool()));

    // Bloques de minerales con experiencia (usa UniformIntProvider.create)
    public static final Block MINERAL_EJEMPLO = registerBlock("mineral_ejemplo",
            new ExperienceDroppingBlock(UniformIntProvider.create(2, 5),
                    AbstractBlock.Settings.copy(Blocks.STONE).requiresTool()));

    public static final Block MINERAL_DEEPSLATE_EJEMPLO = registerBlock("mineral_deepslate_ejemplo",
            new ExperienceDroppingBlock(UniformIntProvider.create(3, 7),
                    AbstractBlock.Settings.copy(Blocks.DEEPSLATE).requiresTool()));

    // Método auxiliar para registrar un bloque y su BlockItem correspondiente
    private static Block registerBlock(String name, Block block) {
        registerBlockItem(name, block);
        return Registry.register(Registries.BLOCK, Identifier.of("modrealista", name), block);
    }

    // Método auxiliar para registrar el ítem del bloque
    private static Item registerBlockItem(String name, Block block) {
        return Registry.register(Registries.ITEM, Identifier.of("modrealista", name),
                new BlockItem(block, new Item.Settings()));
    }

    // Método principal de registro que es llamado desde ModRealista.java
    public static void registrarTodo() {
        // Inicializa la carga de las variables estáticas de la clase
    }
}