package com.kenjiber.modrealista.init;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.ExperienceDroppingBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
// 1. IMPORTANTE: Esta importación es necesaria para los minerales que dan experiencia
import net.minecraft.util.math.intprovider.UniformIntProvider;

public class ModBlocks {

    // Bloques estándar (sin experiencia)
    public static final Block BLOQUE_ACERO = registerBlock("bloque_acero",
            new Block(AbstractBlock.Settings.copy(Blocks.IRON_BLOCK)));

    // 2. CORRECCIÓN CLAVE (Líneas 54 y 60):
    // El orden correcto es: UniformIntProvider.of(min, max), Settings
    public static final Block MINERAL_TITANIO = registerBlock("mineral_titanio",
            new ExperienceDroppingBlock(
                    UniformIntProvider.of(2, 5), // <--- Primero el rango de XP
                    AbstractBlock.Settings.copy(Blocks.STONE_ORE) // <--- Luego las propiedades
            ));

    public static final Block MINERAL_TUNGSTENO = registerBlock("mineral_tungsteno",
            new ExperienceDroppingBlock(
                    UniformIntProvider.of(3, 7), // <--- Primero el rango de XP
                    AbstractBlock.Settings.copy(Blocks.DEEPSLATE_ORE) // <--- Luego las propiedades
            ));

    // Métodos auxiliares para registrar bloques e ítems en el juego
    private static Block registerBlock(String name, Block block) {
        registerBlockItem(name, block);
        return Registry.register(Registries.BLOCK, new Identifier("modrealista", name), block);
    }

    private static Item registerBlockItem(String name, Block block) {
        return Registry.register(Registries.ITEM, new Identifier("modrealista", name),
                new BlockItem(block, new Item.Settings()));
    }

    public static void registerModBlocks() {
        // Se llama en el inicializador principal del mod
    }
}