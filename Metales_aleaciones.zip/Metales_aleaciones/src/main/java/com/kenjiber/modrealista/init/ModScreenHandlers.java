package com.kenjiber.modrealista.init;

import com.kenjiber.modrealista.menu.AltoHornoScreenHandler;
import com.kenjiber.modrealista.menu.FusionFurnaceScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.util.Identifier;

public class ModScreenHandlers {

    // Registro de las variables que solicitan tu cliente y tus pantallas
    public static final ScreenHandlerType<AltoHornoScreenHandler> ALTO_HORNO =
            register("alto_horno", new ExtendedScreenHandlerType<>(AltoHornoScreenHandler::new));

    public static final ScreenHandlerType<FusionFurnaceScreenHandler> HORNO_DE_FUSION =
            register("horno_de_fusion", new ExtendedScreenHandlerType<>(FusionFurnaceScreenHandler::new));

    private static <T extends ScreenHandler> ScreenHandlerType<T> register(String name, ScreenHandlerType<T> type) {
        return Registry.register(Registries.SCREEN_HANDLER, Identifier.of("modrealista", name), type);
    }

    public static void registrarTodo() {
        // Se llama en ModRealista.java para registrar los ScreenHandlers
    }
}