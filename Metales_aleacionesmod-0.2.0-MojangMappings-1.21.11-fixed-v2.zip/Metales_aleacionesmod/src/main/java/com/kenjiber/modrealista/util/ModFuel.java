package com.kenjiber.modrealista.util;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import net.fabricmc.fabric.api.registry.FuelRegistry;

/**
 * Usamos el registro de combustibles de Fabric, que en 1.21.11 expone los mismos
 * tiempos de quemado que usa el sistema de hornos vanilla.
 */
public final class ModFuel {

	private ModFuel() {}


	/** ¿Este ítem sirve como combustible? (mismo criterio que el horno vainilla). */
	public static boolean esCombustible(ItemStack stack) {
		return !stack.isEmpty() && FuelRegistry.INSTANCE.get(stack.getItem()) != null;
	}

	/** Cuántos ticks de quemado da 1 unidad de este ítem como combustible (0 si no aplica). */
	public static int tiempoDeQuemado(ItemStack stack) {
		if (stack.isEmpty()) return 0;
		Integer value = FuelRegistry.INSTANCE.get(stack.getItem());
		return value != null ? value : 0;
	}
}
