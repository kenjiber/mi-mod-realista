package com.kenjiber.modrealista.init;

import com.kenjiber.modrealista.block.entity.AltoHornoBlockEntity;
import com.kenjiber.modrealista.block.entity.FusionFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import java.util.Set;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

public final class ModBlockEntities {

	private ModBlockEntities() {}

	public static BlockEntityType<AltoHornoBlockEntity> ALTO_HORNO_ENTITY;
	public static BlockEntityType<FusionFurnaceBlockEntity> HORNO_FUSION_BASICO_ENTITY;
	public static BlockEntityType<FusionFurnaceBlockEntity> HORNO_FUSION_AVANZADO_ENTITY;

	public static void registrarTodo() {
		ALTO_HORNO_ENTITY = Registry.register(
				BuiltInRegistries.BLOCK_ENTITY_TYPE,
				ResourceKey.create(Registries.BLOCK_ENTITY_TYPE, Identifier.fromNamespaceAndPath(MOD_ID, "alto_horno_de_cobre")),
				new BlockEntityType<>(AltoHornoBlockEntity::new, Set.of(ModBlocks.ALTO_HORNO_DE_COBRE))
		);

		HORNO_FUSION_BASICO_ENTITY = Registry.register(
				BuiltInRegistries.BLOCK_ENTITY_TYPE,
				ResourceKey.create(Registries.BLOCK_ENTITY_TYPE, Identifier.fromNamespaceAndPath(MOD_ID, "horno_fusion_basico")),
				new BlockEntityType<>((pos, state) -> new FusionFurnaceBlockEntity(pos, state, 1), Set.of(ModBlocks.HORNO_DE_FUSION_BASICO))
		);

		HORNO_FUSION_AVANZADO_ENTITY = Registry.register(
				BuiltInRegistries.BLOCK_ENTITY_TYPE,
				ResourceKey.create(Registries.BLOCK_ENTITY_TYPE, Identifier.fromNamespaceAndPath(MOD_ID, "horno_fusion_avanzado")),
				new BlockEntityType<>((pos, state) -> new FusionFurnaceBlockEntity(pos, state, 2), Set.of(ModBlocks.HORNO_DE_FUSION_AVANZADO))
		);
	}
}
