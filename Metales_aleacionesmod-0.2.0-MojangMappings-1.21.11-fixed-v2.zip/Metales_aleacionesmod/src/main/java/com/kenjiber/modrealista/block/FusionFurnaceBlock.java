package com.kenjiber.modrealista.block;

import com.kenjiber.modrealista.block.entity.FusionFurnaceBlockEntity;
import com.kenjiber.modrealista.init.ModBlockEntities;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Containers;

/**
 * Horno de Fusión: bloque con block entity propio que combina DOS lingotes
 * (no uno solo, como el horno vanilla) para crear una aleación.
 * <p>
 * Se usa la misma clase para el Tier 1 (Básico) y Tier 2 (Avanzado); lo único
 * que cambia entre ambos es el {@code tier}, que el BlockEntity usa para
 * filtrar qué recetas de aleación puede procesar.
 */
public class FusionFurnaceBlock extends BaseEntityBlock {

    /** 🔧 NUEVO: expuesto como campo público para que ModBlocks pueda referenciarlo en la luminancia. */
    public static final BooleanProperty LIT = BlockStateProperties.LIT;

    public static final MapCodec<FusionFurnaceBlock> CODEC = RecordCodecBuilder.mapCodec(instance ->
        instance.group(
            BlockBehaviour.propertiesCodec(),
            com.mojang.serialization.Codec.INT.fieldOf("tier").forGetter(block -> block.tier)
        ).apply(instance, FusionFurnaceBlock::new)
    );

    private final int tier; // 1 = Básico (carbón), 2 = Avanzado (blaze/lava)

    public FusionFurnaceBlock(BlockBehaviour.Properties settings, int tier) {
        super(settings);
        this.tier = tier;
        registerDefaultState(getStateDefinition().defaultBlockState().with(LIT, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(LIT);
    }

    public int getTier() {
        return tier;
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return tier == 1
                ? ModBlockEntities.HORNO_FUSION_BASICO_ENTITY.instantiate(pos, state)
                : ModBlockEntities.HORNO_FUSION_AVANZADO_ENTITY.instantiate(pos, state);
    }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return FusionFurnaceBlockEntity::tick;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (level.isClientSide()) return InteractionResult.SUCCESS;
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof MenuProvider factory) {
            player.openMenu(factory);
        }
        return InteractionResult.CONSUME;
    }

    /** Al romperse (y no ser solo un cambio de estado como lit), suelta todo lo que había dentro. */
    @Override
    protected void affectNeighborsAfterRemoval(BlockState state, ServerLevel level, BlockPos pos, boolean moved) {
        if (!moved && level.getBlockEntity(pos) instanceof net.minecraft.world.Container container) {
            Containers.dropContents(level, pos, container);
        }
        super.affectNeighborsAfterRemoval(state, level, pos, moved);
    }
}
