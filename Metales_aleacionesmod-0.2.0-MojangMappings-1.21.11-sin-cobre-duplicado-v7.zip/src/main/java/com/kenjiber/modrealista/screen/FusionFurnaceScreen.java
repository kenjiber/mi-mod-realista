package com.kenjiber.modrealista.screen;

import com.kenjiber.modrealista.ModRealista;
import com.kenjiber.modrealista.menu.FusionFurnaceScreenHandler;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

public class FusionFurnaceScreen extends AbstractContainerScreen<FusionFurnaceScreenHandler> {

	private static final Identifier TEXTURA = Identifier.fromNamespaceAndPath(ModRealista.MOD_ID, "textures/gui/container/horno_de_fusion.png");
	private static final Identifier LLAMA = Identifier.withDefaultNamespace("container/furnace/lit_progress");
	private static final Identifier FLECHA = Identifier.withDefaultNamespace("container/furnace/burn_progress");

	// Coordenadas segun el layout del FusionFurnaceScreenHandler: molde (35,53), combustible (80,53), salida (134,35).
	private static final int LLAMA_X = 80, LLAMA_Y = 36, LLAMA_W = 14, LLAMA_H = 14;
	private static final int FLECHA_X = 103, FLECHA_Y = 34, FLECHA_W = 22, FLECHA_H = 16;

	public FusionFurnaceScreen(FusionFurnaceScreenHandler handler, Inventory inventory, Component title) {
		super(handler, inventory, title);
		this.backgroundWidth = 176;
		this.backgroundHeight = 166;
	}

	@Override
	protected void drawBackground(GuiGraphics context, float delta, int mouseX, int mouseY) {
		int x = (width - backgroundWidth) / 2;
		int y = (height - backgroundHeight) / 2;
		context.drawTexture(RenderPipelines.GUI_TEXTURED, TEXTURA, x, y, 0, 0, backgroundWidth, backgroundHeight, 176, 166);

		float combustible = handler.getCombustibleFraccion();
		int alturaLlama = Math.round(LLAMA_H * combustible);
		if (alturaLlama > 0) {
			context.drawTexture(RenderPipelines.GUI_TEXTURED, LLAMA, x + LLAMA_X, y + LLAMA_Y + (LLAMA_H - alturaLlama),
					0, LLAMA_H - alturaLlama, LLAMA_W, alturaLlama, LLAMA_W, LLAMA_H);
		}

		float progreso = handler.getProgresoFraccion();
		int anchoFlecha = Math.round(FLECHA_W * progreso);
		if (anchoFlecha > 0) {
			context.drawTexture(RenderPipelines.GUI_TEXTURED, FLECHA, x + FLECHA_X, y + FLECHA_Y, 0, 0, anchoFlecha, FLECHA_H, FLECHA_W, FLECHA_H);
		}
	}

	@Override
	public void render(GuiGraphics context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		this.renderTooltip(context, mouseX, mouseY);
	}
}
