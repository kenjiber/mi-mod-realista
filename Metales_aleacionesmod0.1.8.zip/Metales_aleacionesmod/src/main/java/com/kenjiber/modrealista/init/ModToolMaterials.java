private static ToolMaterial crear(ModMetal metal) {
    int encantabilidad = switch (metal) {
        case ORO, ELECTRO -> 22;
        case TITANIO, NETHERITE_TITANIO, NETHERITE_TUNGSTENO -> 15;
        default -> 10;
    };

    TagKey<Block> incorrectBlocks = tagParaNivel(metal.nivelMinado);
    int durability = metal.durabilidadHerramienta;
    float speed = metal.velocidadMinado;
    float attackDamage = metal.danoAtaque;
    int enchantValue = encantabilidad;
    Item lingote = ModItems.LINGOTES.get(metal);

    return new ToolMaterial() {
        @Override
        public TagKey<Block> getInverseTag() {       // ✅ Yarn 1.21.1
            return incorrectBlocks;
        }

        @Override
        public int getDurability() {
            return durability;
        }

        @Override
        public float getMiningSpeedMultiplier() {
            return speed;
        }

        @Override
        public float getAttackDamage() {
            return attackDamage;
        }

        @Override
        public int getEnchantability() {
            return enchantValue;
        }

        @Override
        public Ingredient getRepairIngredient() {
            return Ingredient.ofItems(lingote);
        }
    };
}