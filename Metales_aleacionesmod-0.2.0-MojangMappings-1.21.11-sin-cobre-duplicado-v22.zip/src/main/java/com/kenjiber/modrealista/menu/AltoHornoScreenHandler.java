package com.kenjiber.modrealista.menu;

import com.kenjiber.modrealista.block.entity.AltoHornoBlockEntity;
import com.kenjiber.modrealista.init.ModItems;
import com.kenjiber.modrealista.init.ModScreenHandlers;
import com.kenjiber.modrealista.util.ModFuel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.FuelValues;

/**
 * Igual que el AbstractContainerMenu del Alto Horno vainilla, pero con una 4ta
 * ranura secundaria para el Molde Reutilizable o el lingote de Cobre de la receta de Bronce.
 */
public class AltoHornoScreenHandler extends AbstractContainerMenu {

	public static final int SLOT_FRAGMENTOS = 0;
	public static final int SLOT_MOLDE = 1;
	public static final int SLOT_COMBUSTIBLE = 2;
	public static final int SLOT_SALIDA = 3;

	private final Container inventarioHorno;
	private final ContainerData propiedades;

	public static final int PROP_PROGRESO = 0;
	public static final int PROP_PROGRESO_TOTAL = 1;
	public static final int PROP_COMBUSTIBLE = 2;
	public static final int PROP_COMBUSTIBLE_MAX = 3;

	public AltoHornoScreenHandler(int syncId, Inventory playerInventory, BlockPos pos) {
		super(ModScreenHandlers.ALTO_HORNO, syncId);
		final FuelValues fuelValues = playerInventory.player.level().fuelValues();

		// 🔧 FIX: getLevel() → level()
		BlockEntity be = playerInventory.player.level().getBlockEntity(pos);
		if (be instanceof AltoHornoBlockEntity altoHorno) {
			this.inventarioHorno = altoHorno;
			this.propiedades = new ContainerData() {
				@Override
				public int get(int index) {
					return switch (index) {
						case PROP_PROGRESO -> altoHorno.getProgresoRaw();
						case PROP_PROGRESO_TOTAL -> altoHorno.getTiempoTotalNecesarioRaw();
						case PROP_COMBUSTIBLE -> altoHorno.getCombustibleRestanteRaw();
						case PROP_COMBUSTIBLE_MAX -> altoHorno.getCombustibleMaximoRaw();
						default -> 0;
					};
				}

				@Override
				public void set(int index, int value) {
					switch (index) {
						case PROP_PROGRESO -> altoHorno.setProgresoRaw(value);
						case PROP_PROGRESO_TOTAL -> altoHorno.setTiempoTotalNecesarioRaw(value);
						case PROP_COMBUSTIBLE -> altoHorno.setCombustibleRestanteRaw(value);
						case PROP_COMBUSTIBLE_MAX -> altoHorno.setCombustibleMaximoRaw(value);
					}
				}

				// 🔧 FIX: getContainerSize() → getCount()
				@Override
				public int getCount() {
					return 4;
				}
			};
		} else {
			this.inventarioHorno = new SimpleContainer(4);
			this.propiedades = new SimpleContainerData(4);
		}

		// 🔧 FIX: checkSize() → checkContainerSize()
		checkContainerSize(inventarioHorno, 4);
		this.addDataSlots(propiedades);

		// Ranura de fragmentos (input tipo "mineral").
		this.addSlot(new Slot(inventarioHorno, SLOT_FRAGMENTOS, 56, 17));

		// Ranura secundaria: acepta el molde reutilizable para purificación o 1 lingote de cobre para fabricar bronce.
		// 🔧 FIX: canInsert() → mayPlace()
		this.addSlot(new Slot(inventarioHorno, SLOT_MOLDE, 26, 35) {
			@Override
			public boolean mayPlace(ItemStack stack) {
				return stack.is(ModItems.molde_de_fundicion) || stack.is(net.minecraft.world.item.Items.COPPER_INGOT);
			}
		});

		// Ranura de combustible: usa el mismo filtro que el horno vainilla.
		this.addSlot(new Slot(inventarioHorno, SLOT_COMBUSTIBLE, 56, 53) {
			@Override
			public boolean mayPlace(ItemStack stack) {
				return ModFuel.esCombustible(stack, fuelValues);
			}
		});

		// Ranura de salida: solo se puede extraer, no colocar directamente.
		this.addSlot(new Slot(inventarioHorno, SLOT_SALIDA, 116, 35) {
			@Override
			public boolean mayPlace(ItemStack stack) {
				return false;
			}
		});

		// Inventario del jugador (27 slots principales + 9 de hotbar).
		for (int fila = 0; fila < 3; fila++) {
			for (int col = 0; col < 9; col++) {
				this.addSlot(new Slot(playerInventory, col + fila * 9 + 9, 8 + col * 18, 84 + fila * 18));
			}
		}
		for (int col = 0; col < 9; col++) {
			this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 142));
		}
	}

	// 🔧 FIX: canUse() → stillValid(), Player → Player
	@Override
	public boolean stillValid(Player player) {
		return inventarioHorno.stillValid(player);
	}

	// 🔧 FIX: quickMove() → quickMoveStack(), insertItem() → moveItemStackTo(),
	//          hasStack() → hasItem(), getItem() → getItem(),
	//          setItem() → set(), setChanged() → setChanged()
	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		Slot slot = this.slots.get(index);
		if (slot == null || !slot.hasItem()) return ItemStack.EMPTY;
		ItemStack original = slot.getItem();
		ItemStack copia = original.copy();
		if (index < 4) {
			if (!this.moveItemStackTo(original, 4, this.slots.size(), true)) return ItemStack.EMPTY;
		} else {
			if (!this.moveItemStackTo(original, 0, 4, false)) return ItemStack.EMPTY;
		}
		if (original.isEmpty()) slot.set(ItemStack.EMPTY); else slot.setChanged();
		return copia;
	}

	// --- Helpers para que la pantalla (cliente) dibuje la animación ---
	public float getProgresoFraccion() {
		int total = propiedades.get(PROP_PROGRESO_TOTAL);
		return total <= 0 ? 0f : (float) propiedades.get(PROP_PROGRESO) / total;
	}

	public float getCombustibleFraccion() {
		int max = propiedades.get(PROP_COMBUSTIBLE_MAX);
		return max <= 0 ? 0f : (float) propiedades.get(PROP_COMBUSTIBLE) / max;
	}
}
