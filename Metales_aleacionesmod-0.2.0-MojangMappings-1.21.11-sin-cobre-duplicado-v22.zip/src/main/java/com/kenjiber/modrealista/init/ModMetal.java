package com.kenjiber.modrealista.init;

/**
 * Registro central de todos los metales y aleaciones del mod.
 * <p>
 * En vez de escribir a mano cada Item/ToolMaterial/ArmorMaterial (serían
 * decenas de clases casi idénticas), cada metal se describe una sola vez
 * aquí con sus stats y "flags" de catálogo. ModItems, ModToolMaterials y
 * ModArmorMaterials recorren este enum para registrar todo automáticamente.
 * <p>
 * Los valores numéricos vienen directamente de las tablas de diseño que
 * definiste (picos/espadas y armaduras). Si cambias un número, cámbialo
 * SOLO aquí.
 */
public enum ModMetal {

	// ---- METALES PUROS (tienen mineral/fragmento en el mundo) ----
	COBRE("cobre", Catalogo.SOLO_INGREDIENTE, false, 0,
			180, 4.5f, 5.5f, 1.6f,
			ArmorStats.of(1, 3, 4, 1, 0f, 9)),

	ESTANO("estano", Catalogo.SOLO_INGREDIENTE, false, 0,
			0, 0f, 0f, 0f, ArmorStats.NONE),

	ALUMINIO("aluminio", Catalogo.SET_COMPLETO, false, 1,
			190, 12.0f, 5.0f, 1.6f,
			ArmorStats.of(1, 4, 5, 2, 0f, 15)),

	PLATA("plata", Catalogo.ESPECIAL_ARMA_ESCUDO, false, 2,
			220, 5.5f, 5.5f, 1.6f, ArmorStats.NONE),

	HIERRO("hierro", Catalogo.SET_COMPLETO, false, 2,
			250, 6.0f, 6.0f, 1.6f,
			ArmorStats.of(2, 5, 6, 2, 0f, 9)),

	ORO("oro", Catalogo.SET_COMPLETO, false, 0,
			32, 12.0f, 4.0f, 1.6f,
			ArmorStats.of(1, 3, 5, 2, 0f, 25)),

	TITANIO("titanio", Catalogo.SET_COMPLETO, false, 3,
			1561, 9.0f, 8.0f, 1.6f,
			ArmorStats.of(3, 6, 8, 3, 2f, 15)),

	TUNGSTENO("tungsteno", Catalogo.ESPECIAL_SOLO_HERRAMIENTA, false, 3,
			1800, 8.0f, 9.0f, 1.2f, ArmorStats.NONE),

	// ---- ALEACIONES (se funden en el Horno de Fusión) ----
	BRONCE("bronce", Catalogo.SET_COMPLETO, true, 2,
			250, 6.0f, 6.0f, 1.6f,
			ArmorStats.of(2, 5, 6, 2, 0f, 12)),

	DURALUMINIO("duraluminio", Catalogo.ESPECIAL_LIGERO, true, 1,
			350, 7.5f, 6.0f, 1.9f, ArmorStats.NONE),

	ELECTRO("electro", Catalogo.ESPECIAL_MAGICO, true, 2,
			250, 12.0f, 6.5f, 1.8f, ArmorStats.NONE),

	ACERO("acero", Catalogo.SET_COMPLETO, true, 3,
			650, 7.5f, 7.0f, 1.6f,
			ArmorStats.of(3, 6, 7, 3, 1f, 14)),

	// Tier 5: se craftean con Mesa de Herrería (Netherite vanilla + lingote), no en mesa normal.
	NETHERITE_TITANIO("netherite_titanio", Catalogo.SET_COMPLETO_HERRERIA, true, 4,
			2500, 11.0f, 9.5f, 1.7f,
			ArmorStats.of(4, 7, 9, 4, 3f, 20)),

	NETHERITE_TUNGSTENO("netherite_tungsteno", Catalogo.SET_COMPLETO_HERRERIA, true, 4,
			3200, 10.0f, 11.0f, 1.1f,
			ArmorStats.of(4, 7, 9, 4, 3f, 20));

	/** Qué paquete de objetos genera este material. */
	public enum Catalogo {
		/** Pico, hacha, pala, espada y armadura completa, crafteo normal. */
		SET_COMPLETO,
		/** Igual que SET_COMPLETO pero se craftea en Mesa de Herrería (Tier 5). */
		SET_COMPLETO_HERRERIA,
		/** Sin armadura ni objetos: solo ingrediente de otra aleación (Estaño). */
		SOLO_INGREDIENTE,
		/** Espada + Escudo + Pico, sin armadura (Plata). */
		ESPECIAL_ARMA_ESCUDO,
		/** Pico + Hacha/Maza pesada, sin armadura (Tungsteno puro). */
		ESPECIAL_SOLO_HERRAMIENTA,
		/** Pico + Hacha + Espada "ligeros", sin armadura (Duraluminio). */
		ESPECIAL_LIGERO,
		/** Pico + Hacha + Espada "mágicos", sin armadura (Electro). */
		ESPECIAL_MAGICO
	}

	public final String id;
	public final Catalogo catalogo;
	public final boolean esAleacion;
	public final int nivelMinado; // 0=madera/piedra equivalente ... 4=netherite
	public final int durabilidadHerramienta;
	public final float velocidadMinado;
	public final float danoAtaque;
	public final float velocidadAtaque;
	public final ArmorStats armadura;

	ModMetal(String id, Catalogo catalogo, boolean esAleacion, int nivelMinado,
			 int durabilidadHerramienta, float velocidadMinado, float danoAtaque, float velocidadAtaque,
			 ArmorStats armadura) {
		this.id = id;
		this.catalogo = catalogo;
		this.esAleacion = esAleacion;
		this.nivelMinado = nivelMinado;
		this.durabilidadHerramienta = durabilidadHerramienta;
		this.velocidadMinado = velocidadMinado;
		this.danoAtaque = danoAtaque;
		this.velocidadAtaque = velocidadAtaque;
		this.armadura = armadura;
	}

	public boolean tieneArmadura() {
		return catalogo == Catalogo.SET_COMPLETO || catalogo == Catalogo.SET_COMPLETO_HERRERIA;
	}

	public boolean tieneSetCompletoDeHerramientas() {
		return tieneArmadura();
	}

	public boolean tieneMineralEnElMundo() {
		// Las aleaciones no se minan: se funden en el Horno de Fusión a partir
		// de los lingotes de sus metales componentes.
		return this != COBRE && !esAleacion;
	}

	/**
	 * Hierro y Oro reutilizan el lingote y la mena VAINILLA (no crean lingote
	 * ni bloque de mena propios) — solo se les da un fragmento_crudo propio
	 * vía loot table override. Cobre también reutiliza el lingote vanilla y, al igual que hierro/oro,
	 * no registra objetos propios de equipo ni mena en el mundo.
	 */
	public boolean esVanilla() {
		return this == HIERRO || this == ORO || this == COBRE;
	}

	/** Puntos de defensa por pieza (bota, pantalón, pechera, casco) + tenacidad + durabilidad base. */
	public static final class ArmorStats {
		public static final ArmorStats NONE = new ArmorStats(0, 0, 0, 0, 0f, 0);

		public final int botas, pantalones, pechera, casco;
		public final float tenacidad;
		public final int durabilidadBase; // multiplicador estilo vanilla (se multiplica x11/x16 según pieza)

		private ArmorStats(int botas, int pantalones, int pechera, int casco, float tenacidad, int durabilidadBase) {
			this.botas = botas;
			this.pantalones = pantalones;
			this.pechera = pechera;
			this.casco = casco;
			this.tenacidad = tenacidad;
			this.durabilidadBase = durabilidadBase;
		}

		public static ArmorStats of(int botas, int pantalones, int pechera, int casco, float tenacidad, int durabilidadBase) {
			return new ArmorStats(botas, pantalones, pechera, casco, tenacidad, durabilidadBase);
		}
	}
}
