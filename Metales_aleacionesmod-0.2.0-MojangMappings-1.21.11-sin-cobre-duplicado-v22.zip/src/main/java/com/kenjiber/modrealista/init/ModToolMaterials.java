package com.kenjiber.modrealista.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.Identifier;

import java.util.EnumMap;
import java.util.Map;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

/**
 * ============================== ATENCION (1.21.11) ==============================
 * Desde 1.21.11, ToolMaterial ya NO es una interfaz (como en 1.21.1) sino un
 * RECORD con constructor directo, y ahora exige un 6to parametro: el TagKey<Item>
 * de items que sirven para repararlo en la mesa de herreria/yunque (antes era
 * un Ingredient calculado en caliente). Usamos los tags ya creados en
 * data/modrealista/tags/item/repair/<metal>.json para esto.
 * ==================================================================================
 */
public final class ModToolMaterials {

	private ModToolMaterials() {}

	private static final Map<ModMetal, ToolMaterial> CACHE = new EnumMap<>(ModMetal.class);

	private static TagKey<Block> tagParaNivel(int nivel) {
		return switch (nivel) {
			case 0 -> BlockTags.INCORRECT_FOR_WOODEN_TOOL;
			case 1 -> BlockTags.INCORRECT_FOR_STONE_TOOL;
			case 2 -> BlockTags.INCORRECT_FOR_IRON_TOOL;
			case 3 -> BlockTags.INCORRECT_FOR_DIAMOND_TOOL;
			default -> BlockTags.INCORRECT_FOR_NETHERITE_TOOL;
		};
	}

	/** Tag de reparacion ya generado en data/modrealista/tags/item/repair/<metal>.json */
	public static TagKey<Item> tagDeReparacion(ModMetal metal) {
		return TagKey.create(net.minecraft.core.registries.Registries.ITEM, Identifier.fromNamespaceAndPath(MOD_ID, "repair/" + metal.id));
	}

	public static ToolMaterial get(ModMetal metal) {
		return CACHE.computeIfAbsent(metal, ModToolMaterials::crear);
	}

	private static ToolMaterial crear(ModMetal metal) {
		int encantabilidad = switch (metal) {
			case ORO, ELECTRO -> 22;
			case TITANIO, NETHERITE_TITANIO, NETHERITE_TUNGSTENO -> 15;
			default -> 10;
		};

		// IMPORTANTE: desde 1.21.11, el daño total de un arma = 1 (base) +
		// este attackDamageBonus + el "bono de tipo" (espada=3, hacha=3, pico=1,
		// pala=1.5) que se pasa por separado en Item.Properties#sword()/axe()/etc.
		// Restamos 4 aqui para que el daño de la ESPADA (nuestra referencia de
		// diseño) termine coincidiendo exactamente con metal.danoAtaque.
		float attackDamageBonus = metal.danoAtaque - 4.0f;

		return new ToolMaterial(
				tagParaNivel(metal.nivelMinado),
				metal.durabilidadHerramienta,
				metal.velocidadMinado,
				attackDamageBonus,
				encantabilidad,
				tagDeReparacion(metal)
		);
	}
}
