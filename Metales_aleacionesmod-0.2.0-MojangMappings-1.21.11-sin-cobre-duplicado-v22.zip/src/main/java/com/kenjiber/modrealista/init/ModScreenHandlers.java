package com.kenjiber.modrealista.init;

import com.kenjiber.modrealista.menu.AltoHornoScreenHandler;
import com.kenjiber.modrealista.menu.FusionFurnaceScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.resources.Identifier;
import net.minecraft.core.BlockPos;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

public final class ModScreenHandlers {

	private ModScreenHandlers() {}

	public static MenuType<AltoHornoScreenHandler> ALTO_HORNO;
	public static MenuType<FusionFurnaceScreenHandler> HORNO_DE_FUSION;

	public static void registrarTodo() {
		ALTO_HORNO = Registry.register(
				BuiltInRegistries.MENU,
				ResourceKey.create(Registries.MENU, Identifier.fromNamespaceAndPath(MOD_ID, "alto_horno_de_cobre")),
				new ExtendedScreenHandlerType<>(AltoHornoScreenHandler::new, BlockPos.STREAM_CODEC)
		);

		HORNO_DE_FUSION = Registry.register(
				BuiltInRegistries.MENU,
				ResourceKey.create(Registries.MENU, Identifier.fromNamespaceAndPath(MOD_ID, "horno_de_fusion")),
				new ExtendedScreenHandlerType<>(FusionFurnaceScreenHandler::new, BlockPos.STREAM_CODEC)
		);
	}
}
