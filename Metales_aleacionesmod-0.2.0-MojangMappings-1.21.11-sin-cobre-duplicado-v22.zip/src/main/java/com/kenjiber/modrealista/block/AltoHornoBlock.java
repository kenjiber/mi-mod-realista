package com.kenjiber.modrealista.block;

import com.kenjiber.modrealista.block.entity.AltoHornoBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Containers;

/** Alto Horno de Cobre: purifica fragmentos crudos en lingotes puros (ver AltoHornoBlockEntity). */
public class AltoHornoBlock extends BaseEntityBlock {

    /** 🔧 NUEVO: expuesto como campo público para que ModBlocks pueda referenciarlo en la luminancia. */
    public static final BooleanProperty LIT = BlockStateProperties.LIT;

    public AltoHornoBlock(BlockBehaviour.Properties settings) {
        super(settings);
        // Por defecto se coloca apagado (lit=false); AltoHornoBlockEntity
        // cambia esta propiedad sola cuando el horno tiene combustible ardiendo.
        registerDefaultState(this.stateDefinition.any().setValue(LIT, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(LIT);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return MapCodec.unit(this);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new AltoHornoBlockEntity(pos, state);
    }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return AltoHornoBlockEntity::tick;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (level.isClientSide()) return InteractionResult.SUCCESS;
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof MenuProvider factory) {
            player.openMenu(factory);
        }
        return InteractionResult.CONSUME;
    }

    /** Al romperse (y no ser solo un cambio de estado como lit), suelta todo lo que había dentro. */
    @Override
    protected void affectNeighborsAfterRemoval(BlockState state, ServerLevel level, BlockPos pos, boolean moved) {
        if (!moved && level.getBlockEntity(pos) instanceof net.minecraft.world.Container container) {
            Containers.dropContents(level, pos, container);
        }
        super.affectNeighborsAfterRemoval(state, level, pos, moved);
    }
}
