# Mod Realista — v21

Cambios de esta versión:
- Molde de fundición: durabilidad de 15 usos. Se consume 1 uso por cada lingote producido en el Alto Horno de Cobre y en los Hornos de Fusión. El bronce del Alto Horno no usa molde.
- Purificación del Alto Horno: ahora usa 1 fragmento por lingote para hierro, plata, oro, titanio y tungsteno. La receta especial de bronce mantiene 3 estaño + 1 cobre y no usa molde.
- Añadido escudo de cobre: ShieldItem con 168 de durabilidad (mitad de 336 del escudo vanilla), receta .C./CWC/.C., donde C=cobre y W=cualquier tablón de madera.
- Añadida textura/modelo/item definition del escudo de cobre.
- Escudo de cobre añadido al grupo creativo de Metalurgia.
- Se conserva la progresión anterior de minería, aleaciones y aluminio.
