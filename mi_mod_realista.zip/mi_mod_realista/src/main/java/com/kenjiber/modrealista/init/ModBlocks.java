package com.kenjiber.modrealista.init;

import com.kenjiber.modrealista.block.AltoHornoBlock;
import com.kenjiber.modrealista.block.FusionFurnaceBlock;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

public final class ModBlocks {

	private ModBlocks() {}

	public static Block ALTO_HORNO_DE_COBRE;
	public static Block HORNO_DE_FUSION_BASICO;
	public static Block HORNO_DE_FUSION_AVANZADO;

	/** Solo los 8 metales puros tienen mena en el mundo (las aleaciones no). */
	public static final java.util.Map<ModMetal, Block> MENAS = new java.util.EnumMap<>(ModMetal.class);
	public static final java.util.Map<ModMetal, Block> MENAS_PIZARRA_PROFUNDA = new java.util.EnumMap<>(ModMetal.class);

	public static void registrarTodo() {
		ALTO_HORNO_DE_COBRE = registrarConItem("alto_horno_de_cobre",
				new AltoHornoBlock(AbstractBlock.Settings.create()
						.mapColor(MapColor.TERRACOTTA_ORANGE)
						.strength(3.5f, 6.0f)));

		HORNO_DE_FUSION_BASICO = registrarConItem("horno_de_fusion_basico",
				new FusionFurnaceBlock(AbstractBlock.Settings.create()
						.mapColor(MapColor.TERRACOTTA_ORANGE)
						.strength(4.0f, 8.0f)
						.luminance(state -> 0), 1));

		HORNO_DE_FUSION_AVANZADO = registrarConItem("horno_de_fusion_avanzado",
				new FusionFurnaceBlock(AbstractBlock.Settings.create()
						.mapColor(MapColor.STONE_GRAY)
						.strength(5.0f, 10.0f)
						.luminance(state -> 3), 2));

		for (ModMetal metal : ModMetal.values()) {
			if (!metal.tieneMineralEnElMundo()) continue;

			// Dureza/nivel de picado aproximado según el tier de minado de ModMetal.
			float dureza = 3.0f + metal.nivelMinado * 1.5f;
			Block mena = new net.minecraft.block.ExperienceDroppingBlock(
					AbstractBlock.Settings.create().mapColor(MapColor.STONE_GRAY)
							.strength(dureza, dureza * 1.5f).requiresTool(),
					net.minecraft.util.math.intprovider.UniformIntProvider.create(0, 1 + metal.nivelMinado));
			MENAS.put(metal, registrarConItem("mena_" + metal.id, mena));

			Block menaDeepslate = new net.minecraft.block.ExperienceDroppingBlock(
					AbstractBlock.Settings.create().mapColor(MapColor.DEEPSLATE_GRAY)
							.strength(dureza + 1.5f, dureza * 1.5f + 1.5f).requiresTool(),
					net.minecraft.util.math.intprovider.UniformIntProvider.create(0, 1 + metal.nivelMinado));
			MENAS_PIZARRA_PROFUNDA.put(metal, registrarConItem("mena_" + metal.id + "_pizarra_profunda", menaDeepslate));
		}
	}

	private static Block registrarConItem(String path, Block block) {
		Identifier id = Identifier.of(MOD_ID, path);
		Block registrado = Registries.BLOCK.add(RegistryKey.of(RegistryKeys.BLOCK, id), block);
		Registries.ITEM.add(RegistryKey.of(RegistryKeys.ITEM, id),
				new BlockItem(registrado, new Item.Settings()));
		return registrado;
	}
}
