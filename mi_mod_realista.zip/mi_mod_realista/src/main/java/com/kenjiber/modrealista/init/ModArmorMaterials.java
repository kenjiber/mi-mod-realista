package com.kenjiber.modrealista.init;

import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ArmorItem;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

/**
 * ============================== ¡ATENCION! ==============================
 * Este es el archivo con mas probabilidad de necesitar un ajuste manual.
 * La firma de ArmorMaterial (constructor, si se registra por Registry o por
 * constante estatica, el nombre de sus campos) ha cambiado varias veces
 * entre 1.20.5 y 1.21.x. Lo de abajo representa la ESTRUCTURA de datos
 * correcta (defensa por pieza, tenacidad, durabilidad, encantabilidad,
 * sonido, item de reparacion) tal como la definiste en tu tabla, pero antes
 * de compilar abre una clase vanilla real que implemente ArmorMaterial
 * (Ctrl+Click en "ArmorMaterial" con las fuentes generadas por
 * `gradlew genSources`) y ajusta el constructor si Minecraft lo cambio.
 * ==========================================================================
 */
public final class ModArmorMaterials {

	private ModArmorMaterials() {}

	private static final Map<ModMetal, RegistryEntry<ArmorMaterial>> CACHE = new EnumMap<>(ModMetal.class);

	public static RegistryEntry<ArmorMaterial> get(ModMetal metal) {
		return CACHE.computeIfAbsent(metal, ModArmorMaterials::crear);
	}

	private static int encantabilidad(ModMetal metal) {
		return switch (metal) {
			case ORO -> 25;
			case TITANIO, NETHERITE_TITANIO, NETHERITE_TUNGSTENO -> 15;
			default -> 9;
		};
	}

	private static SoundEvent sonidoEquipar(ModMetal metal) {
		return switch (metal) {
			case ORO -> SoundEvents.ITEM_ARMOR_EQUIP_GOLD;
			case NETHERITE_TITANIO, NETHERITE_TUNGSTENO -> SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE;
			default -> SoundEvents.ITEM_ARMOR_EQUIP_IRON;
		};
	}

	private static RegistryEntry<ArmorMaterial> crear(ModMetal metal) {
		ModMetal.ArmorStats s = metal.armadura;

		Map<ArmorItem.Type, Integer> defensaPorPieza = Map.of(
				ArmorItem.Type.BOOTS, s.botas,
				ArmorItem.Type.LEGGINGS, s.pantalones,
				ArmorItem.Type.CHESTPLATE, s.pechera,
				ArmorItem.Type.HELMET, s.casco
		);

		ArmorMaterial material = new ArmorMaterial(
				s.durabilidadBase,
				defensaPorPieza,
				encantabilidad(metal),
				sonidoEquipar(metal),
				s.tenacidad,
				0f, // resistencia a knockback plana; el +50%/100% de las Netherite se aplica como atributo extra al equipar - ver README
				Ingredient.ofItems(ModItems.LINGOTES.get(metal))
		);

		RegistryKey<ArmorMaterial> key = RegistryKey.of(RegistryKeys.ARMOR_MATERIAL, Identifier.of(MOD_ID, metal.id));
		return Registries.ARMOR_MATERIAL.createEntry(key, material);
	}
}
