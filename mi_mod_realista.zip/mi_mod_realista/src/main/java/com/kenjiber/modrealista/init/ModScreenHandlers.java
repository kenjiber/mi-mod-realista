package com.kenjiber.modrealista.init;

import com.kenjiber.modrealista.menu.AltoHornoScreenHandler;
import com.kenjiber.modrealista.menu.FusionFurnaceScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

public final class ModScreenHandlers {

	private ModScreenHandlers() {}

	public static ScreenHandlerType<AltoHornoScreenHandler> ALTO_HORNO;
	public static ScreenHandlerType<FusionFurnaceScreenHandler> HORNO_DE_FUSION;

	public static void registrarTodo() {
		// NOTA: la firma de ScreenHandlerType cambió en 1.21 (algunas versiones
		// piden un segundo argumento, un Codec, para sincronizar datos extra).
		// Como nuestros dos handlers no necesitan datos extra (solo la posición
		// del bloque, que ya se resuelve del lado servidor), el constructor de
		// un solo argumento debería bastar. Si tu versión exacta lo exige,
		// compara con `ScreenHandlerType.GENERIC_9X3` en las fuentes vanilla.
		ALTO_HORNO = Registries.SCREEN_HANDLER.add(
				RegistryKey.of(RegistryKeys.SCREEN_HANDLER, Identifier.of(MOD_ID, "alto_horno_de_cobre")),
				new ScreenHandlerType<>(AltoHornoScreenHandler::new));

		HORNO_DE_FUSION = Registries.SCREEN_HANDLER.add(
				RegistryKey.of(RegistryKeys.SCREEN_HANDLER, Identifier.of(MOD_ID, "horno_de_fusion")),
				new ScreenHandlerType<>(FusionFurnaceScreenHandler::new));
	}
}
