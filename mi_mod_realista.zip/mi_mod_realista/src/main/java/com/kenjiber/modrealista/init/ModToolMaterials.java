package com.kenjiber.modrealista.init;

import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.block.Block;

import java.util.EnumMap;
import java.util.Map;

/**
 * Traduce cada ModMetal a un {@link ToolMaterial} de vanilla (durabilidad,
 * velocidad de minado, nivel de minería, encantabilidad, sonido al equipar
 * y el "repair item" para el yunque).
 * <p>
 * NOTA: la firma exacta de ToolMaterial (orden de parámetros) cambia entre
 * snapshots de Minecraft. Verifica contra las fuentes mapeadas (Yarn) de tu
 * gradle.properties con "gradlew genSources" si algo no compila 1:1 — el
 * concepto (un registro de constantes, uno por metal) no cambia.
 */
public final class ModToolMaterials {

	private ModToolMaterials() {}

	private static final Map<ModMetal, ToolMaterial> CACHE = new EnumMap<>(ModMetal.class);

	/** Nivel de minado de cada tier, usando los tags vanilla como referencia de "qué puede picar". */
	private static TagKey<Block> tagParaNivel(int nivel) {
		return switch (nivel) {
			case 0 -> BlockTags.INCORRECT_FOR_WOODEN_TOOL;
			case 1 -> BlockTags.INCORRECT_FOR_STONE_TOOL;
			case 2 -> BlockTags.INCORRECT_FOR_IRON_TOOL;
			case 3 -> BlockTags.INCORRECT_FOR_DIAMOND_TOOL;
			default -> BlockTags.INCORRECT_FOR_NETHERITE_TOOL;
		};
	}

	public static ToolMaterial get(ModMetal metal) {
		return CACHE.computeIfAbsent(metal, ModToolMaterials::crear);
	}

	private static ToolMaterial crear(ModMetal metal) {
		int encantabilidad = switch (metal) {
			case ORO, ELECTRO -> 22; // igual que oro vanilla: máxima encantabilidad
			case TITANIO, NETHERITE_TITANIO, NETHERITE_TUNGSTENO -> 15;
			default -> 10;
		};
		return new ToolMaterial(
				tagParaNivel(metal.nivelMinado),
				metal.durabilidadHerramienta,
				metal.velocidadMinado,
				metal.danoAtaque,
				encantabilidad
		);
	}
}
