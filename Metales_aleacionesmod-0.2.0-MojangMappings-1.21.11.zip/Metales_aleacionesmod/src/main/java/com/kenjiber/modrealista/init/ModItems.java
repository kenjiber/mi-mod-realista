package com.kenjiber.modrealista.init;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;

import java.util.EnumMap;
import java.util.Map;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

/**
 * ============================== ATENCION (1.21.11) ==============================
 * Cambios de API frente a 1.21.1:
 *   - Ya NO existen las clases PickaxeItem ni SwordItem: un pico o una espada
 *     ahora son un Item comun con Item.BlockStateProperties#pickaxe(material, dano, vel)
 *     o #sword(material, dano, vel).
 *   - AxeItem y ShovelItem SI se mantienen (implementan interacciones propias:
 *     el hacha puede "pelar" troncos, la pala puede hacer caminos de tierra),
 *     pero su Item.BlockStateProperties debe pasarse VACIO: el propio constructor de
 *     AxeItem/ShovelItem llama a .axe(...)/.shovel(...) internamente.
 *   - ArmorItem tambien desaparecio: una pieza de armadura es un Item comun
 *     con Item.BlockStateProperties#humanoidArmor(material, ArmorType), sumado a
 *     .durability(ArmorType.X.getDurability(base)) para fijar su vida util
 *     (el ArmorMaterial ya no trae la durabilidad final calculada).
 * ==================================================================================
 */
public final class ModItems {

	private ModItems() {}

	// Mapas de acceso rápido: metal -> item concreto.
	public static final Map<ModMetal, Item> LINGOTES = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> FRAGMENTOS_CRUDOS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> PICOS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, AxeItem> HACHAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ShovelItem> PALAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> ESPADAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> CASCOS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> PECHERAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> PANTALONES = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> BOTAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ShieldItem> ESCUDOS = new EnumMap<>(ModMetal.class);

	/** Molde reutilizable que el Alto Horno pide junto a 4 fragmentos para purificar un lingote. */
	public static Item molde_de_fundicion;
	public static Item molde_de_arcilla_crudo;

	public static void registrarTodo() {
		molde_de_fundicion = registrar("molde_de_fundicion", new Item(new Item.BlockStateProperties()));
		molde_de_arcilla_crudo = registrar("molde_de_arcilla_crudo", new Item(new Item.BlockStateProperties()));

		for (ModMetal metal : ModMetal.values()) {

			// ==========================================================
			// HIERRO y ORO: usan lingotes vanilla, SIN herramientas/armaduras custom
			// ==========================================================
			if (metal.esVanilla()) {
				if (metal == ModMetal.HIERRO) {
					LINGOTES.put(metal, net.minecraft.world.item.Items.IRON_INGOT);
					FRAGMENTOS_CRUDOS.put(metal,
							registrar("fragmento_crudo_hierro", new Item(new Item.BlockStateProperties())));
				} else {
					LINGOTES.put(metal, net.minecraft.world.item.Items.GOLD_INGOT);
					FRAGMENTOS_CRUDOS.put(metal,
							registrar("fragmento_crudo_oro", new Item(new Item.BlockStateProperties())));
				}
				continue; // Sin herramientas ni armaduras custom
			}

			// ==========================================================
			// COBRE: lingote vanilla, PERO CON herramientas/armaduras custom
			// ==========================================================
			if (metal == ModMetal.COBRE) {
				LINGOTES.put(metal, net.minecraft.world.item.Items.COPPER_INGOT);
				FRAGMENTOS_CRUDOS.put(metal,
						registrar("fragmento_crudo_cobre", new Item(new Item.BlockStateProperties())));
				// NO continue: sigue al switch de abajo para crear herramientas/armadura.
			} else {
				LINGOTES.put(metal, registrar("lingote_" + metal.id, new Item(new Item.BlockStateProperties())));

				if (metal.tieneMineralEnElMundo()) {
					FRAGMENTOS_CRUDOS.put(metal,
							registrar("fragmento_crudo_" + metal.id, new Item(new Item.BlockStateProperties())));
				}
			}

			// ==========================================================
			// HERRAMIENTAS Y ARMADURAS (aplica a todos menos hierro/oro)
			// ==========================================================
			ToolMaterial material = ModToolMaterials.get(metal);

			switch (metal.catalogo) {
				case SET_COMPLETO, SET_COMPLETO_HERRERIA -> {
					registrarSetDeHerramientas(metal, material);
					registrarArmadura(metal);
					if (metal == ModMetal.ALUMINIO) {
						registrar("arco_ligero_de_aluminio",
								new BowItem(new Item.BlockStateProperties().durability(300)));
						registrar("flecha_de_alcance_aluminio",
								new ArrowItem(new Item.BlockStateProperties()));
					}
				}
				case ESPECIAL_ARMA_ESCUDO -> { // Plata
					ESPADAS.put(metal, registrar("espada_de_" + metal.id,
							new Item(new Item.BlockStateProperties().sword(material, 3.0f, metal.velocidadAtaque))));
					PICOS.put(metal, registrar("pico_de_" + metal.id,
							new Item(new Item.BlockStateProperties().pickaxe(material, 1.0f, metal.velocidadAtaque))));
					ESCUDOS.put(metal, registrar("escudo_de_" + metal.id,
							new ShieldItem(new Item.BlockStateProperties()
									.durability(metal.durabilidadHerramienta * 4))));
				}
				case ESPECIAL_SOLO_HERRAMIENTA -> { // Tungsteno puro
					PICOS.put(metal, registrar("pico_de_" + metal.id,
							new Item(new Item.BlockStateProperties().pickaxe(material, 1.0f, metal.velocidadAtaque))));
					HACHAS.put(metal, registrar("maza_pesada_de_" + metal.id,
							new AxeItem(material, 4.0f, metal.velocidadAtaque, new Item.BlockStateProperties())));
				}
				case ESPECIAL_LIGERO, ESPECIAL_MAGICO -> { // Duraluminio / Electro
					registrarSetDeHerramientas(metal, material);
				}
				case SOLO_INGREDIENTE -> { /* Estaño: solo el lingote */ }
			}
		}
	}

	private static void registrarSetDeHerramientas(ModMetal metal, ToolMaterial material) {
		PICOS.put(metal, registrar("pico_de_" + metal.id,
				new Item(new Item.BlockStateProperties().pickaxe(material, 1.0f, metal.velocidadAtaque))));
		HACHAS.put(metal, registrar("hacha_de_" + metal.id,
				new AxeItem(material, 3.0f, metal.velocidadAtaque, new Item.BlockStateProperties())));
		PALAS.put(metal, registrar("pala_de_" + metal.id,
				new ShovelItem(material, 1.5f, metal.velocidadAtaque, new Item.BlockStateProperties())));
		ESPADAS.put(metal, registrar("espada_de_" + metal.id,
				new Item(new Item.BlockStateProperties().sword(material, 3.0f, metal.velocidadAtaque))));
	}

	private static void registrarArmadura(ModMetal metal) {
		ArmorMaterial mat = ModArmorMaterials.get(metal);
		int durBase = metal.armadura.durabilidadBase;

		CASCOS.put(metal, registrar("casco_de_" + metal.id,
				new Item(new Item.BlockStateProperties().humanoidArmor(mat, ArmorType.HELMET)
						.durability(ArmorType.HELMET.getDurability(durBase)))));
		PECHERAS.put(metal, registrar("pechera_de_" + metal.id,
				new Item(new Item.BlockStateProperties().humanoidArmor(mat, ArmorType.CHESTPLATE)
						.durability(ArmorType.CHESTPLATE.getDurability(durBase)))));
		PANTALONES.put(metal, registrar("pantalones_de_" + metal.id,
				new Item(new Item.BlockStateProperties().humanoidArmor(mat, ArmorType.LEGGINGS)
						.durability(ArmorType.LEGGINGS.getDurability(durBase)))));
		BOTAS.put(metal, registrar("botas_de_" + metal.id,
				new Item(new Item.BlockStateProperties().humanoidArmor(mat, ArmorType.BOOTS)
						.durability(ArmorType.BOOTS.getDurability(durBase)))));
	}

	@SuppressWarnings("unchecked")
	private static <T extends Item> T registrar(String path, T item) {
		Identifier id = Identifier.fromNamespaceAndPath(MOD_ID, path);
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
		return (T) Registry.register(BuiltInRegistries.ITEM, key, item);
	}
}
