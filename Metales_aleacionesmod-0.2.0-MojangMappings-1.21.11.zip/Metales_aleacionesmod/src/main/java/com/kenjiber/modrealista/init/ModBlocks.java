package com.kenjiber.modrealista.init;

import com.kenjiber.modrealista.block.AltoHornoBlock;
import com.kenjiber.modrealista.block.FusionFurnaceBlock;
import net.minecraft.world.level.block.BlockBehaviour;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.valueproviders.UniformInt;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

public final class ModBlocks {

	private ModBlocks() {}

	public static Block ALTO_HORNO_DE_COBRE;
	public static Block HORNO_DE_FUSION_BASICO;
	public static Block HORNO_DE_FUSION_AVANZADO;

	public static final java.util.Map<ModMetal, Block> MENAS = new java.util.EnumMap<>(ModMetal.class);
	public static final java.util.Map<ModMetal, Block> MENAS_PIZARRA_PROFUNDA = new java.util.EnumMap<>(ModMetal.class);

	public static void registrarTodo() {
		// ✅ ALTO HORNO — luz 12 cuando está encendido (LIT=true)
		ALTO_HORNO_DE_COBRE = registrarConItem("alto_horno_de_cobre",
				new AltoHornoBlock(BlockBehaviour.Properties.of()
						.mapColor(MapColor.TERRACOTTA_ORANGE)
						.strength(3.5f, 6.0f)
						.luminance(state -> state.get(AltoHornoBlock.LIT) ? 12 : 0)));

		// ✅ HORNO BÁSICO — luz 10 cuando está encendido (LIT=true)
		HORNO_DE_FUSION_BASICO = registrarConItem("horno_de_fusion_basico",
				new FusionFurnaceBlock(BlockBehaviour.Properties.of()
						.mapColor(MapColor.TERRACOTTA_ORANGE)
						.strength(4.0f, 8.0f)
						.luminance(state -> state.get(FusionFurnaceBlock.LIT) ? 10 : 0), 1));

		// ✅ HORNO AVANZADO — luz 14 cuando está encendido (LIT=true)
		HORNO_DE_FUSION_AVANZADO = registrarConItem("horno_de_fusion_avanzado",
				new FusionFurnaceBlock(BlockBehaviour.Properties.of()
						.mapColor(MapColor.STONE_GRAY)
						.strength(5.0f, 10.0f)
						.luminance(state -> state.get(FusionFurnaceBlock.LIT) ? 14 : 0), 2));

		for (ModMetal metal : ModMetal.values()) {
			if (!metal.tieneMineralEnElMundo()) continue;

			// Cobre y Estaño son los metales de entrada al mod: dureza baja fija
			// (se minan rápido con cualquier pico) sin importar su nivelMinado.
			float dureza = (metal == ModMetal.COBRE || metal == ModMetal.ESTANO)
					? 1.5f
					: 3.0f + metal.nivelMinado * 1.5f;

			// Orden del constructor en 1.21.1: (IntProvider, Settings)
			Block mena = new net.minecraft.world.level.block.ExperienceDroppingBlock(
					UniformInt.create(0, 1 + metal.nivelMinado),
					BlockBehaviour.Properties.of().mapColor(MapColor.STONE_GRAY)
							.strength(dureza, dureza * 1.5f).requiresTool());
			MENAS.put(metal, registrarConItem("mena_" + metal.id, mena));

			Block menaDeepslate = new net.minecraft.world.level.block.ExperienceDroppingBlock(
					UniformInt.create(0, 1 + metal.nivelMinado),
					BlockBehaviour.Properties.of().mapColor(MapColor.DEEPSLATE_GRAY)
							.strength(dureza + 1.5f, dureza * 1.5f + 1.5f).requiresTool());
			MENAS_PIZARRA_PROFUNDA.put(metal, registrarConItem("mena_" + metal.id + "_pizarra_profunda", menaDeepslate));
		}
	}

	private static Block registrarConItem(String path, Block block) {
		Identifier id = Identifier.of(MOD_ID, path);
		ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id);
		Block registrado = Registry.register(Registries.BLOCK, blockKey, block);
		Registry.register(Registries.ITEM, ResourceKey.create(Registries.ITEM, id),
				new BlockItem(registrado, new Item.Settings()));
		return registrado;
	}
}
