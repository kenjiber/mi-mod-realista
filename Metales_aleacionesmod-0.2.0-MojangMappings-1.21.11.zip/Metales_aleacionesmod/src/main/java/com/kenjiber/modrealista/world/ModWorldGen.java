package com.kenjiber.modrealista.world;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

public class ModWorldGen {

    public static final ResourceKey<PlacedFeature> MENA_COBRE =
            ResourceKey.create(Registries.PLACED_FEATURE, Identifier.of(MOD_ID, "mena_cobre"));
    public static final ResourceKey<PlacedFeature> MENA_ESTANO =
            ResourceKey.create(Registries.PLACED_FEATURE, Identifier.of(MOD_ID, "mena_estano"));
    public static final ResourceKey<PlacedFeature> MENA_ALUMINIO =
            ResourceKey.create(Registries.PLACED_FEATURE, Identifier.of(MOD_ID, "mena_aluminio"));
    public static final ResourceKey<PlacedFeature> MENA_PLATA =
            ResourceKey.create(Registries.PLACED_FEATURE, Identifier.of(MOD_ID, "mena_plata"));
    public static final ResourceKey<PlacedFeature> MENA_TITANIO =
            ResourceKey.create(Registries.PLACED_FEATURE, Identifier.of(MOD_ID, "mena_titanio"));
    public static final ResourceKey<PlacedFeature> MENA_TUNGSTENO =
            ResourceKey.create(Registries.PLACED_FEATURE, Identifier.of(MOD_ID, "mena_tungsteno"));

    public static void registrar() {
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                GenerationStep.Decoration.UNDERGROUND_ORES, MENA_COBRE);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                GenerationStep.Decoration.UNDERGROUND_ORES, MENA_ESTANO);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                GenerationStep.Decoration.UNDERGROUND_ORES, MENA_ALUMINIO);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                GenerationStep.Decoration.UNDERGROUND_ORES, MENA_PLATA);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                GenerationStep.Decoration.UNDERGROUND_ORES, MENA_TITANIO);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                GenerationStep.Decoration.UNDERGROUND_ORES, MENA_TUNGSTENO);
    }
}
