package com.kenjiber.modrealista.init;

import com.kenjiber.modrealista.block.entity.AltoHornoBlockEntity;
import com.kenjiber.modrealista.block.entity.FusionFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

public final class ModBlockEntities {

	private ModBlockEntities() {}

	public static BlockEntityType<AltoHornoBlockEntity> ALTO_HORNO_ENTITY;
	public static BlockEntityType<FusionFurnaceBlockEntity> HORNO_FUSION_BASICO_ENTITY;
	public static BlockEntityType<FusionFurnaceBlockEntity> HORNO_FUSION_AVANZADO_ENTITY;

	public static void registrarTodo() {
		// CAMBIO: Registry.register(Registries.BLOCK_ENTITY_TYPE, key, value)
		ALTO_HORNO_ENTITY = Registry.register(
				Registries.BLOCK_ENTITY_TYPE,
				ResourceKey.create(Registries.BLOCK_ENTITY_TYPE, Identifier.of(MOD_ID, "alto_horno_de_cobre")),
				BlockEntityType.Builder.create(
						AltoHornoBlockEntity::new,
						ModBlocks.ALTO_HORNO_DE_COBRE
				).build()
		);

		HORNO_FUSION_BASICO_ENTITY = Registry.register(
				Registries.BLOCK_ENTITY_TYPE,
				ResourceKey.create(Registries.BLOCK_ENTITY_TYPE, Identifier.of(MOD_ID, "horno_fusion_basico")),
				BlockEntityType.Builder.create(
						(pos, state) -> new FusionFurnaceBlockEntity(pos, state, 1),
						ModBlocks.HORNO_DE_FUSION_BASICO
				).build()
		);

		HORNO_FUSION_AVANZADO_ENTITY = Registry.register(
				Registries.BLOCK_ENTITY_TYPE,
				ResourceKey.create(Registries.BLOCK_ENTITY_TYPE, Identifier.of(MOD_ID, "horno_fusion_avanzado")),
				BlockEntityType.Builder.create(
						(pos, state) -> new FusionFurnaceBlockEntity(pos, state, 2),
						ModBlocks.HORNO_DE_FUSION_AVANZADO
				).build()
		);
	}
}
