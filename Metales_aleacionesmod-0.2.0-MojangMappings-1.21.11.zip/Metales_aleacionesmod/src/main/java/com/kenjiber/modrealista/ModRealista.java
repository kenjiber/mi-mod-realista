package com.kenjiber.modrealista;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.Registry;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kenjiber.modrealista.init.ModBlockEntities;
import com.kenjiber.modrealista.init.ModBlocks;
import com.kenjiber.modrealista.init.ModItems;
import com.kenjiber.modrealista.init.ModMetal;

public class ModRealista implements ModInitializer {

	public static final String MOD_ID = "modrealista";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static ResourceKey<CreativeModeTab> GRUPO_METALURGIA;

	@Override
	public void onInitialize() {
		LOGGER.info("Inicializando Mod Realista - Metalurgia");

		// El orden importa: items antes que bloques (los bloques usan items
		// como el molde/lingotes en sus recetas de crafteo), y el creative
		// tab al final para poder listar todo lo ya registrado.
		ModItems.registrarTodo();
		com.kenjiber.modrealista.recipe.ModFusionRecipes.construir();
		ModBlocks.registrarTodo();
		ModBlockEntities.registrarTodo();
		com.kenjiber.modrealista.init.ModScreenHandlers.registrarTodo();
		com.kenjiber.modrealista.world.ModWorldGen.registrar();
		com.kenjiber.modrealista.world.ModLootTables.registrar();
		registrarCreativeTab();
	}

	private void registrarCreativeTab() {
		GRUPO_METALURGIA = ResourceKey.create(Registries.CREATIVE_MODE_TAB, Identifier.of(MOD_ID, "metalurgia"));

		Registry.register(Registries.CREATIVE_MODE_TAB, GRUPO_METALURGIA, FabricItemGroup.builder()
				.icon(() -> new ItemStack(ModItems.LINGOTES.get(ModMetal.ACERO)))
				.displayName(Component.translatable("itemGroup.modrealista.metalurgia"))
				.build());

		ItemGroupEvents.modifyEntriesEvent(GRUPO_METALURGIA).register(entries -> {
			entries.add(ModItems.molde_de_arcilla_crudo);
			entries.add(ModItems.molde_de_fundicion);
			ModMetal.values(); // orden de aparición: recorre el enum en orden natural definido
			for (ModMetal metal : ModMetal.values()) {
				if (ModItems.FRAGMENTOS_CRUDOS.containsKey(metal)) entries.add(ModItems.FRAGMENTOS_CRUDOS.get(metal));
				if (ModItems.LINGOTES.containsKey(metal)) entries.add(ModItems.LINGOTES.get(metal));
				if (ModItems.PICOS.containsKey(metal)) entries.add(ModItems.PICOS.get(metal));
				if (ModItems.HACHAS.containsKey(metal)) entries.add(ModItems.HACHAS.get(metal));
				if (ModItems.PALAS.containsKey(metal)) entries.add(ModItems.PALAS.get(metal));
				if (ModItems.ESPADAS.containsKey(metal)) entries.add(ModItems.ESPADAS.get(metal));
				if (ModItems.ESCUDOS.containsKey(metal)) entries.add(ModItems.ESCUDOS.get(metal));
				if (ModItems.CASCOS.containsKey(metal)) entries.add(ModItems.CASCOS.get(metal));
				if (ModItems.PECHERAS.containsKey(metal)) entries.add(ModItems.PECHERAS.get(metal));
				if (ModItems.PANTALONES.containsKey(metal)) entries.add(ModItems.PANTALONES.get(metal));
				if (ModItems.BOTAS.containsKey(metal)) entries.add(ModItems.BOTAS.get(metal));
			}
			entries.add(new ItemStack(ModBlocks.ALTO_HORNO_DE_COBRE));
			entries.add(new ItemStack(ModBlocks.HORNO_DE_FUSION_BASICO));
			entries.add(new ItemStack(ModBlocks.HORNO_DE_FUSION_AVANZADO));
		});
	}
}
