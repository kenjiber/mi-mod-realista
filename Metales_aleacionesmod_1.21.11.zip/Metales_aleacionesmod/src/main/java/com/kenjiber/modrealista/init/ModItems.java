package com.kenjiber.modrealista.init;

import net.minecraft.item.ArrowItem;
import net.minecraft.item.AxeItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.ShieldItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.equipment.ArmorMaterial;
import net.minecraft.item.equipment.EquipmentType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

/**
 * ============================== ATENCION (1.21.11) ==============================
 * Cambios de API frente a 1.21.1:
 *   - Ya NO existen las clases PickaxeItem ni SwordItem: un pico o una espada
 *     ahora son un Item comun con Item.Properties#pickaxe(material, dano, vel)
 *     o #sword(material, dano, vel).
 *   - AxeItem y ShovelItem SI se mantienen (implementan interacciones propias:
 *     el hacha puede "pelar" troncos, la pala puede hacer caminos de tierra),
 *     pero su Item.Properties debe pasarse VACIO: el propio constructor de
 *     AxeItem/ShovelItem llama a .axe(...)/.shovel(...) internamente.
 *   - ArmorItem tambien desaparecio: una pieza de armadura es un Item comun
 *     con Item.Properties#humanoidArmor(material, EquipmentType), sumado a
 *     .durability(EquipmentType.X.getDurability(base)) para fijar su vida util
 *     (el ArmorMaterial ya no trae la durabilidad final calculada).
 * ==================================================================================
 */
public final class ModItems {

	private ModItems() {}

	// Mapas de acceso rápido: metal -> item concreto.
	public static final Map<ModMetal, Item> LINGOTES = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> FRAGMENTOS_CRUDOS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> PICOS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, AxeItem> HACHAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ShovelItem> PALAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> ESPADAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> CASCOS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> PECHERAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> PANTALONES = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> BOTAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ShieldItem> ESCUDOS = new EnumMap<>(ModMetal.class);

	/** Molde reutilizable que el Alto Horno pide junto a 4 fragmentos para purificar un lingote. */
	public static Item molde_de_fundicion;
	public static Item molde_de_arcilla_crudo;

	public static void registrarTodo() {
		molde_de_fundicion = registrar("molde_de_fundicion", new Item(new Item.Settings()));
		molde_de_arcilla_crudo = registrar("molde_de_arcilla_crudo", new Item(new Item.Settings()));

		for (ModMetal metal : ModMetal.values()) {

			// ==========================================================
			// HIERRO y ORO: usan lingotes vanilla, SIN herramientas/armaduras custom
			// ==========================================================
			if (metal.esVanilla()) {
				if (metal == ModMetal.HIERRO) {
					LINGOTES.put(metal, net.minecraft.item.Items.IRON_INGOT);
					FRAGMENTOS_CRUDOS.put(metal,
							registrar("fragmento_crudo_hierro", new Item(new Item.Settings())));
				} else {
					LINGOTES.put(metal, net.minecraft.item.Items.GOLD_INGOT);
					FRAGMENTOS_CRUDOS.put(metal,
							registrar("fragmento_crudo_oro", new Item(new Item.Settings())));
				}
				continue; // Sin herramientas ni armaduras custom
			}

			// ==========================================================
			// COBRE: lingote vanilla, PERO CON herramientas/armaduras custom
			// ==========================================================
			if (metal == ModMetal.COBRE) {
				LINGOTES.put(metal, net.minecraft.item.Items.COPPER_INGOT);
				FRAGMENTOS_CRUDOS.put(metal,
						registrar("fragmento_crudo_cobre", new Item(new Item.Settings())));
				// NO continue: sigue al switch de abajo para crear herramientas/armadura.
			} else {
				LINGOTES.put(metal, registrar("lingote_" + metal.id, new Item(new Item.Settings())));

				if (metal.tieneMineralEnElMundo()) {
					FRAGMENTOS_CRUDOS.put(metal,
							registrar("fragmento_crudo_" + metal.id, new Item(new Item.Settings())));
				}
			}

			// ==========================================================
			// HERRAMIENTAS Y ARMADURAS (aplica a todos menos hierro/oro)
			// ==========================================================
			ToolMaterial material = ModToolMaterials.get(metal);

			switch (metal.catalogo) {
				case SET_COMPLETO, SET_COMPLETO_HERRERIA -> {
					registrarSetDeHerramientas(metal, material);
					registrarArmadura(metal);
					if (metal == ModMetal.ALUMINIO) {
						registrar("arco_ligero_de_aluminio",
								new BowItem(new Item.Settings().maxDamage(300)));
						registrar("flecha_de_alcance_aluminio",
								new ArrowItem(new Item.Settings()));
					}
				}
				case ESPECIAL_ARMA_ESCUDO -> { // Plata
					ESPADAS.put(metal, registrar("espada_de_" + metal.id,
							new Item(new Item.Settings().sword(material, 3.0f, metal.velocidadAtaque))));
					PICOS.put(metal, registrar("pico_de_" + metal.id,
							new Item(new Item.Settings().pickaxe(material, 1.0f, metal.velocidadAtaque))));
					ESCUDOS.put(metal, registrar("escudo_de_" + metal.id,
							new ShieldItem(new Item.Settings()
									.maxDamage(metal.durabilidadHerramienta * 4))));
				}
				case ESPECIAL_SOLO_HERRAMIENTA -> { // Tungsteno puro
					PICOS.put(metal, registrar("pico_de_" + metal.id,
							new Item(new Item.Settings().pickaxe(material, 1.0f, metal.velocidadAtaque))));
					HACHAS.put(metal, registrar("maza_pesada_de_" + metal.id,
							new AxeItem(material, 4.0f, metal.velocidadAtaque, new Item.Settings())));
				}
				case ESPECIAL_LIGERO, ESPECIAL_MAGICO -> { // Duraluminio / Electro
					registrarSetDeHerramientas(metal, material);
				}
				case SOLO_INGREDIENTE -> { /* Estaño: solo el lingote */ }
			}
		}
	}

	private static void registrarSetDeHerramientas(ModMetal metal, ToolMaterial material) {
		PICOS.put(metal, registrar("pico_de_" + metal.id,
				new Item(new Item.Settings().pickaxe(material, 1.0f, metal.velocidadAtaque))));
		HACHAS.put(metal, registrar("hacha_de_" + metal.id,
				new AxeItem(material, 3.0f, metal.velocidadAtaque, new Item.Settings())));
		PALAS.put(metal, registrar("pala_de_" + metal.id,
				new ShovelItem(material, 1.5f, metal.velocidadAtaque, new Item.Settings())));
		ESPADAS.put(metal, registrar("espada_de_" + metal.id,
				new Item(new Item.Settings().sword(material, 3.0f, metal.velocidadAtaque))));
	}

	private static void registrarArmadura(ModMetal metal) {
		ArmorMaterial mat = ModArmorMaterials.get(metal);
		int durBase = metal.armadura.durabilidadBase;

		CASCOS.put(metal, registrar("casco_de_" + metal.id,
				new Item(new Item.Settings().humanoidArmor(mat, EquipmentType.HELMET)
						.durability(EquipmentType.HELMET.getDurability(durBase)))));
		PECHERAS.put(metal, registrar("pechera_de_" + metal.id,
				new Item(new Item.Settings().humanoidArmor(mat, EquipmentType.CHESTPLATE)
						.durability(EquipmentType.CHESTPLATE.getDurability(durBase)))));
		PANTALONES.put(metal, registrar("pantalones_de_" + metal.id,
				new Item(new Item.Settings().humanoidArmor(mat, EquipmentType.LEGGINGS)
						.durability(EquipmentType.LEGGINGS.getDurability(durBase)))));
		BOTAS.put(metal, registrar("botas_de_" + metal.id,
				new Item(new Item.Settings().humanoidArmor(mat, EquipmentType.BOOTS)
						.durability(EquipmentType.BOOTS.getDurability(durBase)))));
	}

	@SuppressWarnings("unchecked")
	private static <T extends Item> T registrar(String path, T item) {
		Identifier id = Identifier.of(MOD_ID, path);
		RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id);
		return (T) Registry.register(Registries.ITEM, key, item);
	}
}
