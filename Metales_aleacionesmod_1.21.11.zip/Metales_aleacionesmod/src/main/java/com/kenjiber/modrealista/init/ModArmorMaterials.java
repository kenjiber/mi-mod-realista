package com.kenjiber.modrealista.init;

import net.minecraft.item.Item;
import net.minecraft.item.equipment.ArmorMaterial;
import net.minecraft.item.equipment.EquipmentAsset;
import net.minecraft.item.equipment.EquipmentAssetKeys;
import net.minecraft.item.equipment.EquipmentType;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

/**
 * ============================== ATENCION (1.21.11) ==============================
 * A partir de 1.21.2-1.21.4, Mojang reescribió por completo el sistema de
 * armaduras. Cambios clave frente a la version 1.21.1 que teniamos antes:
 *   1. ArmorMaterial se movio de paquete: ahora vive en
 *      net.minecraft.item.equipment.ArmorMaterial (antes net.minecraft.item).
 *   2. Ya NO se registra en un Registry (no mas Registries.ARMOR_MATERIAL);
 *      ahora es un simple record que se guarda como constante, sin
 *      RegistryEntry envolviendolo.
 *   3. El "repairIngredient" ya no es un Ingredient/Supplier<Ingredient>,
 *      sino un TagKey<Item> (usamos los tags ya creados en
 *      data/modrealista/tags/item/repair/<metal>.json).
 *   4. La lista de texturas (List<Layer>) fue reemplazada por una sola
 *      RegistryKey<EquipmentAsset>, que apunta a un archivo JSON nuevo en
 *      assets/modrealista/equipment/<metal>.json (ver ese archivo para el
 *      mapeo real de texturas humanoid/humanoid_leggings).
 *   5. Las texturas de armadura en si se movieron de
 *      textures/models/armor/<id>_layer_1.png (viejo) a
 *      textures/entity/equipment/humanoid/<id>.png (nuevo, capa 1: cuerpo+botas)
 *      textures/entity/equipment/humanoid_leggings/<id>.png (nuevo, capa 2: piernas)
 * ==================================================================================
 */
public final class ModArmorMaterials {

	private ModArmorMaterials() {}

	private static final Map<ModMetal, ArmorMaterial> CACHE = new EnumMap<>(ModMetal.class);

	public static ArmorMaterial get(ModMetal metal) {
		return CACHE.computeIfAbsent(metal, ModArmorMaterials::crear);
	}

	/** Clave del "equipment asset": determina el nombre del JSON en assets/modrealista/equipment/. */
	public static RegistryKey<EquipmentAsset> equipmentAssetKey(ModMetal metal) {
		return RegistryKey.of(EquipmentAssetKeys.REGISTRY_KEY, Identifier.of(MOD_ID, metal.id));
	}

	private static int encantabilidad(ModMetal metal) {
		return switch (metal) {
			case ORO -> 25;
			case TITANIO, NETHERITE_TITANIO, NETHERITE_TUNGSTENO -> 15;
			default -> 9;
		};
	}

	private static RegistryEntry<SoundEvent> sonidoEquipar(ModMetal metal) {
		return switch (metal) {
			case ORO -> SoundEvents.ITEM_ARMOR_EQUIP_GOLD;
			case NETHERITE_TITANIO, NETHERITE_TUNGSTENO -> SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE;
			default -> SoundEvents.ITEM_ARMOR_EQUIP_IRON;
		};
	}

	private static ArmorMaterial crear(ModMetal metal) {
		ModMetal.ArmorStats s = metal.armadura;

		Map<EquipmentType, Integer> defensaPorPieza = Map.of(
				EquipmentType.HELMET, s.casco,
				EquipmentType.CHESTPLATE, s.pechera,
				EquipmentType.LEGGINGS, s.pantalones,
				EquipmentType.BOOTS, s.botas
		);

		TagKey<Item> repararCon = ModToolMaterials.tagDeReparacion(metal);

		return new ArmorMaterial(
				s.durabilidadBase,       // 1. int durability (base; cada pieza lo multiplica distinto)
				defensaPorPieza,         // 2. Map<EquipmentType, Integer> defense
				encantabilidad(metal),   // 3. int enchantmentValue
				sonidoEquipar(metal),    // 4. RegistryEntry<SoundEvent> equipSound
				s.tenacidad,             // 5. float toughness
				0f,                      // 6. float knockbackResistance
				repararCon,              // 7. TagKey<Item> repairIngredient
				equipmentAssetKey(metal) // 8. RegistryKey<EquipmentAsset> assetId
		);
	}
}
