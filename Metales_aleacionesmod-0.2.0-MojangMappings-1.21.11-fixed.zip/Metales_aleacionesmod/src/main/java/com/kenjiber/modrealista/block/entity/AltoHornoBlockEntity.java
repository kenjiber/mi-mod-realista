package com.kenjiber.modrealista.block.entity;

import com.kenjiber.modrealista.init.ModBlockEntities;
import com.kenjiber.modrealista.init.ModItems;
import com.kenjiber.modrealista.menu.AltoHornoScreenHandler;
import com.kenjiber.modrealista.recipe.ModFusionRecipes;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.network.chat.Component;
import net.minecraft.core.NonNullList;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;

/**
 * Alto Horno de Cobre: purifica 4 Fragmentos Crudos de UN metal (slot 0) +
 * Molde reutilizable (slot 1, no se consume) + combustible (slot 2) en
 * 1 Lingote Puro (slot 3). Ver {@link ModFusionRecipes#PURIFICACIONES}.
 */
public class AltoHornoBlockEntity extends BlockEntity
		implements Container, ExtendedScreenHandlerFactory<BlockPos> {

	public static final int SLOT_FRAGMENTOS = 0;
	public static final int SLOT_MOLDE = 1;
	public static final int SLOT_COMBUSTIBLE = 2;
	public static final int SLOT_SALIDA = 3;
	private static final int TAMANO_INVENTARIO = 4;

	private final NonNullList<ItemStack> inventario = NonNullList.ofSize(TAMANO_INVENTARIO, ItemStack.EMPTY);

	private int progreso = 0;
	private int tiempoTotalNecesario = 200;
	private int combustibleRestante = 0;
	private int combustibleMaximoActual = 0;

	public AltoHornoBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.ALTO_HORNO_ENTITY, pos, state);
	}

	public float getProgreso() {
		return tiempoTotalNecesario == 0 ? 0 : (float) progreso / tiempoTotalNecesario;
	}

	// --- Accesores usados por el PropertyDelegate (sincronización con el cliente para animar la GUI) ---
	public int getProgresoRaw() { return progreso; }
	public void setProgresoRaw(int v) { progreso = v; }
	public int getTiempoTotalNecesarioRaw() { return tiempoTotalNecesario; }
	public void setTiempoTotalNecesarioRaw(int v) { tiempoTotalNecesario = v; }
	public int getCombustibleRestanteRaw() { return combustibleRestante; }
	public void setCombustibleRestanteRaw(int v) { combustibleRestante = v; }
	public int getCombustibleMaximoRaw() { return combustibleMaximoActual; }
	public void setCombustibleMaximoRaw(int v) { combustibleMaximoActual = v; }

	public static <T extends BlockEntity> void tick(Level level, BlockPos pos, BlockState state, T be) {
		if (!(be instanceof AltoHornoBlockEntity horno)) return;
		if (level.isClientSide()) return;
		horno.tickServidor((ServerLevel) level);
	}

	private void tickServidor(ServerLevel world) {
		ItemStack fragmentos = inventario.get(SLOT_FRAGMENTOS);
		ModFusionRecipes.Purificacion receta =
				ModFusionRecipes.buscarPurificacion(fragmentos.getItem(), fragmentos.getCount());

		boolean puedeProcesar = puedeProcesar(receta);

		// 🔧 FIX: Si no puede procesar, apagar el horno (aunque quede combustible)
		if (!puedeProcesar) {
			if (combustibleRestante <= 0) progreso = 0;
			actualizarEncendido(world, false);
			setChanged();
			return;
		}

		if (combustibleRestante <= 0) {
			ItemStack combustible = inventario.get(SLOT_COMBUSTIBLE);
			int valor = com.kenjiber.modrealista.util.ModFuel.tiempoDeQuemado(combustible);
			if (valor > 0) {
				combustibleRestante = valor;
				combustibleMaximoActual = valor;
				combustible.decrement(1);
			}
		}

		if (combustibleRestante > 0) {
			combustibleRestante--;
			tiempoTotalNecesario = receta.tiempoTicks();
			progreso++;
			if (progreso >= tiempoTotalNecesario) {
				progreso = 0;
				fragmentos.decrement(receta.cantidadFragmentos());
				if (inventario.get(SLOT_SALIDA).isEmpty()) {
					inventario.set(SLOT_SALIDA, new ItemStack(receta.resultado()));
				} else {
					inventario.get(SLOT_SALIDA).increment(1);
				}
			}
		}
		actualizarEncendido(world, true);
		setChanged();
	}

	/**
	 * Comprueba si hay una receta válida, hay molde, y hay espacio en la salida.
	 * Se extrae a un método para poder reusarlo desde tickServidor y readNbt.
	 */
	private boolean puedeProcesar(ModFusionRecipes.Purificacion receta) {
		if (receta == null) return false;

		boolean tieneMolde = inventario.get(SLOT_MOLDE).is(ModItems.molde_de_fundicion);
		if (!tieneMolde) return false;

		ItemStack salida = inventario.get(SLOT_SALIDA);
		return salida.isEmpty()
				|| (salida.is(receta.resultado())
					&& salida.getCount() < salida.getMaxCount());
	}

	/**
	 * 🔧 FIX: Sincroniza la propiedad de bloque "lit" (usada por el modelo
	 * apagado/encendido) con el estado real del horno.
	 *
	 * Ahora el horno SOLO se ve encendido si está purificando activamente
	 * (combustible + receta válida + molde + espacio en la salida).
	 *
	 * Además, usa NOTIFY_LISTENERS | FORCE_STATE para garantizar que el paquete
	 * se envíe al cliente aunque el bloque esté lejos o en un chunk recién cargado.
	 */
	private void actualizarEncendido(ServerLevel world, boolean puedeProcesar) {
		boolean encendidoAhora = combustibleRestante > 0 && puedeProcesar;
		BlockState estado = world.getBlockState(worldPosition);

		if (estado.contains(BlockStateProperties.LIT)
				&& estado.get(BlockStateProperties.LIT) != encendidoAhora) {
			world.setBlock(worldPosition,
					estado.with(BlockStateProperties.LIT, encendidoAhora),
					Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
		}
	}

	// ============ Persistencia (NBT) ============

	@Override
	protected void loadAdditional(ValueInput input) {
		super.loadAdditional(input);
		ContainerHelper.loadAllItems(input, inventario);
		progreso = input.getIntOr("Progreso", 0);
		tiempoTotalNecesario = input.getIntOr("TiempoTotal", 200);
		combustibleRestante = input.getIntOr("Combustible", 0);
		combustibleMaximoActual = input.getIntOr("CombustibleMax", 0);

		// 🔧 FIX: reconciliar el estado LIT al cargar el chunk.
		// Si el mundo se cerró con el horno encendido pero ya no puede procesar,
		// forzar LIT=false para evitar la "textura de encendido pegada".
		if (level != null && !level.isClientSide()) {
			ItemStack fragmentos = inventario.get(SLOT_FRAGMENTOS);
			ModFusionRecipes.Purificacion receta =
					ModFusionRecipes.buscarPurificacion(fragmentos.getItem(), fragmentos.getCount());
			boolean puedeProcesar = puedeProcesar(receta);
			boolean encendidoAhora = combustibleRestante > 0 && puedeProcesar;

			BlockState estado = level.getBlockState(worldPosition)
			if (estado.contains(BlockStateProperties.LIT)
					&& estado.get(BlockStateProperties.LIT) != encendidoAhora) {
				level.setBlock(worldPosition,
						estado.with(BlockStateProperties.LIT, encendidoAhora),
						Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
			}
		}
	}

	@Override
	protected void saveAdditional(ValueOutput output) {
		super.saveAdditional(output);
		ContainerHelper.saveAllItems(output, inventario);
		output.putInt("Progreso", progreso);
		output.putInt("TiempoTotal", tiempoTotalNecesario);
		output.putInt("Combustible", combustibleRestante);
		output.putInt("CombustibleMax", combustibleMaximoActual);
	}

	// ============ Inventory ============

	@Override public int getContainerSize() { return TAMANO_INVENTARIO; }
	@Override public boolean isEmpty() { return inventario.stream().allMatch(ItemStack::isEmpty); }
	@Override public ItemStack getItem(int slot) { return inventario.get(slot); }
	@Override public ItemStack removeItem(int slot, int amount) { return ContainerHelper.removeItem(inventario, slot, amount); }
	@Override public ItemStack removeItemNoUpdate(int slot) { return ContainerHelper.takeItem(inventario, slot); }
	@Override public void setItem(int slot, ItemStack stack) { inventario.set(slot, stack); }


	@Override
	public boolean stillValid(Player player) {
		return level != null && level.getBlockEntity(worldPosition) == this
				&& player.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 64.0;
	}
	@Override public void clearContent() { inventario.clear(); }

	// ============ ExtendedScreenHandlerFactory ============

	@Override
	public Component getDisplayName() {
		return Component.translatable("block.modrealista.alto_horno_de_cobre");
	}

	@Override
	public BlockPos getScreenOpeningData(ServerPlayer player) {
		return this.worldPosition;
	}

	@Override
	public AbstractContainerMenu createMenu(int syncId, Inventory playerInventory, Player player) {
		return new AltoHornoScreenHandler(syncId, playerInventory, this.worldPosition);
	}
}
