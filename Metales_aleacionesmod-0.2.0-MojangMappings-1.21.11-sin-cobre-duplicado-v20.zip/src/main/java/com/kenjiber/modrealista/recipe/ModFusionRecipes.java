package com.kenjiber.modrealista.recipe;

import com.kenjiber.modrealista.init.ModItems;
import com.kenjiber.modrealista.init.ModMetal;
import net.minecraft.world.item.Item;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Tabla central de recetas de fundición. Si quieres cambiar una proporción
 * (ej. que el Bronce use 4 Cobre en vez de 3), este es el único lugar que
 * hay que tocar — no hace falta editar el BlockEntity.
 * <p>
 * Se definieron dos tipos de receta:
 *  - {@link Purificacion}: Alto Horno de Cobre. 4 Fragmentos Crudos de UN
 *    metal + Molde (no se consume) + combustible -> 1 Lingote Puro.
 *  - {@link Aleacion}: Horno de Fusión (Básico o Avanzado). 2 ingredientes
 *    en proporciones libres + Molde (no se consume) + combustible -> 1
 *    Lingote de aleación.
 * <p>
 * ⚠️ IMPORTANTE: {@link #construir()} DEBE llamarse después de
 * {@code ModItems.registrarTodo()}, porque usa los mapas LINGOTES y
 * FRAGMENTOS_CRUDOS que se llenan durante el registro.
 */
public final class ModFusionRecipes {

	private static final Logger LOGGER = LoggerFactory.getLogger("modrealista/recipes");

	private ModFusionRecipes() {}

	/** horno = 1 (Básico) o 2 (Avanzado); tiempoTicks por defecto 200 (10s), igual que el horno vanilla. */
	public record Aleacion(Item ingrediente1, int cantidad1, Item ingrediente2, int cantidad2,
							Item resultado, int hornoRequerido, int tiempoTicks) {}

	public record Purificacion(Item fragmento, int cantidadFragmentos, Item resultado, int tiempoTicks) {}

	public static final List<Aleacion> ALEACIONES = new ArrayList<>();
	public static final List<Purificacion> PURIFICACIONES = new ArrayList<>();

	/** Evita reconstruir si ya se llamó (idempotente). */
	private static boolean construida = false;

	public static void construir() {
		if (construida) return;

		ALEACIONES.clear();
		PURIFICACIONES.clear();

		// ============================================================
		// ---- Horno de Fusión BÁSICO (tier 1) ----
		// ============================================================
		agregarAleacion(ModMetal.COBRE, 3, ModMetal.ESTANO, 1, ModMetal.BRONCE, 1, 200);
		agregarAleacion(ModMetal.ALUMINIO, 1, ModMetal.COBRE, 1, ModMetal.DURALUMINIO, 1, 200);
		agregarAleacion(ModMetal.PLATA, 1, ModMetal.ORO, 1, ModMetal.ELECTRO, 1, 200);

		// Acero: 1 Hierro + 1 Carbón → 1 Acero.
		// También se fabrica en el Horno de Fusión BÁSICO.
		agregarAleacionItems(
				ModItems.LINGOTES.get(ModMetal.HIERRO), 1,
				net.minecraft.world.item.Items.COAL, 1,
				ModItems.LINGOTES.get(ModMetal.ACERO), 1,
				1, 240);

		// ============================================================
		// ---- Horno de Fusión AVANZADO (tier 2) ----
		// ============================================================
		// El avanzado queda reservado para las aleaciones que incluyen
		// Titanio o Tungsteno junto con Netherite.

		// Netherite-Titanio: 1 Netherite + 2 Titanio → 1 Netherite-Titanio
		agregarAleacionItems(
				net.minecraft.world.item.Items.NETHERITE_INGOT, 1,
				ModItems.LINGOTES.get(ModMetal.TITANIO), 2,
				ModItems.LINGOTES.get(ModMetal.NETHERITE_TITANIO), 1,
				2, 300);

		// Netherite-Tungsteno: 1 Netherite + 2 Tungsteno → 1 Netherite-Tungsteno
		agregarAleacionItems(
				net.minecraft.world.item.Items.NETHERITE_INGOT, 1,
				ModItems.LINGOTES.get(ModMetal.TUNGSTENO), 2,
				ModItems.LINGOTES.get(ModMetal.NETHERITE_TUNGSTENO), 1,
				2, 300);

		// ============================================================
		// ---- Alto Horno de Cobre: purificación de fragmentos ----
		// ============================================================
		agregarPurificacion(ModMetal.HIERRO, 4, 200);
		agregarPurificacion(ModMetal.PLATA, 4, 200);
		agregarPurificacion(ModMetal.ORO, 4, 200);
		agregarPurificacion(ModMetal.TITANIO, 4, 260);
		agregarPurificacion(ModMetal.TUNGSTENO, 4, 260);

		construida = true;
		LOGGER.info("[ModRealista] Recetas de fusión construidas: {} aleaciones, {} purificaciones",
				ALEACIONES.size(), PURIFICACIONES.size());
	}

	// ==================== Helpers internos ====================

	private static void agregarAleacion(ModMetal m1, int c1, ModMetal m2, int c2,
										 ModMetal resultado, int horno, int ticks) {
		Item i1 = ModItems.LINGOTES.get(m1);
		Item i2 = ModItems.LINGOTES.get(m2);
		Item ir = ModItems.LINGOTES.get(resultado);
		if (i1 == null || i2 == null || ir == null) {
			LOGGER.warn("[ModRealista] Aleación omitida por item nulo: {} + {} -> {}", m1, m2, resultado);
			return;
		}
		ALEACIONES.add(new Aleacion(i1, c1, i2, c2, ir, horno, ticks));
	}

	private static void agregarAleacionItems(Item i1, int c1, Item i2, int c2,
											  Item resultado, int cantidadResultado,
											  int horno, int ticks) {
		if (i1 == null || i2 == null || resultado == null) {
			LOGGER.warn("[ModRealista] Aleación de items omitida por item nulo");
			return;
		}
		ALEACIONES.add(new Aleacion(i1, c1, i2, c2, resultado, horno, ticks));
	}

	private static void agregarPurificacion(ModMetal metal, int cantidadFragmentos, int ticks) {
		Item frag = ModItems.FRAGMENTOS_CRUDOS.get(metal);
		Item lingote = ModItems.LINGOTES.get(metal);
		if (frag == null || lingote == null) {
			LOGGER.warn("[ModRealista] Purificación omitida por item nulo: {}", metal);
			return;
		}
		PURIFICACIONES.add(new Purificacion(frag, cantidadFragmentos, lingote, ticks));
	}

	// ==================== Búsqueda ====================

	/** Busca una receta de aleación que coincida EXACTAMENTE (en cualquier orden de slots). */
	public static Aleacion buscarAleacion(Item itemSlot1, int cantSlot1,
										   Item itemSlot2, int cantSlot2, int hornoTier) {
		for (Aleacion a : ALEACIONES) {
			if (a.hornoRequerido() > hornoTier) continue;

			boolean directo = a.ingrediente1() == itemSlot1 && cantSlot1 >= a.cantidad1()
					&& a.ingrediente2() == itemSlot2 && cantSlot2 >= a.cantidad2();
			boolean invertido = a.ingrediente1() == itemSlot2 && cantSlot2 >= a.cantidad1()
					&& a.ingrediente2() == itemSlot1 && cantSlot1 >= a.cantidad2();

			if (directo || invertido) return a;
		}
		return null;
	}

	public static Purificacion buscarPurificacion(Item fragmento, int cantidad) {
		for (Purificacion p : PURIFICACIONES) {
			if (p.fragmento() == fragmento && cantidad >= p.cantidadFragmentos()) return p;
		}
		return null;
	}
}
