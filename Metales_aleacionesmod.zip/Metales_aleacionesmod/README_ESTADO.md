# Estado del proyecto — Mod Realista (Metalurgia)

## Listo (código + datos)
- Proyecto Gradle + Fabric Loom completo (build.gradle, gradle.properties, settings.gradle, fabric.mod.json)
- `ModMetal.java`: fuente única de verdad de los 8 metales puros + 6 aleaciones (stats, catálogo de objetos)
- `ModItems.java`: registra automáticamente lingotes, fragmentos, picos, hachas, palas, espadas,
  armaduras, arco/flecha de Aluminio, espada/escudo/pico de Plata, pico/maza de Tungsteno,
  herramientas de Duraluminio/Electro, y los 2 moldes
- `ModToolMaterials.java` / `ModArmorMaterials.java`: convierten cada metal en ToolMaterial/ArmorMaterial
- `ModBlocks.java`: Alto Horno de Cobre + Horno de Fusión Básico/Avanzado + 16 bloques de mena
  (8 metales × normal/pizarra profunda)
- `ModFusionRecipes.java`: tabla central de recetas de fundición (Purificación en Alto Horno,
  Aleación en Hornos de Fusión) — todas las proporciones exactas que definiste
- `AltoHornoBlockEntity` / `FusionFurnaceBlockEntity`: lógica real de fundido (combustible, progreso,
  consumo de fragmentos/lingotes, producción de resultado, el molde no se consume)
- **GUI jugable**: `AltoHornoScreenHandler`/`AltoHornoScreen` (4 slots: fragmentos, molde, combustible,
  salida) y `FusionFurnaceScreenHandler`/`FusionFurnaceScreen` (5 slots: 2 metales, molde, combustible,
  salida). Ambos bloques ya abren una pantalla real al hacer clic derecho.
- Texturas placeholder identificables para los 113 ítems + 16 menas + 3 bloques de horno + 2 GUIs
  (color por metal + pictograma por tipo de herramienta/pieza)
- Modelos de item/bloque y blockstates para todo lo anterior
- Loot tables de los 16 bloques de mena (dropean su fragmento crudo correspondiente)
- ~105 archivos de receta JSON: molde crudo, molde cocido, Alto Horno, ambos Hornos de Fusión,
  fundido directo de Cobre/Estaño/Aluminio, sets completos de herramienta+armadura (7 metales),
  ítems especiales (arco/flecha de Aluminio, espada/escudo/pico de Plata, maza/pico de Tungsteno,
  herramientas de Duraluminio/Electro), y las 12 mejoras de Mesa de Herrería para Tier 5
  (Netherite-Titanio / Netherite-Tungsteno, usando la Plantilla de Netherite vainilla)
- Lang es_es / en_us con 131 nombres

## Falta / pendiente
1. **Habilidades pasivas de armadura** (inmunidad a lava, -30% daño de caída, resistencia a
   knockback extra, +50% daño no-muertos, ignorar escudo, etc.): no implementadas aún. Algunas
   son gratis vía datos (tag `piglin_safe_armor` para el Oro), otras necesitan Mixin o eventos
   de Fabric API.
2. **Worldgen real** (que las 16 menas aparezcan al generar el mundo, por Y-level/bioma): los
   bloques existen y son minables, pero no se generan solos todavía — falta el datapack de
   `worldgen/configured_feature` + `worldgen/placed_feature` + `biome_modification`.
3. **Item tags** (ej. que los picos de Duraluminio/Electro cuenten como "pico" para vainilla,
   fortuna/silk touch, tags de `minecraft:tool` correctos por nivel de minería).
4. **Barra de progreso/llama animadas en la GUI**: el fondo y los slots ya funcionan y son
   jugables, pero la textura de flecha/llama es estática — falta exponer el progreso real vía
   PropertyDelegate y usarlo en el Screen para que se mueva/parpadee.
5. **Texturas finales**: los placeholders son deliberadamente simples — cuando tengas las
   texturas reales, solo hay que reemplazar los .png, no tocar ningún JSON ni Java.

## Antes de compilar
Corre `gradlew genSources` y revisa especialmente `ModArmorMaterials.java` y `ModScreenHandlers.java`
(la firma de ArmorMaterial y de ScreenHandlerType cambia entre versiones de Minecraft 1.20.5+).
