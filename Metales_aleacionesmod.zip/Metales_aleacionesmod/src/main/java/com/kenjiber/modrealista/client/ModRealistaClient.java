package com.kenjiber.modrealista.client;

import com.kenjiber.modrealista.init.ModScreenHandlers;
import com.kenjiber.modrealista.screen.AltoHornoScreen;
import com.kenjiber.modrealista.screen.FusionFurnaceScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screenhandler.v1.ScreenRegistry; // <-- NUEVO IMPORT

/**
 * Todo lo que solo existe en el cliente (pantallas, renderizado) va aquí,
 * nunca en ModRealista.java — si se registra una Screen en el servidor
 * dedicado, este crashea al arrancar.
 */
public class ModRealistaClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		// CAMBIO: Se usa ScreenRegistry.register(...) en lugar de HandledScreens.register(...)
		ScreenRegistry.register(ModScreenHandlers.ALTO_HORNO, AltoHornoScreen::new);
		ScreenRegistry.register(ModScreenHandlers.HORNO_DE_FUSION, FusionFurnaceScreen::new);
	}
}