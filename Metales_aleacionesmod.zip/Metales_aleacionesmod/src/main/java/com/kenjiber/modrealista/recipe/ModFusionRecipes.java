package com.kenjiber.modrealista.recipe;

import com.kenjiber.modrealista.init.ModItems;
import com.kenjiber.modrealista.init.ModMetal;
import net.minecraft.item.Item;

import java.util.ArrayList;
import java.util.List;

/**
 * Tabla central de recetas de fundición. Si quieres cambiar una proporción
 * (ej. que el Bronce use 4 Cobre en vez de 3), este es el único lugar que
 * hay que tocar — no hace falta editar el BlockEntity.
 * <p>
 * Se definieron dos tipos de receta:
 *  - {@link Purificacion}: Alto Horno de Cobre. 4 Fragmentos Crudos de UN
 *    metal + Molde (no se consume) + combustible -> 1 Lingote Puro.
 *  - {@link Aleacion}: Horno de Fusión (Básico o Avanzado). 2 ingredientes
 *    en proporciones libres + Molde (no se consume) + combustible -> 1
 *    Lingote de aleación.
 */
public final class ModFusionRecipes {

	private ModFusionRecipes() {}

	/** horno = 1 (Básico) o 2 (Avanzado); tiempoTicks por defecto 200 (10s), igual que el horno vanilla. */
	public record Aleacion(Item ingrediente1, int cantidad1, Item ingrediente2, int cantidad2,
							Item resultado, int hornoRequerido, int tiempoTicks) {}

	public record Purificacion(Item fragmento, int cantidadFragmentos, Item resultado, int tiempoTicks) {}

	public static final List<Aleacion> ALEACIONES = new ArrayList<>();
	public static final List<Purificacion> PURIFICACIONES = new ArrayList<>();

	public static void construir() {
		ALEACIONES.clear();
		PURIFICACIONES.clear();

		// ---- Horno de Fusión BÁSICO (horno = 1) ----
		agregarAleacion(ModMetal.COBRE, 3, ModMetal.ESTANO, 1, ModMetal.BRONCE, 1, 200);
		agregarAleacion(ModMetal.ALUMINIO, 1, ModMetal.COBRE, 1, ModMetal.DURALUMINIO, 1, 200);
		agregarAleacion(ModMetal.PLATA, 1, ModMetal.ORO, 1, ModMetal.ELECTRO, 1, 200);

		// ---- Horno de Fusión AVANZADO (horno = 2) ----
		// Acero usa Carbón (mineral vanilla) en vez de un ModMetal; se registra aparte.
		ALEACIONES.add(new Aleacion(
				ModItems.LINGOTES.get(ModMetal.HIERRO), 1,
				net.minecraft.item.Items.COAL, 1,
				ModItems.LINGOTES.get(ModMetal.ACERO), 2, 240));
		ALEACIONES.add(new Aleacion(
				net.minecraft.item.Items.NETHERITE_INGOT, 1,
				ModItems.LINGOTES.get(ModMetal.TITANIO), 2,
				ModItems.LINGOTES.get(ModMetal.NETHERITE_TITANIO), 2, 300));
		ALEACIONES.add(new Aleacion(
				net.minecraft.item.Items.NETHERITE_INGOT, 1,
				ModItems.LINGOTES.get(ModMetal.TUNGSTENO), 2,
				ModItems.LINGOTES.get(ModMetal.NETHERITE_TUNGSTENO), 2, 300));

		// ---- Alto Horno de Cobre: purificación de fragmentos ----
		agregarPurificacion(ModMetal.HIERRO, 4, 200);
		agregarPurificacion(ModMetal.PLATA, 4, 200);
		agregarPurificacion(ModMetal.ORO, 4, 200);
		agregarPurificacion(ModMetal.TITANIO, 4, 260);
		agregarPurificacion(ModMetal.TUNGSTENO, 4, 260);
	}

	private static void agregarAleacion(ModMetal m1, int c1, ModMetal m2, int c2, ModMetal resultado, int horno, int ticks) {
		ALEACIONES.add(new Aleacion(
				ModItems.LINGOTES.get(m1), c1,
				ModItems.LINGOTES.get(m2), c2,
				ModItems.LINGOTES.get(resultado), horno, ticks));
	}

	private static void agregarPurificacion(ModMetal metal, int cantidadFragmentos, int ticks) {
		PURIFICACIONES.add(new Purificacion(
				ModItems.FRAGMENTOS_CRUDOS.get(metal), cantidadFragmentos,
				ModItems.LINGOTES.get(metal), ticks));
	}

	/** Busca una receta de aleación que coincida EXACTAMENTE (en cualquier orden de slots) con los 2 items dados. */
	public static Aleacion buscarAleacion(Item itemSlot1, int cantSlot1, Item itemSlot2, int cantSlot2, int hornoTier) {
		for (Aleacion a : ALEACIONES) {
			if (a.hornoRequerido() > hornoTier) continue;
			boolean directo = a.ingrediente1() == itemSlot1 && cantSlot1 >= a.cantidad1()
					&& a.ingrediente2() == itemSlot2 && cantSlot2 >= a.cantidad2();
			boolean invertido = a.ingrediente1() == itemSlot2 && cantSlot2 >= a.cantidad1()
					&& a.ingrediente2() == itemSlot1 && cantSlot1 >= a.cantidad2();
			if (directo || invertido) return a;
		}
		return null;
	}

	public static Purificacion buscarPurificacion(Item fragmento, int cantidad) {
		for (Purificacion p : PURIFICACIONES) {
			if (p.fragmento() == fragmento && cantidad >= p.cantidadFragmentos()) return p;
		}
		return null;
	}
}
