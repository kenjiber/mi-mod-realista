package com.kenjiber.modrealista.block.entity;

import com.kenjiber.modrealista.init.ModBlockEntities;
import com.kenjiber.modrealista.init.ModItems;
import com.kenjiber.modrealista.menu.AltoHornoScreenHandler;
import com.kenjiber.modrealista.recipe.ModFusionRecipes;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventories;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Alto Horno de Cobre: purifica 4 Fragmentos Crudos de UN metal (slot 0) +
 * Molde reutilizable (slot 1, no se consume) + combustible (slot 2) en
 * 1 Lingote Puro (slot 3). Ver {@link ModFusionRecipes#PURIFICACIONES}.
 */
public class AltoHornoBlockEntity extends BlockEntity
		implements Inventory, ExtendedScreenHandlerFactory<BlockPos> {

	public static final int SLOT_FRAGMENTOS = 0;
	public static final int SLOT_MOLDE = 1;
	public static final int SLOT_COMBUSTIBLE = 2;
	public static final int SLOT_SALIDA = 3;
	private static final int TAMANO_INVENTARIO = 4;

	private final DefaultedList<ItemStack> inventario = DefaultedList.ofSize(TAMANO_INVENTARIO, ItemStack.EMPTY);

	private int progreso = 0;
	private int tiempoTotalNecesario = 200;
	private int combustibleRestante = 0;
	private int combustibleMaximoActual = 0;

	public AltoHornoBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.ALTO_HORNO_ENTITY, pos, state);
	}

	public float getProgreso() {
		return tiempoTotalNecesario == 0 ? 0 : (float) progreso / tiempoTotalNecesario;
	}

	// --- Accesores usados por el PropertyDelegate (sincronización con el cliente para animar la GUI) ---
	public int getProgresoRaw() { return progreso; }
	public void setProgresoRaw(int v) { progreso = v; }
	public int getTiempoTotalNecesarioRaw() { return tiempoTotalNecesario; }
	public void setTiempoTotalNecesarioRaw(int v) { tiempoTotalNecesario = v; }
	public int getCombustibleRestanteRaw() { return combustibleRestante; }
	public void setCombustibleRestanteRaw(int v) { combustibleRestante = v; }
	public int getCombustibleMaximoRaw() { return combustibleMaximoActual; }
	public void setCombustibleMaximoRaw(int v) { combustibleMaximoActual = v; }

	public static <T extends BlockEntity> void tick(World world, BlockPos pos, BlockState state, T be) {
		if (!(be instanceof AltoHornoBlockEntity horno)) return;
		if (world.isClient) return;
		horno.tickServidor((ServerWorld) world);
	}

	private void tickServidor(ServerWorld world) {
		ItemStack fragmentos = inventario.get(SLOT_FRAGMENTOS);
		ModFusionRecipes.Purificacion receta =
				ModFusionRecipes.buscarPurificacion(fragmentos.getItem(), fragmentos.getCount());

		boolean puedeProcesar = puedeProcesar(receta);

		// 🔧 FIX: Si no puede procesar, apagar el horno (aunque quede combustible)
		if (!puedeProcesar) {
			if (combustibleRestante <= 0) progreso = 0;
			actualizarEncendido(world, false);
			markDirty();
			return;
		}

		if (combustibleRestante <= 0) {
			ItemStack combustible = inventario.get(SLOT_COMBUSTIBLE);
			int valor = com.kenjiber.modrealista.util.ModFuel.tiempoDeQuemado(combustible);
			if (valor > 0) {
				combustibleRestante = valor;
				combustibleMaximoActual = valor;
				combustible.decrement(1);
			}
		}

		if (combustibleRestante > 0) {
			combustibleRestante--;
			tiempoTotalNecesario = receta.tiempoTicks();
			progreso++;
			if (progreso >= tiempoTotalNecesario) {
				progreso = 0;
				fragmentos.decrement(receta.cantidadFragmentos());
				if (inventario.get(SLOT_SALIDA).isEmpty()) {
					inventario.set(SLOT_SALIDA, new ItemStack(receta.resultado()));
				} else {
					inventario.get(SLOT_SALIDA).increment(1);
				}
			}
		}
		actualizarEncendido(world, true);
		markDirty();
	}

	/**
	 * Comprueba si hay una receta válida, hay molde, y hay espacio en la salida.
	 * Se extrae a un método para poder reusarlo desde tickServidor y readNbt.
	 */
	private boolean puedeProcesar(ModFusionRecipes.Purificacion receta) {
		if (receta == null) return false;

		boolean tieneMolde = inventario.get(SLOT_MOLDE).isOf(ModItems.molde_de_fundicion);
		if (!tieneMolde) return false;

		ItemStack salida = inventario.get(SLOT_SALIDA);
		return salida.isEmpty()
				|| (salida.isOf(receta.resultado())
					&& salida.getCount() < salida.getMaxCount());
	}

	/**
	 * 🔧 FIX: Sincroniza la propiedad de bloque "lit" (usada por el modelo
	 * apagado/encendido) con el estado real del horno.
	 *
	 * Ahora el horno SOLO se ve encendido si está purificando activamente
	 * (combustible + receta válida + molde + espacio en la salida).
	 *
	 * Además, usa NOTIFY_LISTENERS | FORCE_STATE para garantizar que el paquete
	 * se envíe al cliente aunque el bloque esté lejos o en un chunk recién cargado.
	 */
	private void actualizarEncendido(ServerWorld world, boolean puedeProcesar) {
		boolean encendidoAhora = combustibleRestante > 0 && puedeProcesar;
		BlockState estado = world.getBlockState(pos);

		if (estado.contains(Properties.LIT)
				&& estado.get(Properties.LIT) != encendidoAhora) {
			world.setBlockState(pos,
					estado.with(Properties.LIT, encendidoAhora),
					Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
		}
	}

	// ============ Persistencia (NBT) ============

	@Override
	protected void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
		super.readNbt(nbt, registries);
		Inventories.readNbt(nbt, inventario, registries);
		progreso = nbt.getInt("Progreso");
		tiempoTotalNecesario = nbt.getInt("TiempoTotal");
		combustibleRestante = nbt.getInt("Combustible");
		combustibleMaximoActual = nbt.getInt("CombustibleMax");

		// 🔧 FIX: reconciliar el estado LIT al cargar el chunk.
		// Si el mundo se cerró con el horno encendido pero ya no puede procesar,
		// forzar LIT=false para evitar la "textura de encendido pegada".
		if (world != null && !world.isClient) {
			ItemStack fragmentos = inventario.get(SLOT_FRAGMENTOS);
			ModFusionRecipes.Purificacion receta =
					ModFusionRecipes.buscarPurificacion(fragmentos.getItem(), fragmentos.getCount());
			boolean puedeProcesar = puedeProcesar(receta);
			boolean encendidoAhora = combustibleRestante > 0 && puedeProcesar;

			BlockState estado = world.getBlockState(pos);
			if (estado.contains(Properties.LIT)
					&& estado.get(Properties.LIT) != encendidoAhora) {
				world.setBlockState(pos,
						estado.with(Properties.LIT, encendidoAhora),
						Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
			}
		}
	}

	@Override
	protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
		super.writeNbt(nbt, registries);
		Inventories.writeNbt(nbt, inventario, registries);
		nbt.putInt("Progreso", progreso);
		nbt.putInt("TiempoTotal", tiempoTotalNecesario);
		nbt.putInt("Combustible", combustibleRestante);
		nbt.putInt("CombustibleMax", combustibleMaximoActual);
	}

	// ============ Inventory ============

	@Override public int size() { return TAMANO_INVENTARIO; }
	@Override public boolean isEmpty() { return inventario.stream().allMatch(ItemStack::isEmpty); }
	@Override public ItemStack getStack(int slot) { return inventario.get(slot); }
	@Override public ItemStack removeStack(int slot, int amount) { return Inventories.splitStack(inventario, slot, amount); }
	@Override public ItemStack removeStack(int slot) { return Inventories.removeStack(inventario, slot); }
	@Override public void setStack(int slot, ItemStack stack) { inventario.set(slot, stack); }

	@Override
	public void markDirty() {
		super.markDirty();
		if (world != null) world.updateListeners(pos, getCachedState(), getCachedState(), 3);
	}

	@Override
	public boolean canPlayerUse(PlayerEntity player) {
		return world != null && world.getBlockEntity(pos) == this
				&& player.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 64.0;
	}
	@Override public void clear() { inventario.clear(); }

	// ============ ExtendedScreenHandlerFactory ============

	@Override
	public Text getDisplayName() {
		return Text.translatable("block.modrealista.alto_horno_de_cobre");
	}

	@Override
	public BlockPos getScreenOpeningData(ServerPlayerEntity player) {
		return this.pos;
	}

	@Override
	public ScreenHandler createMenu(int syncId, PlayerInventory playerInventory, PlayerEntity player) {
		return new AltoHornoScreenHandler(syncId, playerInventory, this.pos);
	}
}