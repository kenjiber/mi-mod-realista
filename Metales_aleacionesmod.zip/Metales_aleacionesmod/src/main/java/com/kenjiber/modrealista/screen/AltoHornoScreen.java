package com.kenjiber.modrealista.screen;

import com.kenjiber.modrealista.ModRealista;
import com.kenjiber.modrealista.menu.AltoHornoScreenHandler;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Pantalla del Alto Horno de Cobre. El fondo es nuestra textura propia;
 * la llama y la flecha de progreso reutilizan los sprites del horno
 * vainilla (se ven y animan exactamente igual).
 */
public class AltoHornoScreen extends HandledScreen<AltoHornoScreenHandler> {

	private static final Identifier TEXTURA = Identifier.of(ModRealista.MOD_ID, "textures/gui/container/alto_horno_de_cobre.png");

	// Sprites vainilla del horno normal (mismo tamaño en el horno de fusión/alto horno).
	private static final Identifier LLAMA = Identifier.ofVanilla("container/furnace/lit_progress");
	private static final Identifier FLECHA = Identifier.ofVanilla("container/furnace/burn_progress");

	// Posiciones dentro de nuestra GUI (coinciden con donde están los slots de combustible/salida).
	private static final int LLAMA_X = 56, LLAMA_Y = 36, LLAMA_W = 14, LLAMA_H = 14;
	private static final int FLECHA_X = 79, FLECHA_Y = 34, FLECHA_W = 22, FLECHA_H = 16;

	public AltoHornoScreen(AltoHornoScreenHandler handler, PlayerInventory inventory, Text title) {
		super(handler, inventory, title);
		this.backgroundWidth = 176;
		this.backgroundHeight = 166;
	}

	@Override
	protected void drawBackground(DrawContext context, float delta, int mouseX, int mouseY) {
		int x = (width - backgroundWidth) / 2;
		int y = (height - backgroundHeight) / 2;
		context.drawTexture(TEXTURA, x, y, 0, 0, backgroundWidth, backgroundHeight, 176, 166);

		// Llama: se "vacía" de abajo hacia arriba a medida que se consume el combustible.
		float combustible = handler.getCombustibleFraccion();
		int alturaLlama = Math.round(LLAMA_H * combustible);
		if (alturaLlama > 0) {
			context.drawTexture(LLAMA, x + LLAMA_X, y + LLAMA_Y + (LLAMA_H - alturaLlama),
					0, LLAMA_H - alturaLlama, LLAMA_W, alturaLlama, LLAMA_W, LLAMA_H);
		}

		// Flecha de progreso: se rellena de izquierda a derecha.
		float progreso = handler.getProgresoFraccion();
		int anchoFlecha = Math.round(FLECHA_W * progreso);
		if (anchoFlecha > 0) {
			context.drawTexture(FLECHA, x + FLECHA_X, y + FLECHA_Y, 0, 0, anchoFlecha, FLECHA_H, FLECHA_W, FLECHA_H);
		}
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		this.drawMouseoverTooltip(context, mouseX, mouseY);
	}
}
