package com.kenjiber.modrealista.world;

import com.kenjiber.modrealista.init.ModItems;
import com.kenjiber.modrealista.init.ModMetal;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

/**
 * Reemplaza el drop de las menas vanilla (hierro, oro, cobre) por fragmentos del mod.
 * El jugador debe fundir el fragmento para obtener el lingote.
 */
public class ModLootTables {

    private static final RegistryKey<LootTable> IRON_ORE = key("iron_ore");
    private static final RegistryKey<LootTable> DEEPSLATE_IRON_ORE = key("deepslate_iron_ore");
    private static final RegistryKey<LootTable> GOLD_ORE = key("gold_ore");
    private static final RegistryKey<LootTable> DEEPSLATE_GOLD_ORE = key("deepslate_gold_ore");
    private static final RegistryKey<LootTable> NETHER_GOLD_ORE = key("nether_gold_ore");
    private static final RegistryKey<LootTable> COPPER_ORE = key("copper_ore");
    private static final RegistryKey<LootTable> DEEPSLATE_COPPER_ORE = key("deepslate_copper_ore");

    private static RegistryKey<LootTable> key(String name) {
        return RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.ofVanilla("blocks/" + name));
    }

    public static void registrar() {
        // REEMPLAZAR: la mena ya no da el lingote vanilla, da el fragmento del mod.
        LootTableEvents.REPLACE.register((key, original, source, registries) -> {
            if (key.equals(IRON_ORE) || key.equals(DEEPSLATE_IRON_ORE)) {
                return dropSolo(ModItems.FRAGMENTOS_CRUDOS.get(ModMetal.HIERRO));
            }
            if (key.equals(GOLD_ORE) || key.equals(DEEPSLATE_GOLD_ORE) || key.equals(NETHER_GOLD_ORE)) {
                return dropSolo(ModItems.FRAGMENTOS_CRUDOS.get(ModMetal.ORO));
            }
            if (key.equals(COPPER_ORE) || key.equals(DEEPSLATE_COPPER_ORE)) {
                return dropSolo(ModItems.FRAGMENTOS_CRUDOS.get(ModMetal.COBRE));
            }
            return null; // null = no modificar esta loot table
        });
    }

    private static LootTable dropSolo(net.minecraft.item.Item item) {
        return LootTable.builder()
                .pool(LootPool.builder()
                        .rolls(ConstantLootNumberProvider.create(1))
                        .with(ItemEntry.builder(item))
                        .build())
                .build();
    }
}