package com.kenjiber.modrealista.init;

import com.kenjiber.modrealista.menu.AltoHornoScreenHandler;
import com.kenjiber.modrealista.menu.FusionFurnaceScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

public final class ModScreenHandlers {

	private ModScreenHandlers() {}

	public static ScreenHandlerType<AltoHornoScreenHandler> ALTO_HORNO;
	public static ScreenHandlerType<FusionFurnaceScreenHandler> HORNO_DE_FUSION;

	// CAMBIO: Declaramos el codec como PacketCodec<ByteBuf, BlockPos>
	// (ByteBuf es supertipo de RegistryByteBuf, así que es válido).
	public static final PacketCodec<PacketByteBuf, BlockPos> BLOCK_POS_PACKET_CODEC =
			BlockPos.PACKET_CODEC.cast();

	public static void registrarTodo() {
		ALTO_HORNO = Registry.register(
				Registries.SCREEN_HANDLER,
				RegistryKey.of(RegistryKeys.SCREEN_HANDLER, Identifier.of(MOD_ID, "alto_horno_de_cobre")),
				new ExtendedScreenHandlerType<>(AltoHornoScreenHandler::new, BLOCK_POS_PACKET_CODEC)
		);

		HORNO_DE_FUSION = Registry.register(
				Registries.SCREEN_HANDLER,
				RegistryKey.of(RegistryKeys.SCREEN_HANDLER, Identifier.of(MOD_ID, "horno_de_fusion")),
				new ExtendedScreenHandlerType<>(FusionFurnaceScreenHandler::new, BLOCK_POS_PACKET_CODEC)
		);
	}
}