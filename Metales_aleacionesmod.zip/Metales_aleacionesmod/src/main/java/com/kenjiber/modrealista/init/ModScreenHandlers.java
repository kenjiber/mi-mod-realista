package com.kenjiber.modrealista.init;

import com.kenjiber.modrealista.menu.AltoHornoScreenHandler;
import com.kenjiber.modrealista.menu.FusionFurnaceScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

public final class ModScreenHandlers {

	private ModScreenHandlers() {}

	public static ScreenHandlerType<AltoHornoScreenHandler> ALTO_HORNO;
	public static ScreenHandlerType<FusionFurnaceScreenHandler> HORNO_DE_FUSION;

	// 1. Definimos el PacketCodec para BlockPos.
	//    Esto le dice al juego cómo empaquetar y desempaquetar la posición del bloque.
	public static final PacketCodec<RegistryByteBuf, BlockPos> BLOCK_POS_PACKET_CODEC = BlockPos.PACKET_CODEC;

	public static void registrarTodo() {
		// CAMBIO: Registry.register(...) en lugar de Registries.SCREEN_HANDLER.add(...)
		ALTO_HORNO = Registry.register(
				Registries.SCREEN_HANDLER,
				RegistryKey.of(RegistryKeys.SCREEN_HANDLER, Identifier.of(MOD_ID, "alto_horno_de_cobre")),
				// CAMBIO: Ahora se pasa el PacketCodec como segundo argumento
				new ExtendedScreenHandlerType<>(AltoHornoScreenHandler::new, BLOCK_POS_PACKET_CODEC)
		);

		HORNO_DE_FUSION = Registry.register(
				Registries.SCREEN_HANDLER,
				RegistryKey.of(RegistryKeys.SCREEN_HANDLER, Identifier.of(MOD_ID, "horno_de_fusion")),
				new ExtendedScreenHandlerType<>(FusionFurnaceScreenHandler::new, BLOCK_POS_PACKET_CODEC)
		);
	}
}