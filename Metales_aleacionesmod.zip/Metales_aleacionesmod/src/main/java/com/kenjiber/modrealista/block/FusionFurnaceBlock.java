package com.kenjiber.modrealista.block;

import com.kenjiber.modrealista.block.entity.FusionFurnaceBlockEntity;
import com.kenjiber.modrealista.init.ModBlockEntities;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.NamedScreenHandlerFactory;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Horno de Fusión: bloque con block entity propio que combina DOS lingotes
 * (no uno solo, como el horno vanilla) para crear una aleación.
 * <p>
 * Se usa la misma clase para el Tier 1 (Básico) y Tier 2 (Avanzado); lo único
 * que cambia entre ambos es el {@code tier}, que el BlockEntity usa para
 * filtrar qué recetas de aleación puede procesar.
 */
public class FusionFurnaceBlock extends BlockWithEntity {

    /** 🔧 NUEVO: expuesto como campo público para que ModBlocks pueda referenciarlo en la luminancia. */
    public static final BooleanProperty LIT = Properties.LIT;

    public static final MapCodec<FusionFurnaceBlock> CODEC = RecordCodecBuilder.mapCodec(instance ->
        instance.group(
            createSettingsCodec(),
            com.mojang.serialization.Codec.INT.fieldOf("tier").forGetter(block -> block.tier)
        ).apply(instance, FusionFurnaceBlock::new)
    );

    private final int tier; // 1 = Básico (carbón), 2 = Avanzado (blaze/lava)

    public FusionFurnaceBlock(Settings settings, int tier) {
        super(settings);
        this.tier = tier;
        setDefaultState(getStateManager().getDefaultState().with(LIT, false));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(LIT);
    }

    public int getTier() {
        return tier;
    }

    @Override
    protected MapCodec<? extends BlockWithEntity> getCodec() {
        return CODEC;
    }

    @Override
    public BlockRenderType getRenderType(BlockState state) {
        return BlockRenderType.MODEL;
    }

    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return tier == 1
                ? ModBlockEntities.HORNO_FUSION_BASICO_ENTITY.instantiate(pos, state)
                : ModBlockEntities.HORNO_FUSION_AVANZADO_ENTITY.instantiate(pos, state);
    }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState state, BlockEntityType<T> type) {
        return FusionFurnaceBlockEntity::tick;
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (world.isClient) return ActionResult.SUCCESS;
        BlockEntity be = world.getBlockEntity(pos);
        if (be instanceof NamedScreenHandlerFactory factory) {
            player.openHandledScreen(factory);
        }
        return ActionResult.CONSUME;
    }
}