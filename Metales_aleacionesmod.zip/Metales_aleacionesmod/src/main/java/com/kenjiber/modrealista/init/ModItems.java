package com.kenjiber.modrealista.init;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ArrowItem;
import net.minecraft.item.AxeItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.Item;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.ShieldItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

public final class ModItems {

	private ModItems() {}

	// Mapas de acceso rápido: metal -> item concreto. Otras clases (recetas,
	// creative tab, etc.) los usan en vez de tener que reconstruir el Identifier.
	public static final Map<ModMetal, Item> LINGOTES = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> FRAGMENTOS_CRUDOS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, PickaxeItem> PICOS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, AxeItem> HACHAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ShovelItem> PALAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, SwordItem> ESPADAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ArmorItem> CASCOS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ArmorItem> PECHERAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ArmorItem> PANTALONES = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ArmorItem> BOTAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ShieldItem> ESCUDOS = new EnumMap<>(ModMetal.class);

	/** Molde reutilizable que el Alto Horno pide junto a 4 fragmentos para purificar un lingote. */
	public static Item molde_de_fundicion;
	public static Item molde_de_arcilla_crudo;

	public static void registrarTodo() {
		molde_de_fundicion = registrar("molde_de_fundicion", new Item(new Item.Settings()));
		molde_de_arcilla_crudo = registrar("molde_de_arcilla_crudo", new Item(new Item.Settings()));

		for (ModMetal metal : ModMetal.values()) {
			// Lingote: todo metal/aleación tiene lingote, incluido Estaño.
			LINGOTES.put(metal, registrar("lingote_" + metal.id, new Item(new Item.Settings())));

			// Fragmento crudo: solo metales que se minan del mundo (no aleaciones).
			if (metal.tieneMineralEnElMundo()) {
				FRAGMENTOS_CRUDOS.put(metal, registrar("fragmento_crudo_" + metal.id, new Item(new Item.Settings())));
			}

			ToolMaterial material = ModToolMaterials.get(metal);

			switch (metal.catalogo) {
				case SET_COMPLETO, SET_COMPLETO_HERRERIA -> {
					registrarSetDeHerramientas(metal, material);
					registrarArmadura(metal);
					if (metal == ModMetal.ALUMINIO) {
						// Arco Ligero + Flechas de Alcance mencionados para Aluminio.
						registrar("arco_ligero_de_aluminio", new BowItem(new Item.Settings().maxDamage(300)));
						registrar("flecha_de_alcance_aluminio", new ArrowItem(new Item.Settings()));
					}
				}
				case ESPECIAL_ARMA_ESCUDO -> { // Plata
					ESPADAS.put(metal, registrar("espada_de_" + metal.id,
							new SwordItem(material, new Item.Settings().attributeModifiers(
									// CAMBIO: (int) metal.danoAtaque
									SwordItem.createAttributeModifiers(material, (int) metal.danoAtaque, metal.velocidadAtaque - 4.0f)))));
					PICOS.put(metal, registrar("pico_de_" + metal.id,
							new PickaxeItem(material, new Item.Settings().attributeModifiers(
									PickaxeItem.createAttributeModifiers(material, 1, metal.velocidadAtaque - 4.0f)))));
					ESCUDOS.put(metal, registrar("escudo_de_" + metal.id,
							new ShieldItem(new Item.Settings().maxDamage(metal.durabilidadHerramienta * 4))));
				}
				case ESPECIAL_SOLO_HERRAMIENTA -> { // Tungsteno puro
					PICOS.put(metal, registrar("pico_de_" + metal.id,
							new PickaxeItem(material, new Item.Settings().attributeModifiers(
									PickaxeItem.createAttributeModifiers(material, 1, metal.velocidadAtaque - 4.0f)))));
					HACHAS.put(metal, registrar("maza_pesada_de_" + metal.id,
							new AxeItem(material, new Item.Settings().attributeModifiers(
									AxeItem.createAttributeModifiers(material, metal.danoAtaque + 2.0f, metal.velocidadAtaque - 4.0f)))));
				}
				case ESPECIAL_LIGERO, ESPECIAL_MAGICO -> { // Duraluminio / Electro
					registrarSetDeHerramientas(metal, material);
				}
				case SOLO_INGREDIENTE -> { /* Estaño: solo el lingote registrado arriba. */ }
			}
		}
	}

	private static void registrarSetDeHerramientas(ModMetal metal, ToolMaterial material) {
		PICOS.put(metal, registrar("pico_de_" + metal.id,
				new PickaxeItem(material, new Item.Settings().attributeModifiers(
						PickaxeItem.createAttributeModifiers(material, 1, metal.velocidadAtaque - 4.0f)))));
		HACHAS.put(metal, registrar("hacha_de_" + metal.id,
				new AxeItem(material, new Item.Settings().attributeModifiers(
						AxeItem.createAttributeModifiers(material, metal.danoAtaque, metal.velocidadAtaque - 4.0f)))));
		PALAS.put(metal, registrar("pala_de_" + metal.id,
				new ShovelItem(material, new Item.Settings().attributeModifiers(
						ShovelItem.createAttributeModifiers(material, 1.5f, metal.velocidadAtaque - 4.0f)))));
		ESPADAS.put(metal, registrar("espada_de_" + metal.id,
				new SwordItem(material, new Item.Settings().attributeModifiers(
						// CAMBIO: (int) metal.danoAtaque
						SwordItem.createAttributeModifiers(material, (int) metal.danoAtaque, metal.velocidadAtaque - 4.0f)))));
	}

	private static void registrarArmadura(ModMetal metal) {
		RegistryEntry<ArmorMaterial> mat = ModArmorMaterials.get(metal);
		CASCOS.put(metal, registrar("casco_de_" + metal.id,
				new ArmorItem(mat, ArmorItem.Type.HELMET, new Item.Settings())));
		PECHERAS.put(metal, registrar("pechera_de_" + metal.id,
				new ArmorItem(mat, ArmorItem.Type.CHESTPLATE, new Item.Settings())));
		PANTALONES.put(metal, registrar("pantalones_de_" + metal.id,
				new ArmorItem(mat, ArmorItem.Type.LEGGINGS, new Item.Settings())));
		BOTAS.put(metal, registrar("botas_de_" + metal.id,
				new ArmorItem(mat, ArmorItem.Type.BOOTS, new Item.Settings())));
	}

	@SuppressWarnings("unchecked")
	private static <T extends Item> T registrar(String path, T item) {
		Identifier id = Identifier.of(MOD_ID, path);
		RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id);
		// CAMBIO: Registry.register en lugar de Registries.ITEM.add
		return (T) Registry.register(Registries.ITEM, key, item);
	}
}