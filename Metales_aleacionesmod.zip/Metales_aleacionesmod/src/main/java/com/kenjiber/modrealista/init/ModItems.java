package com.kenjiber.modrealista.init;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ArrowItem;
import net.minecraft.item.AxeItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.Item;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.ShieldItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

public final class ModItems {

	private ModItems() {}

	// Mapas de acceso rápido: metal -> item concreto.
	public static final Map<ModMetal, Item> LINGOTES = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> FRAGMENTOS_CRUDOS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, PickaxeItem> PICOS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, AxeItem> HACHAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ShovelItem> PALAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, SwordItem> ESPADAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ArmorItem> CASCOS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ArmorItem> PECHERAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ArmorItem> PANTALONES = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ArmorItem> BOTAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ShieldItem> ESCUDOS = new EnumMap<>(ModMetal.class);

	/** Molde reutilizable que el Alto Horno pide junto a 4 fragmentos para purificar un lingote. */
	public static Item molde_de_fundicion;
	public static Item molde_de_arcilla_crudo;

	public static void registrarTodo() {
		molde_de_fundicion = registrar("molde_de_fundicion", new Item(new Item.Settings()));
		molde_de_arcilla_crudo = registrar("molde_de_arcilla_crudo", new Item(new Item.Settings()));

		for (ModMetal metal : ModMetal.values()) {

			// ==========================================================
			// HIERRO y ORO: usan lingotes vanilla, SIN herramientas/armaduras custom
			// ==========================================================
			if (metal.esVanilla()) {
				if (metal == ModMetal.HIERRO) {
					LINGOTES.put(metal, net.minecraft.item.Items.IRON_INGOT);
					FRAGMENTOS_CRUDOS.put(metal,
							registrar("fragmento_crudo_hierro", new Item(new Item.Settings())));
				} else {
					LINGOTES.put(metal, net.minecraft.item.Items.GOLD_INGOT);
					FRAGMENTOS_CRUDOS.put(metal,
							registrar("fragmento_crudo_oro", new Item(new Item.Settings())));
				}
				continue; // Sin herramientas ni armaduras custom
			}

			// ==========================================================
			// COBRE: lingote vanilla, PERO CON herramientas/armaduras custom
			// ==========================================================
			if (metal == ModMetal.COBRE) {
				// 1. Usamos el lingote de cobre vanilla
				LINGOTES.put(metal, net.minecraft.item.Items.COPPER_INGOT);
				// 2. Registramos el fragmento del mod
				FRAGMENTOS_CRUDOS.put(metal,
						registrar("fragmento_crudo_cobre", new Item(new Item.Settings())));
				// 3. NO hacemos continue: dejamos que el switch de abajo lo procese
				//    para crear sus herramientas y armaduras custom.
			} else {
				// Para el resto de metales, registramos el lingote del mod
				LINGOTES.put(metal, registrar("lingote_" + metal.id, new Item(new Item.Settings())));

				// Fragmento crudo (solo metales que se minan del mundo)
				if (metal.tieneMineralEnElMundo()) {
					FRAGMENTOS_CRUDOS.put(metal,
							registrar("fragmento_crudo_" + metal.id, new Item(new Item.Settings())));
				}
			}

			// ==========================================================
			// HERRAMIENTAS Y ARMADURAS (aplica a todos menos hierro/oro)
			// ==========================================================
			ToolMaterial material = ModToolMaterials.get(metal);

			switch (metal.catalogo) {
				case SET_COMPLETO, SET_COMPLETO_HERRERIA -> {
					registrarSetDeHerramientas(metal, material);
					registrarArmadura(metal);
					if (metal == ModMetal.ALUMINIO) {
						// Arco Ligero + Flechas de Alcance para Aluminio
						registrar("arco_ligero_de_aluminio",
								new BowItem(new Item.Settings().maxDamage(300)));
						registrar("flecha_de_alcance_aluminio",
								new ArrowItem(new Item.Settings()));
					}
				}
				case ESPECIAL_ARMA_ESCUDO -> { // Plata
					ESPADAS.put(metal, registrar("espada_de_" + metal.id,
							new SwordItem(material, new Item.Settings().attributeModifiers(
									SwordItem.createAttributeModifiers(material,
											(int) metal.danoAtaque, metal.velocidadAtaque - 4.0f)))));
					PICOS.put(metal, registrar("pico_de_" + metal.id,
							new PickaxeItem(material, new Item.Settings().attributeModifiers(
									PickaxeItem.createAttributeModifiers(material, 1,
											metal.velocidadAtaque - 4.0f)))));
					ESCUDOS.put(metal, registrar("escudo_de_" + metal.id,
							new ShieldItem(new Item.Settings()
									.maxDamage(metal.durabilidadHerramienta * 4))));
				}
				case ESPECIAL_SOLO_HERRAMIENTA -> { // Tungsteno puro
					PICOS.put(metal, registrar("pico_de_" + metal.id,
							new PickaxeItem(material, new Item.Settings().attributeModifiers(
									PickaxeItem.createAttributeModifiers(material, 1,
											metal.velocidadAtaque - 4.0f)))));
					HACHAS.put(metal, registrar("maza_pesada_de_" + metal.id,
							new AxeItem(material, new Item.Settings().attributeModifiers(
									AxeItem.createAttributeModifiers(material,
											metal.danoAtaque + 2.0f,
											metal.velocidadAtaque - 4.0f)))));
				}
				case ESPECIAL_LIGERO, ESPECIAL_MAGICO -> { // Duraluminio / Electro
					registrarSetDeHerramientas(metal, material);
				}
				case SOLO_INGREDIENTE -> { /* Estaño: solo el lingote */ }
			}
		}
	}

	private static void registrarSetDeHerramientas(ModMetal metal, ToolMaterial material) {
		PICOS.put(metal, registrar("pico_de_" + metal.id,
				new PickaxeItem(material, new Item.Settings().attributeModifiers(
						PickaxeItem.createAttributeModifiers(material, 1,
								metal.velocidadAtaque - 4.0f)))));
		HACHAS.put(metal, registrar("hacha_de_" + metal.id,
				new AxeItem(material, new Item.Settings().attributeModifiers(
						AxeItem.createAttributeModifiers(material, metal.danoAtaque,
								metal.velocidadAtaque - 4.0f)))));
		PALAS.put(metal, registrar("pala_de_" + metal.id,
				new ShovelItem(material, new Item.Settings().attributeModifiers(
						ShovelItem.createAttributeModifiers(material, 1.5f,
								metal.velocidadAtaque - 4.0f)))));
		ESPADAS.put(metal, registrar("espada_de_" + metal.id,
				new SwordItem(material, new Item.Settings().attributeModifiers(
						SwordItem.createAttributeModifiers(material, (int) metal.danoAtaque,
								metal.velocidadAtaque - 4.0f)))));
	}

	private static void registrarArmadura(ModMetal metal) {
		RegistryEntry<ArmorMaterial> mat = ModArmorMaterials.get(metal);
		int durBase = metal.armadura.durabilidadBase;

		CASCOS.put(metal, registrar("casco_de_" + metal.id,
				new ArmorItem(mat, ArmorItem.Type.HELMET,
						new Item.Settings().maxDamage(ArmorItem.Type.HELMET.getMaxDamage(durBase)))));
		PECHERAS.put(metal, registrar("pechera_de_" + metal.id,
				new ArmorItem(mat, ArmorItem.Type.CHESTPLATE,
						new Item.Settings().maxDamage(ArmorItem.Type.CHESTPLATE.getMaxDamage(durBase)))));
		PANTALONES.put(metal, registrar("pantalones_de_" + metal.id,
				new ArmorItem(mat, ArmorItem.Type.LEGGINGS,
						new Item.Settings().maxDamage(ArmorItem.Type.LEGGINGS.getMaxDamage(durBase)))));
		BOTAS.put(metal, registrar("botas_de_" + metal.id,
				new ArmorItem(mat, ArmorItem.Type.BOOTS,
						new Item.Settings().maxDamage(ArmorItem.Type.BOOTS.getMaxDamage(durBase)))));
	}

	@SuppressWarnings("unchecked")
	private static <T extends Item> T registrar(String path, T item) {
		Identifier id = Identifier.of(MOD_ID, path);
		RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id);
		return (T) Registry.register(Registries.ITEM, key, item);
	}
}q