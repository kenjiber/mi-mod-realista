package com.kenjiber.modrealista.util;

import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

import java.util.Map;

/**
 * `net.minecraft.screen.FuelRegistry` no existe en 1.21.1 (esa API de
 * combustibles data-driven llegó en una versión posterior). Aquí usamos
 * directamente el mapa de combustibles que el horno vainilla ya construye
 * internamente (`AbstractFurnaceBlockEntity.createFuelTimeMap()`), que sí
 * es público y estable.
 */
public final class ModFuel {

	private ModFuel() {}

	private static Map<Item, Integer> MAPA;

	private static Map<Item, Integer> mapa() {
		if (MAPA == null) {
			MAPA = AbstractFurnaceBlockEntity.createFuelTimeMap();
		}
		return MAPA;
	}

	/** ¿Este ítem sirve como combustible? (mismo criterio que el horno vainilla). */
	public static boolean esCombustible(ItemStack stack) {
		return !stack.isEmpty() && mapa().containsKey(stack.getItem());
	}

	/** Cuántos ticks de quemado da 1 unidad de este ítem como combustible (0 si no aplica). */
	public static int tiempoDeQuemado(ItemStack stack) {
		if (stack.isEmpty()) return 0;
		return mapa().getOrDefault(stack.getItem(), 0);
	}
}
