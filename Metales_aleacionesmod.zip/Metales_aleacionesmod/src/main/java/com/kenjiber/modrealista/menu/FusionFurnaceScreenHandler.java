package com.kenjiber.modrealista.menu;

import com.kenjiber.modrealista.block.entity.FusionFurnaceBlockEntity;
import com.kenjiber.modrealista.init.ModItems;
import com.kenjiber.modrealista.init.ModScreenHandlers;
import com.kenjiber.modrealista.util.ModFuel;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.math.BlockPos;

/**
 * Horno de Fusión (Básico o Avanzado, mismo Screen para los dos):
 * 2 ranuras de entrada (metales distintos), 1 de molde, 1 de combustible,
 * 1 de salida (la aleación resultante).
 */
public class FusionFurnaceScreenHandler extends ScreenHandler {

	public static final int SLOT_ENTRADA_1 = 0;
	public static final int SLOT_ENTRADA_2 = 1;
	public static final int SLOT_MOLDE = 2;
	public static final int SLOT_COMBUSTIBLE = 3;
	public static final int SLOT_SALIDA = 4;

	private final Inventory inventarioHorno;

	// CAMBIO: Ahora el constructor recibe BlockPos en lugar de Inventory.
	// Esto es necesario para el ExtendedScreenHandlerType en 1.21.1.
	public FusionFurnaceScreenHandler(int syncId, PlayerInventory playerInventory, BlockPos pos) {
		super(ModScreenHandlers.HORNO_DE_FUSION, syncId);

		// Resolvemos el inventario desde el BlockEntity usando la posición
		BlockEntity be = playerInventory.player.getWorld().getBlockEntity(pos);
		if (be instanceof FusionFurnaceBlockEntity fusionFurnace) {
			this.inventarioHorno = fusionFurnace;
		} else {
			this.inventarioHorno = new SimpleInventory(5);
		}
		checkSize(inventarioHorno, 5);

		this.addSlot(new Slot(inventarioHorno, SLOT_ENTRADA_1, 35, 17));
		this.addSlot(new Slot(inventarioHorno, SLOT_ENTRADA_2, 80, 17));

		this.addSlot(new Slot(inventarioHorno, SLOT_MOLDE, 35, 53) {
			@Override
			public boolean canInsert(ItemStack stack) {
				return stack.isOf(ModItems.molde_de_fundicion);
			}
		});

		this.addSlot(new Slot(inventarioHorno, SLOT_COMBUSTIBLE, 80, 53) {
			@Override
			public boolean canInsert(ItemStack stack) {
				return ModFuel.esCombustible(stack);
			}
		});

		this.addSlot(new Slot(inventarioHorno, SLOT_SALIDA, 134, 35) {
			@Override
			public boolean canInsert(ItemStack stack) {
				return false;
			}
		});

		// Inventario del jugador (27 slots principales + 9 de hotbar).
		for (int fila = 0; fila < 3; fila++) {
			for (int col = 0; col < 9; col++) {
				this.addSlot(new Slot(playerInventory, col + fila * 9 + 9, 8 + col * 18, 84 + fila * 18));
			}
		}
		for (int col = 0; col < 9; col++) {
			this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 142));
		}
	}

	@Override
	public boolean canUse(PlayerEntity player) {
		return inventarioHorno.canPlayerUse(player);
	}

	@Override
	public ItemStack quickMove(PlayerEntity player, int index) {
		Slot slot = this.slots.get(index);
		if (slot == null || !slot.hasStack()) return ItemStack.EMPTY;
		ItemStack original = slot.getStack();
		ItemStack copia = original.copy();
		if (index < 5) {
			if (!this.insertItem(original, 5, this.slots.size(), true)) return ItemStack.EMPTY;
		} else {
			if (!this.insertItem(original, 0, 5, false)) return ItemStack.EMPTY;
		}
		if (original.isEmpty()) slot.setStack(ItemStack.EMPTY); else slot.markDirty();
		return copia;
	}
}