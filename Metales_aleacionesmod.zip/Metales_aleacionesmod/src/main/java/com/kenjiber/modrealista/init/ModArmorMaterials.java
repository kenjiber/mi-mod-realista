package com.kenjiber.modrealista.init;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Item;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

public final class ModArmorMaterials {

	private ModArmorMaterials() {}

	private static final Map<ModMetal, RegistryEntry<ArmorMaterial>> CACHE = new EnumMap<>(ModMetal.class);

	public static RegistryEntry<ArmorMaterial> get(ModMetal metal) {
		return CACHE.computeIfAbsent(metal, ModArmorMaterials::crear);
	}

	private static int encantabilidad(ModMetal metal) {
		return switch (metal) {
			case ORO -> 25;
			case TITANIO, NETHERITE_TITANIO, NETHERITE_TUNGSTENO -> 15;
			default -> 9;
		};
	}

	private static RegistryEntry<SoundEvent> sonidoEquipar(ModMetal metal) {
		return switch (metal) {
			case ORO -> SoundEvents.ITEM_ARMOR_EQUIP_GOLD;
			case NETHERITE_TITANIO, NETHERITE_TUNGSTENO -> SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE;
			default -> SoundEvents.ITEM_ARMOR_EQUIP_IRON;
		};
	}

	private static RegistryEntry<ArmorMaterial> crear(ModMetal metal) {
		ModMetal.ArmorStats s = metal.armadura;

		// 1. Defensa por pieza
		Map<ArmorItem.Type, Integer> defensaPorPieza = Map.of(
				ArmorItem.Type.BOOTS, s.botas,
				ArmorItem.Type.LEGGINGS, s.pantalones,
				ArmorItem.Type.CHESTPLATE, s.pechera,
				ArmorItem.Type.HELMET, s.casco
		);

		// 2. Ingrediente de reparación (en 1.21.1 es Supplier<Ingredient>)
		Supplier<Ingredient> repairIngredient =
				() -> Ingredient.ofItems(ModItems.LINGOTES.get(metal));

		// 3. Capas de armadura (una sola capa, con el ID del metal)
		List<ArmorMaterial.Layer> layers = List.of(
				new ArmorMaterial.Layer(Identifier.of(MOD_ID, metal.id))
		);

		// 4. Constructor: 7 parámetros EXACTOS en este orden
		ArmorMaterial material = new ArmorMaterial(
				defensaPorPieza,      // 1. Map<Type, Integer> defense
				encantabilidad(metal),// 2. int enchantability
				sonidoEquipar(metal), // 3. RegistryEntry<SoundEvent> equipSound
				repairIngredient,     // 4. Supplier<Ingredient> repairIngredient
				layers,               // 5. List<Layer> layers
				s.tenacidad,          // 6. float toughness
				0f                    // 7. float knockbackResistance
		);

		RegistryKey<ArmorMaterial> key = RegistryKey.of(RegistryKeys.ARMOR_MATERIAL,
				Identifier.of(MOD_ID, metal.id));
		Registry.register(Registries.ARMOR_MATERIAL, key, material);
		return Registries.ARMOR_MATERIAL.getEntry(key).orElseThrow(
				() -> new IllegalStateException("No se pudo registrar: " + metal.id));
	}
}