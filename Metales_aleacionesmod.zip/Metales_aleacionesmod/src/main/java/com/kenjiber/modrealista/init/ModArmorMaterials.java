package com.kenjiber.modrealista.init;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

public final class ModArmorMaterials {

	private ModArmorMaterials() {}

	private static final Map<ModMetal, RegistryEntry<ArmorMaterial>> CACHE = new EnumMap<>(ModMetal.class);

	public static RegistryEntry<ArmorMaterial> get(ModMetal metal) {
		return CACHE.computeIfAbsent(metal, ModArmorMaterials::crear);
	}

	private static int encantabilidad(ModMetal metal) {
		return switch (metal) {
			case ORO -> 25;
			case TITANIO, NETHERITE_TITANIO, NETHERITE_TUNGSTENO -> 15;
			default -> 9;
		};
	}

	// CAMBIO 1: Ahora devuelve RegistryEntry<SoundEvent> en lugar de SoundEvent
	private static RegistryEntry<SoundEvent> sonidoEquipar(ModMetal metal) {
		return switch (metal) {
			case ORO -> SoundEvents.ITEM_ARMOR_EQUIP_GOLD;
			case NETHERITE_TITANIO, NETHERITE_TUNGSTENO -> SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE;
			default -> SoundEvents.ITEM_ARMOR_EQUIP_IRON;
		};
	}

	private static RegistryEntry<ArmorMaterial> crear(ModMetal metal) {
		ModMetal.ArmorStats s = metal.armadura;

		Map<ArmorItem.Type, Integer> defensaPorPieza = Map.of(
				ArmorItem.Type.BOOTS, s.botas,
				ArmorItem.Type.LEGGINGS, s.pantalones,
				ArmorItem.Type.CHESTPLATE, s.pechera,
				ArmorItem.Type.HELMET, s.casco
		);

		// CAMBIO 2: En 1.21.1 el ingrediente de reparación es un TagKey<Item>, no un Ingredient.
		// Creamos una tag por metal. Debes crear el archivo JSON correspondiente en:
		// src/main/resources/data/modrealista/tags/item/repair/<metal.id>.json
		TagKey<Item> repairTag = TagKey.of(RegistryKeys.ITEM, Identifier.of(MOD_ID, "repair/" + metal.id));

		ArmorMaterial material = new ArmorMaterial(
				s.durabilidadBase,
				defensaPorPieza,
				encantabilidad(metal),
				sonidoEquipar(metal),
				s.tenacidad,
				0f, // resistencia a knockback plana
				repairTag
		);

		RegistryKey<ArmorMaterial> key = RegistryKey.of(RegistryKeys.ARMOR_MATERIAL, Identifier.of(MOD_ID, metal.id));

		// CAMBIO 3: Registrar y devolver el RegistryEntry correctamente
		Registry.register(Registries.ARMOR_MATERIAL, key, material);
		return Registries.ARMOR_MATERIAL.getEntry(key).orElseThrow(
				() -> new IllegalStateException("No se pudo registrar el ArmorMaterial: " + metal.id)
		);
	}
}