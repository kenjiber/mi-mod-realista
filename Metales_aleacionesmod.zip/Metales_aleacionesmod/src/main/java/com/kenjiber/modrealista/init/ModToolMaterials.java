package com.kenjiber.modrealista.init;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

public final class ModToolMaterials {

	private ModToolMaterials() {}

	private static final Map<ModMetal, ToolMaterial> CACHE = new EnumMap<>(ModMetal.class);

	private static TagKey<Block> tagParaNivel(int nivel) {
		return switch (nivel) {
			case 0 -> BlockTags.INCORRECT_FOR_WOODEN_TOOL;
			case 1 -> BlockTags.INCORRECT_FOR_STONE_TOOL;
			case 2 -> BlockTags.INCORRECT_FOR_IRON_TOOL;
			case 3 -> BlockTags.INCORRECT_FOR_DIAMOND_TOOL;
			default -> BlockTags.INCORRECT_FOR_NETHERITE_TOOL;
		};
	}

	public static ToolMaterial get(ModMetal metal) {
		return CACHE.computeIfAbsent(metal, ModToolMaterials::crear);
	}

	private static ToolMaterial crear(ModMetal metal) {
		int encantabilidad = switch (metal) {
			case ORO, ELECTRO -> 22;
			case TITANIO, NETHERITE_TITANIO, NETHERITE_TUNGSTENO -> 15;
			default -> 10;
		};

		TagKey<Block> incorrectBlocks = tagParaNivel(metal.nivelMinado);
		int durability = metal.durabilidadHerramienta;
		float speed = metal.velocidadMinado;
		float attackDamage = metal.danoAtaque;
		int enchantValue = encantabilidad;
		TagKey<Item> repairTag = TagKey.of(RegistryKeys.ITEM,
				Identifier.of(MOD_ID, "repair/" + metal.id));

		// CAMBIO: ToolMaterial es una interfaz en 1.21.1. Implementación anónima.
		return new ToolMaterial() {
			@Override public TagKey<Block> getInverseTag() { return incorrectBlocks; }
			@Override public int getDurability() { return durability; }
			@Override public float getMiningSpeedMultiplier() { return speed; }
			@Override public float getAttackDamage() { return attackDamage; }
			@Override public int getEnchantability() { return enchantValue; }
			@Override public TagKey<Item> getRepairIngredient() { return repairTag; }
		};
	}
}