package com.kenjiber.modrealista.init;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

/**
 * Traduce cada ModMetal a un {@link ToolMaterial} de vanilla (durabilidad,
 * velocidad de minado, nivel de minería, encantabilidad, sonido al equipar
 * y el "repair item" para el yunque).
 */
public final class ModToolMaterials {

	private ModToolMaterials() {}

	private static final Map<ModMetal, ToolMaterial> CACHE = new EnumMap<>(ModMetal.class);

	/** Nivel de minado de cada tier, usando los tags vanilla como referencia de "qué NO puede picar". */
	private static TagKey<Block> tagParaNivel(int nivel) {
		return switch (nivel) {
			case 0 -> BlockTags.INCORRECT_FOR_WOODEN_TOOL;
			case 1 -> BlockTags.INCORRECT_FOR_STONE_TOOL;
			case 2 -> BlockTags.INCORRECT_FOR_IRON_TOOL;
			case 3 -> BlockTags.INCORRECT_FOR_DIAMOND_TOOL;
			default -> BlockTags.INCORRECT_FOR_NETHERITE_TOOL;
		};
	}

	public static ToolMaterial get(ModMetal metal) {
		return CACHE.computeIfAbsent(metal, ModToolMaterials::crear);
	}

	private static ToolMaterial crear(ModMetal metal) {
		int encantabilidad = switch (metal) {
			case ORO, ELECTRO -> 22; // igual que oro vanilla: máxima encantabilidad
			case TITANIO, NETHERITE_TITANIO, NETHERITE_TUNGSTENO -> 15;
			default -> 10;
		};

		// CAMBIO: Ahora usamos la misma tag de reparación que las armaduras.
		// Debe existir el archivo: data/modrealista/tags/item/repair/<metal.id>.json
		TagKey<Item> repairTag = TagKey.of(RegistryKeys.ITEM,
				Identifier.of(MOD_ID, "repair/" + metal.id));

		// CAMBIO: Añadido el 6º parámetro (repairTag) al constructor de ToolMaterial
		return new ToolMaterial(
				tagParaNivel(metal.nivelMinado),  // 1. incorrectBlocksForDrops
				metal.durabilidadHerramienta,     // 2. durability
				metal.velocidadMinado,            // 3. speed
				metal.danoAtaque,                 // 4. attackDamageBonus
				encantabilidad,                   // 5. enchantmentValue
				repairTag                         // 6. repairIngredient (NUEVO)
		);
	}
}