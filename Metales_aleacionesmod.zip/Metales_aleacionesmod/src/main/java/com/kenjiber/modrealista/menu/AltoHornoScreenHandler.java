package com.kenjiber.modrealista.menu;

import com.kenjiber.modrealista.block.entity.AltoHornoBlockEntity;
import com.kenjiber.modrealista.init.ModItems;
import com.kenjiber.modrealista.init.ModScreenHandlers;
import com.kenjiber.modrealista.util.ModFuel;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.math.BlockPos;

/**
 * Igual que el ScreenHandler del Alto Horno vainilla, pero con una 4ta
 * ranura extra para el Molde Reutilizable (que no se consume).
 */
public class AltoHornoScreenHandler extends ScreenHandler {

	public static final int SLOT_FRAGMENTOS = 0;
	public static final int SLOT_MOLDE = 1;
	public static final int SLOT_COMBUSTIBLE = 2;
	public static final int SLOT_SALIDA = 3;

	private final Inventory inventarioHorno;

	// CAMBIO: Ahora el constructor recibe BlockPos en lugar de Inventory.
	// Esto es necesario para el ExtendedScreenHandlerType en 1.21.1.
	public AltoHornoScreenHandler(int syncId, PlayerInventory playerInventory, BlockPos pos) {
		super(ModScreenHandlers.ALTO_HORNO, syncId);

		// Resolvemos el inventario desde el BlockEntity usando la posición
		BlockEntity be = playerInventory.player.getWorld().getBlockEntity(pos);
		if (be instanceof AltoHornoBlockEntity altoHorno) {
			this.inventarioHorno = altoHorno;
		} else {
			this.inventarioHorno = new SimpleInventory(4);
		}
		checkSize(inventarioHorno, 4);

		// Ranura de fragmentos (input tipo "mineral").
		this.addSlot(new Slot(inventarioHorno, SLOT_FRAGMENTOS, 56, 17));

		// Ranura del molde: solo acepta molde_de_fundicion.
		this.addSlot(new Slot(inventarioHorno, SLOT_MOLDE, 26, 35) {
			@Override
			public boolean canInsert(ItemStack stack) {
				return stack.isOf(ModItems.molde_de_fundicion);
			}
		});

		// Ranura de combustible: usa el mismo filtro que el horno vainilla.
		this.addSlot(new Slot(inventarioHorno, SLOT_COMBUSTIBLE, 56, 53) {
			@Override
			public boolean canInsert(ItemStack stack) {
				return ModFuel.esCombustible(stack);
			}
		});

		// Ranura de salida: solo se puede extraer, no colocar directamente.
		this.addSlot(new Slot(inventarioHorno, SLOT_SALIDA, 116, 35) {
			@Override
			public boolean canInsert(ItemStack stack) {
				return false;
			}
		});

		// Inventario del jugador (27 slots principales + 9 de hotbar).
		for (int fila = 0; fila < 3; fila++) {
			for (int col = 0; col < 9; col++) {
				this.addSlot(new Slot(playerInventory, col + fila * 9 + 9, 8 + col * 18, 84 + fila * 18));
			}
		}
		for (int col = 0; col < 9; col++) {
			this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 142));
		}
	}

	@Override
	public boolean canUse(PlayerEntity player) {
		return inventarioHorno.canPlayerUse(player);
	}

	@Override
	public ItemStack quickMove(PlayerEntity player, int index) {
		Slot slot = this.slots.get(index);
		if (slot == null || !slot.hasStack()) return ItemStack.EMPTY;
		ItemStack original = slot.getStack();
		ItemStack copia = original.copy();
		if (index < 4) {
			if (!this.insertItem(original, 4, this.slots.size(), true)) return ItemStack.EMPTY;
		} else {
			if (!this.insertItem(original, 0, 4, false)) return ItemStack.EMPTY;
		}
		if (original.isEmpty()) slot.setStack(ItemStack.EMPTY); else slot.markDirty();
		return copia;
	}
}