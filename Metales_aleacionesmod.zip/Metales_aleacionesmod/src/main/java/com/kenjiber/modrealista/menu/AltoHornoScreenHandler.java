package com.kenjiber.modrealista.menu;

import com.kenjiber.modrealista.block.entity.AltoHornoBlockEntity;
import com.kenjiber.modrealista.init.ModItems;
import com.kenjiber.modrealista.init.ModScreenHandlers;
import com.kenjiber.modrealista.util.ModFuel;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ArrayPropertyDelegate;
import net.minecraft.screen.PropertyDelegate;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.math.BlockPos;

/**
 * Igual que el ScreenHandler del Alto Horno vainilla, pero con una 4ta
 * ranura extra para el Molde Reutilizable (que no se consume).
 */
public class AltoHornoScreenHandler extends ScreenHandler {

	public static final int SLOT_FRAGMENTOS = 0;
	public static final int SLOT_MOLDE = 1;
	public static final int SLOT_COMBUSTIBLE = 2;
	public static final int SLOT_SALIDA = 3;

	private final Inventory inventarioHorno;
	private final PropertyDelegate propiedades;

	public static final int PROP_PROGRESO = 0;
	public static final int PROP_PROGRESO_TOTAL = 1;
	public static final int PROP_COMBUSTIBLE = 2;
	public static final int PROP_COMBUSTIBLE_MAX = 3;

	// CAMBIO: Ahora el constructor recibe BlockPos en lugar de Inventory.
	// Esto es necesario para el ExtendedScreenHandlerType en 1.21.1.
	public AltoHornoScreenHandler(int syncId, PlayerInventory playerInventory, BlockPos pos) {
		super(ModScreenHandlers.ALTO_HORNO, syncId);

		// Resolvemos el inventario desde el BlockEntity usando la posición
		BlockEntity be = playerInventory.player.getWorld().getBlockEntity(pos);
		if (be instanceof AltoHornoBlockEntity altoHorno) {
			this.inventarioHorno = altoHorno;
			this.propiedades = new PropertyDelegate() {
				@Override
				public int get(int index) {
					return switch (index) {
						case PROP_PROGRESO -> altoHorno.getProgresoRaw();
						case PROP_PROGRESO_TOTAL -> altoHorno.getTiempoTotalNecesarioRaw();
						case PROP_COMBUSTIBLE -> altoHorno.getCombustibleRestanteRaw();
						case PROP_COMBUSTIBLE_MAX -> altoHorno.getCombustibleMaximoRaw();
						default -> 0;
					};
				}

				@Override
				public void set(int index, int value) {
					switch (index) {
						case PROP_PROGRESO -> altoHorno.setProgresoRaw(value);
						case PROP_PROGRESO_TOTAL -> altoHorno.setTiempoTotalNecesarioRaw(value);
						case PROP_COMBUSTIBLE -> altoHorno.setCombustibleRestanteRaw(value);
						case PROP_COMBUSTIBLE_MAX -> altoHorno.setCombustibleMaximoRaw(value);
					}
				}

				@Override
				public int size() {
					return 4;
				}
			};
		} else {
			this.inventarioHorno = new SimpleInventory(4);
			this.propiedades = new ArrayPropertyDelegate(4);
		}
		checkSize(inventarioHorno, 4);
		this.addProperties(propiedades);

		// Ranura de fragmentos (input tipo "mineral").
		this.addSlot(new Slot(inventarioHorno, SLOT_FRAGMENTOS, 56, 17));

		// Ranura del molde: solo acepta molde_de_fundicion.
		this.addSlot(new Slot(inventarioHorno, SLOT_MOLDE, 26, 35) {
			@Override
			public boolean canInsert(ItemStack stack) {
				return stack.isOf(ModItems.molde_de_fundicion);
			}
		});

		// Ranura de combustible: usa el mismo filtro que el horno vainilla.
		this.addSlot(new Slot(inventarioHorno, SLOT_COMBUSTIBLE, 56, 53) {
			@Override
			public boolean canInsert(ItemStack stack) {
				return ModFuel.esCombustible(stack);
			}
		});

		// Ranura de salida: solo se puede extraer, no colocar directamente.
		this.addSlot(new Slot(inventarioHorno, SLOT_SALIDA, 116, 35) {
			@Override
			public boolean canInsert(ItemStack stack) {
				return false;
			}
		});

		// Inventario del jugador (27 slots principales + 9 de hotbar).
		for (int fila = 0; fila < 3; fila++) {
			for (int col = 0; col < 9; col++) {
				this.addSlot(new Slot(playerInventory, col + fila * 9 + 9, 8 + col * 18, 84 + fila * 18));
			}
		}
		for (int col = 0; col < 9; col++) {
			this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 142));
		}
	}

	@Override
	public boolean canUse(PlayerEntity player) {
		return inventarioHorno.canPlayerUse(player);
	}

	@Override
	public ItemStack quickMove(PlayerEntity player, int index) {
		Slot slot = this.slots.get(index);
		if (slot == null || !slot.hasStack()) return ItemStack.EMPTY;
		ItemStack original = slot.getStack();
		ItemStack copia = original.copy();
		if (index < 4) {
			if (!this.insertItem(original, 4, this.slots.size(), true)) return ItemStack.EMPTY;
		} else {
			if (!this.insertItem(original, 0, 4, false)) return ItemStack.EMPTY;
		}
		if (original.isEmpty()) slot.setStack(ItemStack.EMPTY); else slot.markDirty();
		return copia;
	}

	// --- Helpers para que la pantalla (cliente) dibuje la animación ---
	public float getProgresoFraccion() {
		int total = propiedades.get(PROP_PROGRESO_TOTAL);
		return total <= 0 ? 0f : (float) propiedades.get(PROP_PROGRESO) / total;
	}

	public float getCombustibleFraccion() {
		int max = propiedades.get(PROP_COMBUSTIBLE_MAX);
		return max <= 0 ? 0f : (float) propiedades.get(PROP_COMBUSTIBLE) / max;
	}
}