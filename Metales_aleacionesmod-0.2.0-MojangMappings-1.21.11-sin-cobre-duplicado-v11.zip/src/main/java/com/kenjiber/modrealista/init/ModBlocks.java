package com.kenjiber.modrealista.init;

import com.kenjiber.modrealista.block.AltoHornoBlock;
import com.kenjiber.modrealista.block.FusionFurnaceBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.valueproviders.UniformInt;
import java.util.function.Function;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

public final class ModBlocks {

	private ModBlocks() {}

	public static Block ALTO_HORNO_DE_COBRE;
	public static Block HORNO_DE_FUSION_BASICO;
	public static Block HORNO_DE_FUSION_AVANZADO;

	public static final java.util.Map<ModMetal, Block> MENAS = new java.util.EnumMap<>(ModMetal.class);
	public static final java.util.Map<ModMetal, Block> MENAS_PIZARRA_PROFUNDA = new java.util.EnumMap<>(ModMetal.class);

	public static void registrarTodo() {
		// ✅ ALTO HORNO — luz 12 cuando está encendido (LIT=true)
		ALTO_HORNO_DE_COBRE = registrarConItem("alto_horno_de_cobre",
				AltoHornoBlock::new,
				BlockBehaviour.Properties.of()
						.mapColor(MapColor.TERRACOTTA_ORANGE)
						.strength(3.5f, 6.0f)
						.luminance(state -> state.getValue(AltoHornoBlock.LIT) ? 12 : 0));

		// ✅ HORNO BÁSICO — luz 10 cuando está encendido (LIT=true)
		HORNO_DE_FUSION_BASICO = registrarConItem("horno_de_fusion_basico",
				props -> new FusionFurnaceBlock(props, 1),
				BlockBehaviour.Properties.of()
						.mapColor(MapColor.TERRACOTTA_ORANGE)
						.strength(4.0f, 8.0f)
						.luminance(state -> state.getValue(FusionFurnaceBlock.LIT) ? 10 : 0));

		// ✅ HORNO AVANZADO — luz 14 cuando está encendido (LIT=true)
		HORNO_DE_FUSION_AVANZADO = registrarConItem("horno_de_fusion_avanzado",
				props -> new FusionFurnaceBlock(props, 2),
				BlockBehaviour.Properties.of()
						.mapColor(MapColor.STONE)
						.strength(5.0f, 10.0f)
						.luminance(state -> state.getValue(FusionFurnaceBlock.LIT) ? 14 : 0));

		for (ModMetal metal : ModMetal.values()) {
			if (!metal.tieneMineralEnElMundo()) continue;

			float dureza = (metal == ModMetal.COBRE || metal == ModMetal.ESTANO)
					? 1.5f
					: 3.0f + metal.nivelMinado * 1.5f;

			MENAS.put(metal, registrarConItem("mena_" + metal.id,
					props -> new DropExperienceBlock(
							UniformInt.of(0, 1 + metal.nivelMinado), props),
					BlockBehaviour.Properties.of().mapColor(MapColor.STONE)
							.strength(dureza, dureza * 1.5f).requiresCorrectToolForDrops()));

			MENAS_PIZARRA_PROFUNDA.put(metal, registrarConItem("mena_" + metal.id + "_pizarra_profunda",
					props -> new DropExperienceBlock(
							UniformInt.of(0, 1 + metal.nivelMinado), props),
					BlockBehaviour.Properties.of().mapColor(MapColor.DEEPSLATE)
							.strength(dureza + 1.5f, dureza * 1.5f + 1.5f).requiresCorrectToolForDrops()));
		}

	}

	private static Block registrarConItem(String path, Function<BlockBehaviour.Properties, Block> factory, BlockBehaviour.Properties properties) {
		Identifier id = Identifier.fromNamespaceAndPath(MOD_ID, path);
		ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id);
		Block block = factory.apply(properties.setId(blockKey));
		Block registrado = Registry.register(BuiltInRegistries.BLOCK, blockKey, block);

		ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id);
		Registry.register(BuiltInRegistries.ITEM, itemKey,
				new BlockItem(registrado, new Item.Properties().setId(itemKey)));
		return registrado;
	}}
