package com.kenjiber.modrealista.world;

import com.kenjiber.modrealista.init.ModItems;
import com.kenjiber.modrealista.init.ModMetal;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;

/**
 * Reemplaza el drop de las menas vanilla de hierro y oro por fragmentos del mod.
 * El jugador debe fundir el fragmento para obtener el lingote.
 */
public class ModLootTables {

    private static final ResourceKey<LootTable> IRON_ORE = key("iron_ore");
    private static final ResourceKey<LootTable> DEEPSLATE_IRON_ORE = key("deepslate_iron_ore");
    private static final ResourceKey<LootTable> GOLD_ORE = key("gold_ore");
    private static final ResourceKey<LootTable> DEEPSLATE_GOLD_ORE = key("deepslate_gold_ore");
    private static final ResourceKey<LootTable> NETHER_GOLD_ORE = key("nether_gold_ore");

    private static ResourceKey<LootTable> key(String name) {
        return ResourceKey.create(Registries.LOOT_TABLE, Identifier.withDefaultNamespace("blocks/" + name));
    }

    public static void registrar() {
        // REEMPLAZAR: la mena ya no da el lingote vanilla, da el fragmento del mod.
        LootTableEvents.REPLACE.register((key, original, source, registries) -> {
            if (key.equals(IRON_ORE) || key.equals(DEEPSLATE_IRON_ORE)) {
                return dropSolo(ModItems.FRAGMENTOS_CRUDOS.get(ModMetal.HIERRO));
            }
            if (key.equals(GOLD_ORE) || key.equals(DEEPSLATE_GOLD_ORE) || key.equals(NETHER_GOLD_ORE)) {
                return dropSolo(ModItems.FRAGMENTOS_CRUDOS.get(ModMetal.ORO));
            }
            return null; // null = no modificar esta loot table
        });
    }

    private static LootTable dropSolo(net.minecraft.world.item.Item item) {
        return LootTable.lootTable()
                .withPool(LootPool.lootPool()
                        .setRolls(ConstantValue.exactly(1.0f))
                        .add(LootItem.lootTableItem(item))
                        .build())
                .build();
    }
}
