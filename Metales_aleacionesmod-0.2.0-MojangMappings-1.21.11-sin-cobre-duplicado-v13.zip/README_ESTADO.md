# Estado de migración — Mojang Mappings 1.21.11

Revisión adicional v9 basada en los errores de GitHub Actions.

Corregidos restos de Yarn detectados en el código:
- NonNullList.ofSize -> NonNullList.withSize
- UniformInt.create -> UniformInt.of
- ItemStack.getMaxCount -> getMaxStackSize
- BlockState.contains/get/with -> hasProperty/getValue/setValue
- LootTable.builder -> lootTable
- LootPool.builder -> lootPool
- ConstantValue.create -> exactly
- LootItem.builder -> lootTableItem
- defaultBlockState().with -> setValue

Se mantiene el uso de Mojang mappings en imports y nombres de API.


## v13 — fundición en horno vanilla y progresión de picos
- Corregidas las recetas de fundición/blast de fragmentos de estaño y aluminio al formato de ingredientes de Minecraft 1.21.11 (ID de item como string).
- Estaño y aluminio requieren como mínimo pico de piedra para obtener drops.
- Mena de hierro, oro y plata requieren pico de hierro para obtener drops; con pico de piedra se pueden romper, pero son más lentas y no sueltan el mineral/fragmento.
- Titanio y tungsteno siguen requiriendo pico de diamante mediante `needs_diamond_tool`.
