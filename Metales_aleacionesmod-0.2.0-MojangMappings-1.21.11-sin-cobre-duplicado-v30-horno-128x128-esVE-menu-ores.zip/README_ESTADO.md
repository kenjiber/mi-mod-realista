# Mod Realista — estado v26

Minecraft 1.21.11 · Fabric · Mojang mappings

## Cambios de v26
- Actualizadas las texturas del Horno de Fusión Avanzado con las seis imágenes suministradas.
- El Escudo de Plata usa el sistema `BLOCKS_ATTACKS` de 1.21.11 y un modelo especial que cambia a la pose de bloqueo al usarlo. También queda en el tag de durabilidad para encantamientos como Irrompibilidad/Reparación.
- Corregida la receta del Escudo de Plata al formato de ingredientes de 1.21.11.
- Añadido Arco de Plata con 768 de durabilidad (el doble del arco vanilla) y encantabilidad 20.
- El Arco de Plata carga aproximadamente el doble de rápido (10 ticks de carga completa) y dispara 25 % más rápido.
- Añadida Flecha de Plata y añadida al tag vanilla de flechas para que el Arco de Plata la reconozca.
- Añadidas tres variantes de receta de Flecha de Plata: pedernal en cualquiera de las tres posiciones de la fila superior, lingote de plata al centro y pluma abajo.
- Añadido el Arco de Plata al tag vanilla `enchantable/bow` y al tag de durabilidad para que pueda recibir los encantamientos de arco y Mending/Unbreaking.

## Validación
- JSON: pendiente de validación final.
- ZIP: pendiente de empaquetado final.
- Compilación Gradle local: no disponible en este entorno porque `gradle` no está instalado.


## v30
- Texturas nuevas del horno de fusión avanzado aplicadas a 128x128 con redimensionado NEAREST.
- Añadido `es_ve.json` para traducir el contenido del mod cuando Minecraft usa Español (Venezuela).
- Añadidas claves de traducción de las menas como items para evitar nombres sin traducir.
- Hierro y oro ya no aparecen como menas del mod en la pestaña creativa; se mantienen las menas vanilla.
