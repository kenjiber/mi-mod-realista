package com.kenjiber.modrealista.item;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/**
 * Arco de plata: mantiene el comportamiento vanilla del arco, pero completa
 * la tensión aproximadamente el doble de rápido (10 ticks en vez de 20).
 */
public class SilverBowItem extends BowItem {

    public SilverBowItem(Properties properties) {
        super(properties);
    }

    @Override
    public boolean releaseUsing(ItemStack stack, Level level, LivingEntity user, int remainingUseTicks) {
        // BowItem calcula la tensión a partir de maxUseTime - remainingUseTicks.
        // Restar 10 ticks hace que 10 ticks reales cuenten como ~20 ticks de carga.
        int acceleratedRemaining = Math.max(0, remainingUseTicks - 10);
        return super.releaseUsing(stack, level, user, acceleratedRemaining);
    }

    @Override
    protected void shootProjectile(LivingEntity shooter, Projectile projectile, int index, float speed,
                                    float divergence, float yaw, @Nullable LivingEntity target) {
        // El arco de plata dispara las flechas un 25 % más rápido que un arco vanilla.
        super.shootProjectile(shooter, projectile, index, speed * 1.25F, divergence, yaw, target);
    }
}
