package com.kenjiber.modrealista.init;

import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.component.BlocksAttacks;
import net.minecraft.world.level.block.entity.BannerPatternLayers;
import net.minecraft.world.item.enchantment.Enchantable;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;

import java.util.EnumMap;
import java.util.Map;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import static com.kenjiber.modrealista.ModRealista.MOD_ID;

import com.kenjiber.modrealista.item.SilverBowItem;

/**
 * ============================== ATENCION (1.21.11) ==============================
 * Cambios de API frente a 1.21.1:
 *   - Ya NO existen las clases PickaxeItem ni SwordItem: un pico o una espada
 *     ahora son un Item comun con Item.Properties#pickaxe(material, dano, vel)
 *     o #sword(material, dano, vel).
 *   - AxeItem y ShovelItem SI se mantienen (implementan interacciones propias:
 *     el hacha puede "pelar" troncos, la pala puede hacer caminos de tierra),
 *     pero su Item.Properties debe pasarse VACIO: el propio constructor de
 *     AxeItem/ShovelItem llama a .axe(...)/.shovel(...) internamente.
 *   - ArmorItem tambien desaparecio: una pieza de armadura es un Item comun
 *     con Item.Properties#humanoidArmor(material, ArmorType), sumado a
 *     .durability(ArmorType.X.getDurability(base)) para fijar su vida util
 *     (el ArmorMaterial ya no trae la durabilidad final calculada).
 * ==================================================================================
 */
public final class ModItems {

	private ModItems() {}

	// Mapas de acceso rápido: metal -> item concreto.
	public static final Map<ModMetal, Item> LINGOTES = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> FRAGMENTOS_CRUDOS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> PICOS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, AxeItem> HACHAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ShovelItem> PALAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> ESPADAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> CASCOS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> PECHERAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> PANTALONES = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, Item> BOTAS = new EnumMap<>(ModMetal.class);
	public static final Map<ModMetal, ShieldItem> ESCUDOS = new EnumMap<>(ModMetal.class);
	public static Item ARCO_DE_PLATA;
	public static Item FLECHA_DE_PLATA;

	/** Molde reutilizable: dura 15 lingotes procesados antes de romperse. */
	public static Item molde_de_fundicion;
	public static Item molde_de_arcilla_crudo;

	public static void registrarTodo() {
		molde_de_fundicion = registrar("molde_de_fundicion", Item::new, new Item.Properties().durability(15));
		molde_de_arcilla_crudo = registrar("molde_de_arcilla_crudo", Item::new, new Item.Properties());

		// Escudo de cobre: se configura con los componentes de escudo de 1.21.11.
		// ShieldItem por sí solo ya no aporta el bloqueo: la defensa vive en BLOCKS_ATTACKS.
		ESCUDOS.put(ModMetal.COBRE, registrar("escudo_de_cobre", ShieldItem::new, propiedadesDeEscudo(168)));

		// Armas a distancia de plata: arco con el doble de durabilidad del arco
		// vanilla (768) y mayor encantabilidad (20 frente a la del arco vanilla).
		ARCO_DE_PLATA = registrar("arco_de_plata", SilverBowItem::new,
				new Item.Properties().durability(768)
						.component(DataComponents.ENCHANTABLE, new Enchantable(20)));
		FLECHA_DE_PLATA = registrar("flecha_de_plata", ArrowItem::new, new Item.Properties());

		for (ModMetal metal : ModMetal.values()) {
			if (metal.esVanilla()) {
				if (metal == ModMetal.HIERRO) {
					LINGOTES.put(metal, net.minecraft.world.item.Items.IRON_INGOT);
					FRAGMENTOS_CRUDOS.put(metal, registrar("fragmento_crudo_hierro", Item::new, new Item.Properties()));
				} else if (metal == ModMetal.ORO) {
					LINGOTES.put(metal, net.minecraft.world.item.Items.GOLD_INGOT);
					FRAGMENTOS_CRUDOS.put(metal, registrar("fragmento_crudo_oro", Item::new, new Item.Properties()));
				} else {
					// El cobre es vanilla en 1.21.11: se reutiliza directamente el lingote vanilla.
					LINGOTES.put(metal, net.minecraft.world.item.Items.COPPER_INGOT);
				}
				continue;
			}

			LINGOTES.put(metal, registrar("lingote_" + metal.id, Item::new, new Item.Properties()));
			if (metal.tieneMineralEnElMundo()) {
				FRAGMENTOS_CRUDOS.put(metal, registrar("fragmento_crudo_" + metal.id, Item::new, new Item.Properties()));
			}

			ToolMaterial material = ModToolMaterials.get(metal);
			switch (metal.catalogo) {
				case SET_COMPLETO, SET_COMPLETO_HERRERIA -> {
					registrarSetDeHerramientas(metal, material);
					registrarArmadura(metal);
					if (metal == ModMetal.ALUMINIO) {
						registrar("arco_ligero_de_aluminio", BowItem::new, new Item.Properties().durability(300));
						registrar("flecha_de_alcance_aluminio", ArrowItem::new, new Item.Properties());
					}
				}
				case ESPECIAL_ARMA_ESCUDO -> {
					ESPADAS.put(metal, registrar("espada_de_" + metal.id, Item::new,
							new Item.Properties().sword(material, 3.0f, metal.velocidadAtaque)));
					PICOS.put(metal, registrar("pico_de_" + metal.id, Item::new,
							new Item.Properties().pickaxe(material, 1.0f, metal.velocidadAtaque)));
					ESCUDOS.put(metal, registrar("escudo_de_" + metal.id, ShieldItem::new,
							propiedadesDeEscudo(metal.durabilidadHerramienta * 4)));
				}
				case ESPECIAL_SOLO_HERRAMIENTA -> {
					PICOS.put(metal, registrar("pico_de_" + metal.id, Item::new,
							new Item.Properties().pickaxe(material, 1.0f, metal.velocidadAtaque)));
					HACHAS.put(metal, registrar("maza_pesada_de_" + metal.id,
							props -> new AxeItem(material, 4.0f, metal.velocidadAtaque, props), new Item.Properties()));
				}
				case ESPECIAL_LIGERO, ESPECIAL_MAGICO -> registrarSetDeHerramientas(metal, material);
				case SOLO_INGREDIENTE -> { }
			}
		}
	}

	/** Configuración de escudo compatible con el sistema BLOCKS_ATTACKS de Minecraft 1.21.11. */
	private static Item.Properties propiedadesDeEscudo(int durabilidad) {
		return new Item.Properties()
				.durability(durabilidad)
				.component(DataComponents.BANNER_PATTERNS, BannerPatternLayers.EMPTY)
				.equippableUnswappable(EquipmentSlot.OFFHAND)
				.component(DataComponents.BLOCKS_ATTACKS, new BlocksAttacks(
						0.25F,
						1.0F,
						List.of(new BlocksAttacks.DamageReduction(90.0F, Optional.empty(), 0.0F, 1.0F)),
						new BlocksAttacks.ItemDamageFunction(3.0F, 1.0F, 1.0F),
						Optional.of(DamageTypeTags.BYPASSES_SHIELD),
						Optional.of(SoundEvents.SHIELD_BLOCK),
						Optional.empty()))
				.component(DataComponents.BREAK_SOUND, SoundEvents.SHIELD_BREAK);
	}

	private static void registrarSetDeHerramientas(ModMetal metal, ToolMaterial material) {
		PICOS.put(metal, registrar("pico_de_" + metal.id, Item::new,
				new Item.Properties().pickaxe(material, 1.0f, metal.velocidadAtaque)));
		HACHAS.put(metal, registrar("hacha_de_" + metal.id,
				props -> new AxeItem(material, 3.0f, metal.velocidadAtaque, props), new Item.Properties()));
		PALAS.put(metal, registrar("pala_de_" + metal.id,
				props -> new ShovelItem(material, 1.5f, metal.velocidadAtaque, props), new Item.Properties()));
		ESPADAS.put(metal, registrar("espada_de_" + metal.id, Item::new,
				new Item.Properties().sword(material, 3.0f, metal.velocidadAtaque)));
	}

	private static void registrarArmadura(ModMetal metal) {
		ArmorMaterial mat = ModArmorMaterials.get(metal);
		int durBase = metal.armadura.durabilidadBase;

		CASCOS.put(metal, registrar("casco_de_" + metal.id, Item::new,
				new Item.Properties().humanoidArmor(mat, ArmorType.HELMET)
						.durability(ArmorType.HELMET.getDurability(durBase))));
		PECHERAS.put(metal, registrar("pechera_de_" + metal.id, Item::new,
				new Item.Properties().humanoidArmor(mat, ArmorType.CHESTPLATE)
						.durability(ArmorType.CHESTPLATE.getDurability(durBase))));
		PANTALONES.put(metal, registrar("pantalones_de_" + metal.id, Item::new,
				new Item.Properties().humanoidArmor(mat, ArmorType.LEGGINGS)
						.durability(ArmorType.LEGGINGS.getDurability(durBase))));
		BOTAS.put(metal, registrar("botas_de_" + metal.id, Item::new,
				new Item.Properties().humanoidArmor(mat, ArmorType.BOOTS)
						.durability(ArmorType.BOOTS.getDurability(durBase))));
	}

	private static <T extends Item> T registrar(String path, Function<Item.Properties, T> factory, Item.Properties properties) {
		Identifier id = Identifier.fromNamespaceAndPath(MOD_ID, path);
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
		T item = factory.apply(properties.setId(key));
		return Registry.register(BuiltInRegistries.ITEM, key, item);
	}
}
