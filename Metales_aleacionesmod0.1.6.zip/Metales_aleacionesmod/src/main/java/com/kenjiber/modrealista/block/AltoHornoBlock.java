package com.kenjiber.modrealista.block;

import com.kenjiber.modrealista.block.entity.AltoHornoBlockEntity;
import com.kenjiber.modrealista.init.ModBlockEntities;
import com.mojang.serialization.MapCodec; // <-- NUEVO IMPORT
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.NamedScreenHandlerFactory;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Alto Horno de Cobre: purifica fragmentos crudos en lingotes puros (ver AltoHornoBlockEntity). */
public class AltoHornoBlock extends BlockWithEntity {

    public AltoHornoBlock(Settings settings) {
        super(settings);
        // Por defecto se coloca apagado (lit=false); AltoHornoBlockEntity
        // cambia esta propiedad sola cuando el horno tiene combustible ardiendo.
        setDefaultState(getStateManager().getDefaultState().with(Properties.LIT, false));
    }

    @Override
    protected void appendProperties(StateManager.Builder<net.minecraft.block.Block, BlockState> builder) {
        builder.add(Properties.LIT);
    }

    // 1. AÑADIDO: Método obligatorio en 1.21.1
    @Override
    protected MapCodec<? extends BlockWithEntity> getCodec() {
        // Como este bloque no tiene propiedades extra (como el tier), 
        // usamos MapCodec.unit(this) para cumplir con el requisito.
        return MapCodec.unit(this);
    }

    // 2. MODIFICADO: Ahora es public en lugar de protected
    @Override
    public BlockRenderType getRenderType(BlockState state) {
        return BlockRenderType.MODEL;
    }

    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new AltoHornoBlockEntity(pos, state);
    }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState state, BlockEntityType<T> type) {
        return AltoHornoBlockEntity::tick;
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (world.isClient) return ActionResult.SUCCESS;
        BlockEntity be = world.getBlockEntity(pos);
        if (be instanceof NamedScreenHandlerFactory factory) {
            player.openHandledScreen(factory);
        }
        return ActionResult.CONSUME;
    }
}