package com.kenjiber.modrealista.block.entity;

import com.kenjiber.modrealista.init.ModItems;
import com.kenjiber.modrealista.menu.FusionFurnaceScreenHandler;
import com.kenjiber.modrealista.recipe.ModFusionRecipes;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventories;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Horno de Fusión: combina 2 lingotes/ingredientes (slots 0 y 1) + un Molde
 * en el slot 2 (se pide pero NO se consume) + combustible en el slot 3,
 * y produce 1 lingote de aleación en el slot 4.
 */
public class FusionFurnaceBlockEntity extends BlockEntity
		implements Inventory, ExtendedScreenHandlerFactory<BlockPos> {

	public static final int SLOT_ENTRADA_1 = 0;
	public static final int SLOT_ENTRADA_2 = 1;
	public static final int SLOT_MOLDE = 2;
	public static final int SLOT_COMBUSTIBLE = 3;
	public static final int SLOT_SALIDA = 4;
	private static final int TAMANO_INVENTARIO = 5;

	private final DefaultedList<ItemStack> inventario = DefaultedList.ofSize(TAMANO_INVENTARIO, ItemStack.EMPTY);
	private final int tier; // 1 = Básico, 2 = Avanzado

	private int progresoFundido = 0;
	private int tiempoTotalNecesario = 200;
	private int combustibleRestante = 0;
	private int combustibleMaximoActual = 0;

	public FusionFurnaceBlockEntity(BlockPos pos, BlockState state, int tier) {
		super(tier == 1
				? com.kenjiber.modrealista.init.ModBlockEntities.HORNO_FUSION_BASICO_ENTITY
				: com.kenjiber.modrealista.init.ModBlockEntities.HORNO_FUSION_AVANZADO_ENTITY,
				pos, state);
		this.tier = tier;
	}

	public int getTier() {
		return tier;
	}

	public boolean estaQuemando() {
		return combustibleRestante > 0;
	}

	public float getProgreso() {
		return tiempoTotalNecesario == 0 ? 0 : (float) progresoFundido / tiempoTotalNecesario;
	}

	public float getCombustibleProgreso() {
		return combustibleMaximoActual == 0 ? 0 : (float) combustibleRestante / combustibleMaximoActual;
	}

	// --- Ticker estático ---
	public static <T extends BlockEntity> void tick(World world, BlockPos pos, BlockState state, T be) {
		if (!(be instanceof FusionFurnaceBlockEntity horno)) return;
		if (world.isClient) return;
		horno.tickServidor((ServerWorld) world);
	}

	private void tickServidor(ServerWorld world) {
		ModFusionRecipes.Aleacion receta = ModFusionRecipes.buscarAleacion(
				stackOf(SLOT_ENTRADA_1), inventario.get(SLOT_ENTRADA_1).getCount(),
				stackOf(SLOT_ENTRADA_2), inventario.get(SLOT_ENTRADA_2).getCount(),
				tier);

		boolean puedeProcesar = puedeProcesar(receta);

		// 🔧 FIX: Si no puede procesar, apagar el horno (aunque quede combustible)
		if (!puedeProcesar) {
			if (combustibleRestante <= 0) progresoFundido = 0;
			actualizarEncendido(world, false);
			markDirty();
			return;
		}

		if (combustibleRestante <= 0) {
			ItemStack combustible = inventario.get(SLOT_COMBUSTIBLE);
			int valor = getValorCombustible(combustible);
			if (valor > 0) {
				combustibleRestante = valor;
				combustibleMaximoActual = valor;
				combustible.decrement(1);
			}
		}

		if (combustibleRestante > 0) {
			combustibleRestante--;
			tiempoTotalNecesario = receta.tiempoTicks();
			progresoFundido++;
			if (progresoFundido >= tiempoTotalNecesario) {
				progresoFundido = 0;
				boolean directo = receta.ingrediente1() == inventario.get(SLOT_ENTRADA_1).getItem();
				int consumo1 = directo ? receta.cantidad1() : receta.cantidad2();
				int consumo2 = directo ? receta.cantidad2() : receta.cantidad1();
				inventario.get(SLOT_ENTRADA_1).decrement(consumo1);
				inventario.get(SLOT_ENTRADA_2).decrement(consumo2);
				if (inventario.get(SLOT_SALIDA).isEmpty()) {
					inventario.set(SLOT_SALIDA, new ItemStack(receta.resultado()));
				} else {
					inventario.get(SLOT_SALIDA).increment(1);
				}
			}
		}
		actualizarEncendido(world, true);
		markDirty();
	}

	/**
	 * Comprueba si hay una receta válida, hay molde, y hay espacio en la salida.
	 * Se extrae a un método para poder reusarlo desde tickServidor y readNbt.
	 */
	private boolean puedeProcesar(ModFusionRecipes.Aleacion receta) {
		if (receta == null) return false;

		boolean tieneMolde = !inventario.get(SLOT_MOLDE).isEmpty()
				&& inventario.get(SLOT_MOLDE).isOf(ModItems.molde_de_fundicion);
		if (!tieneMolde) return false;

		ItemStack salida = inventario.get(SLOT_SALIDA);
		return salida.isEmpty()
				|| (salida.isOf(receta.resultado())
					&& salida.getCount() < salida.getMaxCount());
	}

	/**
	 * 🔧 FIX: Sincroniza la propiedad de bloque "lit" con el estado real del horno.
	 * Ahora el horno SOLO se ve encendido si está fundiendo activamente
	 * (combustible + receta válida + molde + espacio en la salida).
	 *
	 * Además, usa NOTIFY_LISTENERS | FORCE_STATE para garantizar que el paquete
	 * se envíe al cliente aunque el bloque esté lejos o en un chunk recién cargado.
	 */
	private void actualizarEncendido(ServerWorld world, boolean puedeProcesar) {
		boolean encendidoAhora = combustibleRestante > 0 && puedeProcesar;
		BlockState estado = world.getBlockState(pos);

		if (estado.contains(Properties.LIT)
				&& estado.get(Properties.LIT) != encendidoAhora) {
			world.setBlockState(pos,
					estado.with(Properties.LIT, encendidoAhora),
					Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
		}
	}

	private int getValorCombustible(ItemStack stack) {
		int valor = com.kenjiber.modrealista.util.ModFuel.tiempoDeQuemado(stack);
		if (valor == 0) return 0;
		return tier == 2 ? valor : valor / 2 + 1;
	}

	private Item stackOf(int slot) {
		return inventario.get(slot).getItem();
	}

	// ============ Persistencia (NBT) ============

	@Override
	protected void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
		super.readNbt(nbt, registries);
		Inventories.readNbt(nbt, inventario, registries);
		progresoFundido = nbt.getInt("Progreso");
		tiempoTotalNecesario = nbt.getInt("TiempoTotal");
		combustibleRestante = nbt.getInt("Combustible");
		combustibleMaximoActual = nbt.getInt("CombustibleMax");

		// 🔧 FIX: reconciliar el estado LIT al cargar el chunk.
		// Si el mundo se cerró con el horno encendido pero ya no puede procesar,
		// forzar LIT=false para evitar la "textura de encendido pegada".
		if (world != null && !world.isClient) {
			ModFusionRecipes.Aleacion receta = ModFusionRecipes.buscarAleacion(
					stackOf(SLOT_ENTRADA_1), inventario.get(SLOT_ENTRADA_1).getCount(),
					stackOf(SLOT_ENTRADA_2), inventario.get(SLOT_ENTRADA_2).getCount(),
					tier);
			boolean puedeProcesar = puedeProcesar(receta);
			boolean encendidoAhora = combustibleRestante > 0 && puedeProcesar;

			BlockState estado = world.getBlockState(pos);
			if (estado.contains(Properties.LIT)
					&& estado.get(Properties.LIT) != encendidoAhora) {
				world.setBlockState(pos,
						estado.with(Properties.LIT, encendidoAhora),
						Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
			}
		}
	}

	@Override
	protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
		super.writeNbt(nbt, registries);
		Inventories.writeNbt(nbt, inventario, registries);
		nbt.putInt("Progreso", progresoFundido);
		nbt.putInt("TiempoTotal", tiempoTotalNecesario);
		nbt.putInt("Combustible", combustibleRestante);
		nbt.putInt("CombustibleMax", combustibleMaximoActual);
	}

	// ============ Inventory ============

	@Override public int size() { return TAMANO_INVENTARIO; }
	@Override public boolean isEmpty() { return inventario.stream().allMatch(ItemStack::isEmpty); }
	@Override public ItemStack getStack(int slot) { return inventario.get(slot); }
	@Override public ItemStack removeStack(int slot, int amount) { return Inventories.splitStack(inventario, slot, amount); }
	@Override public ItemStack removeStack(int slot) { return Inventories.removeStack(inventario, slot); }
	@Override public void setStack(int slot, ItemStack stack) { inventario.set(slot, stack); }

	@Override
	public void markDirty() {
		super.markDirty();
		if (world != null) world.updateListeners(pos, getCachedState(), getCachedState(), 3);
	}

	@Override
	public boolean canPlayerUse(PlayerEntity player) {
		return world != null && world.getBlockEntity(pos) == this
				&& player.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 64.0;
	}

	@Override public void clear() { inventario.clear(); }

	// ============ ExtendedScreenHandlerFactory ============

	@Override
	public Text getDisplayName() {
		return Text.translatable(tier == 1
				? "block.modrealista.horno_de_fusion_basico"
				: "block.modrealista.horno_de_fusion_avanzado");
	}

	@Override
	public BlockPos getScreenOpeningData(ServerPlayerEntity player) {
		return this.pos;
	}

	@Override
	public ScreenHandler createMenu(int syncId, PlayerInventory playerInventory, PlayerEntity player) {
		return new FusionFurnaceScreenHandler(syncId, playerInventory, this.pos);
	}
}