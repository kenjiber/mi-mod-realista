package com.kenjiber.modrealista.screen;

import com.kenjiber.modrealista.ModRealista;
import com.kenjiber.modrealista.menu.FusionFurnaceScreenHandler;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class FusionFurnaceScreen extends HandledScreen<FusionFurnaceScreenHandler> {

	private static final Identifier TEXTURA = Identifier.of(ModRealista.MOD_ID, "textures/gui/container/horno_de_fusion.png");

	public FusionFurnaceScreen(FusionFurnaceScreenHandler handler, PlayerInventory inventory, Text title) {
		super(handler, inventory, title);
		this.backgroundWidth = 176;
		this.backgroundHeight = 166;
	}

	@Override
	protected void drawBackground(DrawContext context, float delta, int mouseX, int mouseY) {
		int x = (width - backgroundWidth) / 2;
		int y = (height - backgroundHeight) / 2;
		context.drawTexture(TEXTURA, x, y, 0, 0, backgroundWidth, backgroundHeight, 176, 166);
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		this.drawMouseoverTooltip(context, mouseX, mouseY);
	}
}
