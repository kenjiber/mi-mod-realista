# Estado de migración — Mojang Mappings 1.21.11

Revisión adicional v9 basada en los errores de GitHub Actions.

Corregidos restos de Yarn detectados en el código:
- NonNullList.ofSize -> NonNullList.withSize
- UniformInt.create -> UniformInt.of
- ItemStack.getMaxCount -> getMaxStackSize
- BlockState.contains/get/with -> hasProperty/getValue/setValue
- LootTable.builder -> lootTable
- LootPool.builder -> lootPool
- ConstantValue.create -> exactly
- LootItem.builder -> lootTableItem
- defaultBlockState().with -> setValue

Se mantiene el uso de Mojang mappings en imports y nombres de API.
