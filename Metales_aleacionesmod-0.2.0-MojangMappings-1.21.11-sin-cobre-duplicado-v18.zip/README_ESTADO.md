# Mod Realista — v18

Cambios de esta versión:
- Estaño: 3-6 fragmentos por mena.
- Aluminio: 3-6 fragmentos por mena.
- Plata: 1-4 fragmentos por mena.
- Hierro y oro (incluido oro del Nether): 1-4 fragmentos.
- Titanio y tungsteno: 1-2 fragmentos.
- Titanio y tungsteno solo entregan fragmentos con pico de acero o superior: acero, titanio, tungsteno, netherite vanilla, netherite-titanio y netherite-tungsteno.
